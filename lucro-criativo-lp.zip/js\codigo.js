/*
  codigo.js · textura de código do cartaz (Imersão Lucro Criativo · Koko)
  Direção de arte: Lara Sena (layout codigo.png, 26/11/2026)

  O que faz
  - Desenha linhas de código JavaScript numa fonte de pixel própria (bitmap 5x7
    com descendente, ampliada sem suavização) dentro de um <canvas data-codigo>.
    Glifos lilás sobre o azul, alguns tokens com bloco realçado (texto na cor do
    fundo), colunas de "8" com barras realçadas e colunas de pontos.
  - Movimento constante e calmo: as colunas rolam devagar, cada uma numa
    velocidade; uma linha é apagada e redigitada com cursor de bloco; alguns
    blocos realçados (seleção) pulam de palavra em palavra a cada 1–2 s.
  - Mouse (só a textura do fundo reage): os sinais a até ~140 px do ponteiro
    giram de leve (até 30°) "olhando" para ele; quando ele passa ou sai, voltam
    devagar à posição original (mola de ~1 s). Toque não gira nada; no celular o
    movimento constante continua, mais lento e a 30 quadros por segundo.
  - Desempenho: cada coluna é pré-renderizada numa faixa de baixa resolução
    (1 pixel da fonte = 1 pixel da faixa) e ampliada inteira com drawImage sem
    suavização; só os caracteres girados perto do ponteiro são desenhados um a
    um. Só redesenha quando algo mudou, pausa fora da tela e com a aba escondida,
    devicePixelRatio limitado a 2, ResizeObserver para o tamanho.
  - prefers-reduced-motion: um quadro parado, sem mouse.

  Uso
    <canvas class="codigo" data-codigo aria-hidden="true"></canvas>
    <script src="js/codigo.js" defer></script>
  O módulo se inicia sozinho em todo canvas[data-codigo]. Opções por atributo:
    data-codigo-cor         cor dos sinais e realces     (padrão #A9A9FF)
    data-codigo-fundo       cor do fundo                 (padrão #2D2BFF)
    data-codigo-escala      altura da linha em px CSS    (padrão automático: 16 no
                            celular, 17–22 no desktop; a largura da célula é a metade)
    data-codigo-opacidade   0–1, força dos sinais        (padrão 0.78)
    data-codigo-velocidade  multiplicador do movimento   (padrão 1; 0 = parado)
    data-codigo-semente     muda o sorteio do texto      (padrão 7)
  Ou à mão: LCCodigo.mount(canvas, { cor, fundo, escala, opacidade, velocidade,
  semente, raio, angulo, mouse, evitar, semMouse }) devolve { pausar, continuar, destruir, stats }.
  A digitação e os realces que pulam ficam fora do conteúdo do herói (img, svg, h1–h3,
  p, a, button, li, span, [data-retrato] e qualquer [data-codigo-evitar] dentro do pai do
  canvas); a rolagem e o giro do mouse valem para a textura toda (o conteúdo fica por cima).
  Um ponto de atenção por vez: com o ponteiro em cima de [data-retrato], [data-moeda-heroi] ou
  [data-codigo-sem-mouse] a textura não gira (essas peças têm a própria reação ao mouse).
  Atenção: data-codigo-escala abaixo de 14 não afina a linha; o pixel da fonte é inteiro e a
  linha nunca fica abaixo de 14 px CSS (em DPR 1 isso dá 24 px; em DPR 2, 18 px).
*/
(function () {
  'use strict';
  if (window.LCCodigo) return;

  /* ------------------------------------------------------------------ */
  /* Fonte de pixel 5x7 (+ linha de descendente)                         */
  /* Cada caractere = 5 colunas em hexa; bit 0 = linha de cima.          */
  /* ------------------------------------------------------------------ */
  const CARS = ' !"#$%&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~' + String.fromCharCode(0x2022);
  const BITS = (
    '0000000000 00005f0000 0007000700 147f147f14 242a7f2a12 2313086462 3649552250 0005030000 ' +
    '001c224100 0041221c00 14083e0814 08083e0808 0050300000 0808080808 0060600000 2010080402 ' +
    '3e5149453e 00427f4000 4261514946 2141454b31 1814127f10 2745454539 3c4a494930 0171090503 ' +
    '3649494936 064949291e 0036360000 0056360000 0814224100 1414141414 0041221408 0201510906 ' +
    '324979413e 7e1111117e 7f49494936 3e41414122 7f4141221c 7f49494941 7f09090901 3e4149497a ' +
    '7f0808087f 00417f4100 2040413f01 7f08142241 7f40404040 7f020c027f 7f0408107f 3e4141413e ' +
    '7f09090906 3e4151215e 7f09192946 4649494931 01017f0101 3f4040403f 1f2040201f 3f4038403f ' +
    '6314081463 0708700807 6151494543 007f414100 0204081020 0041417f00 0402010204 4040404040 ' +
    '0001020400 2054545478 7f48444438 3844444420 384444487f 3854545418 087e090102 18a4a4a47c ' +
    '7f08040478 00447d4000 4080847d00 7f10284400 00417f4000 7c04180478 7c08040478 3844444438 ' +
    'fc24242418 18242424fc 7c08040408 4854545420 043f444020 3c4040207c 1c2040201c 3c4030403c ' +
    '4428102844 1ca0a0a07c 4464544c44 0008364100 00007f0000 0041360800 0804081008 001c1c1c00'
  ).split(' ');

  const CW = 6, CH = 12;   // célula, em pixels da fonte (largura x altura da linha)
  const GX = 1, GY = 2;    // canto do glifo dentro da célula
  const BH = 11;           // altura do bloco realçado (1 px de respiro entre linhas)
  const CODS = new Map();  // código do caractere -> índice do glifo
  const GLIFOS = [];       // índice -> pixels acesos na célula (y*8 + x)
  for (let i = 0; i < CARS.length; i++) {
    CODS.set(CARS.charCodeAt(i), i);
    const pts = [];
    for (let x = 0; x < 5; x++) {
      const col = parseInt(BITS[i].substr(x * 2, 2), 16);
      for (let y = 0; y < 8; y++) if ((col >> y) & 1) pts.push((GY + y) * 8 + GX + x);
    }
    GLIFOS.push(Int16Array.from(pts));
  }
  const NG = CARS.length;
  const G = (ch) => CODS.get(ch.charCodeAt(0)) || 0;

  /* ------------------------------------------------------------------ */
  /* Texto: o gerador de números do layout (seed, buffer, Uint32Array...) */
  /* ------------------------------------------------------------------ */
  const CODIGO = [
    'class Sfc32 extends Rng {',
    '  constructor(seed) {',
    '    super()',
    '    this.buffer = new Uint32Array(4)',
    '    this.seed(seed)',
    '  }',
    '  seed(str) {',
    '    const h = xmur3(str)',
    '    for (let i = 0; i < 4; i++) {',
    '      this.buffer[i] = h()',
    '    }',
    '    return this',
    '  }',
    '  int() {',
    '    const s = this.buffer',
    '    const t = (((s[0] + s[1]) | 0) + s[3]) | 0',
    '    s[3] = (s[3] + 1) | 0',
    '    s[0] = s[1] ^ (s[1] >>> 9)',
    '    s[1] = (s[2] + (s[2] << 3)) | 0',
    '    s[2] = (s[2] << 21) | (s[2] >>> 11)',
    '    s[2] = (s[2] + t) | 0',
    '    return t >>> 0',
    '  }',
    '  bytes() { return new Uint8Array(this.buffer.buffer) }',
    '  copy() { return new Sfc32(this.buffer) }',
    '}',
    'function xmur3(str) {',
    '  let h = 1779033703 ^ str.length',
    '  for (let i = 0; i < str.length; i++) {',
    '    h = Math.imul(h ^ str.charCodeAt(i), 3432918353)',
    '    h = h << 13 | h >>> 19',
    '  }',
    '  return function () {',
    '    h = Math.imul(h ^ h >>> 16, 2246822507)',
    '    h = Math.imul(h ^ h >>> 13, 3266489909)',
    '    return (h ^= h >>> 16) >>> 0',
    '  }',
    '}',
    'function fnv(str) {',
    '  let h = 2166136261',
    '  for (let i = 0; i < str.length; i++) {',
    '    h ^= str.charCodeAt(i)',
    '    h = Math.imul(h, 16777619)',
    '  }',
    '  return h >>> 0',
    '}',
    'const rng = new Sfc32(seed)',
    'return new Sfc32(this.buffer)'
  ];
  // trechos "corrompidos", como no layout
  const LIXO = [
    'sssssssss ) by retturn new n',
    'copy() { etorn n SF',
    'by return new SFC32',
    'in retturn new Uint',
    'fun int() { stt t = (((s',
    'see s[3] = (s[3] + 1',
    'see s(3] - (s[3] *',
    'sss const s = this.b',
    'const t = (((s[1',
    's eel) fff iin return new',
    'e)db) }  see s[1] = (s[2',
    '}dbl) }un } o this.buffer.se',
    'let h = 2166136261',
    'for (let i = 0; i < str',
    'h = Math.imul(h ^ h >>> 13',
    'h += h << 13 h',
    'h ^= h >>> 7',
    'return f nction()',
    '<<(55))>>>>8  c',
    '>>>>>8  c  ft  ****',
    'str.charCodeAt(i), 16777619)) **',
    'str.length; i++) {',
    'nnnn(())    >>>>>8',
    'gth; i++gh ++) {  167++',
    'this.seed(seed)',
    'super() eed(s',
    '1]) >>> 8  9])  >>> 8 11]) +t)>>8'
  ];
  // linhas repetidas que formam colunas (prefixo variável + sufixo fixo)
  const PREFIXOS = [
    'newUint32Array(4)', 'ti tiBra(this.buffer', 'w Uint32Array(4)', 'ntBrythis.b)',
    '32(this.buffer)', 'ntBray(thiser)', '2(this.buffer)', 'tArray(this.buffer',
    'buffer(this.buffer', 'Array(this.buffer', 'buffer 1])', 'this.buffer', 'new Uint32Array(4)'
  ];
  const SUFIXOS = [
    ' fer.buffer) >> 8', ' for.buffer) >> 8', '.buffer) >> 8  8', ' >>> 8) + s[3]] >>> 8',
    ' >>> 8)) + s[3]) >>8', '.buffer.buffer) >> 8'
  ];
  const PARA_DIGITAR = CODIGO.map((s) => s.trim()).filter((s) => s.length > 6).concat(LIXO);

  /* ------------------------------------------------------------------ */
  /* Utilidades                                                          */
  /* ------------------------------------------------------------------ */
  function semear(s) {   // mulberry32: mesmo texto a cada visita
    let a = (Math.imul(s | 0, 2654435761) >>> 0) || 1;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  const mod = (a, m) => ((a % m) + m) % m;
  const escolher = (rnd, arr) => arr[(rnd() * arr.length) | 0];
  const suave = (x) => (x <= 0 ? 0 : x >= 1 ? 1 : x * x * (3 - 2 * x));
  function ouvirMQ(mq, f) { if (mq.addEventListener) mq.addEventListener('change', f); else if (mq.addListener) mq.addListener(f); }
  function largarMQ(mq, f) { if (mq.removeEventListener) mq.removeEventListener('change', f); else if (mq.removeListener) mq.removeListener(f); }

  function lerCor(ctx, valor, reserva) {   // aceita qualquer cor CSS
    ctx.fillStyle = reserva;
    try { ctx.fillStyle = valor; } catch (e) { /* mantém a reserva */ }
    const s = String(ctx.fillStyle);
    if (s[0] === '#') return [parseInt(s.slice(1, 3), 16), parseInt(s.slice(3, 5), 16), parseInt(s.slice(5, 7), 16)];
    const m = s.match(/[\d.]+/g);
    return m ? [+m[0], +m[1], +m[2]] : [169, 169, 255];
  }
  const mistura = (a, b, k) => [0, 1, 2].map((i) => Math.round(a[i] + (b[i] - a[i]) * k));
  const u32 = (c) => ((255 << 24) | (c[2] << 16) | (c[1] << 8) | c[0]) >>> 0;   // RGBA little-endian
  const rgb = (c) => 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';

  /* ------------------------------------------------------------------ */
  /* Linhas e painéis                                                    */
  /* ------------------------------------------------------------------ */
  // g = glifos da linha, base = realce fixo, dyn = realce móvel (contagem)
  function novaLinha(n) { return { g: new Uint8Array(n), base: new Uint8Array(n), dyn: new Uint8Array(n) }; }
  function escrever(L, txt, x0) {
    for (let i = 0; i < txt.length; i++) { const c = x0 + i; if (c >= 0 && c < L.g.length) L.g[c] = G(txt[i]); }
  }
  const realcado = (L, c) => (L.base[c] | L.dyn[c]) !== 0;
  function palavras(L) {   // [ini0, fim0, ini1, fim1, ...] das sequências sem espaço
    const out = [], n = L.g.length;
    let c = 0;
    while (c < n) {
      while (c < n && !L.g[c]) c++;
      if (c >= n) break;
      const s = c;
      while (c < n && L.g[c]) c++;
      out.push(s, c);
    }
    return out;
  }

  function gerarCodigo(rnd, n, nlin, dir) {
    const txt = [];
    while (txt.length < nlin) {
      const r = rnd();
      if (r < 0.4) {            // trecho de código seguido (linhas curtas ganham um resto, como no layout)
        const i0 = (rnd() * CODIGO.length) | 0, q = 4 + ((rnd() * 9) | 0), ind = (rnd() * 3) | 0;
        for (let k = 0; k < q; k++) {
          let s = ' '.repeat(ind) + CODIGO[(i0 + k) % CODIGO.length];
          if (s.length < n * 0.55 && rnd() < 0.45) s += '   ' + escolher(rnd, LIXO);
          txt.push(s);
        }
      } else if (r < 0.72) {    // repetição em coluna (como ".buffer) >> 8" no layout)
        const q = 5 + ((rnd() * 8) | 0), larg = 12 + ((rnd() * 7) | 0), suf = escolher(rnd, SUFIXOS);
        const suf2 = rnd() < 0.7 ? escolher(rnd, ['   8 )', '  >> 8  8', '  8  8 )', ') >>> 8', '  + s[3]) >>8']) : '';
        for (let k = 0; k < q; k++) txt.push((escolher(rnd, PREFIXOS) + ' '.repeat(larg)).slice(0, larg) + suf + suf2);
      } else if (r < 0.95) {    // código corrompido
        const q = 2 + ((rnd() * 4) | 0);
        for (let k = 0; k < q; k++) {
          let s = ' '.repeat((rnd() * 6) | 0) + escolher(rnd, LIXO);
          if (s.length < n * 0.5 && rnd() < 0.5) s += '  ' + escolher(rnd, LIXO);
          txt.push(s);
        }
      } else {                  // respiro
        txt.push('');
      }
    }
    txt.length = nlin;
    const corte = !dir && rnd() < 0.45 ? 1 + ((rnd() * 5) | 0) : 0;   // texto cortado na borda
    const margem = (rnd() * 3) | 0;
    const linhas = txt.map((s) => {
      const L = novaLinha(n);
      if (dir) { const t = s.replace(/\s+$/, ''); escrever(L, t, n - margem - t.length); }
      else escrever(L, s, -corte);
      return L;
    });
    // realces fixos: tokens soltos, começos de linha em sequência e um bloco de seleção
    for (let r = 0; r < nlin; r++) {
      const L = linhas[r];
      if (rnd() < 0.15) {
        const pw = palavras(L);
        if (pw.length) {
          const j = (rnd() * (pw.length / 2)) | 0;
          let c1 = pw[2 * j + 1];
          if (rnd() < 0.35 && 2 * j + 3 < pw.length) c1 = pw[2 * j + 3];
          for (let c = pw[2 * j]; c < c1; c++) L.base[c] = 1;
        }
      }
      if (rnd() < 0.03) {
        const q = 2 + ((rnd() * 3) | 0), w = Math.min(n, 5 + ((rnd() * 4) | 0));
        for (let k = 0; k < q && r + k < nlin; k++) for (let c = 0; c < w; c++) linhas[r + k].base[c] = 1;
      }
    }
    // blocos de seleção (vários por coluna, como as áreas claras do layout)
    const nBlocos = Math.round((nlin / 30) * (0.6 + rnd()));
    for (let b = 0; b < nBlocos && nlin > 8; b++) {
      const h = 2 + ((rnd() * 4) | 0), w = Math.min(n, 6 + ((rnd() * 14) | 0));
      const r0 = (rnd() * (nlin - h)) | 0, c0 = (rnd() * (n - w + 1)) | 0;
      for (let r = r0; r < r0 + h; r++) for (let c = c0; c < c0 + w; c++) linhas[r].base[c] = 1;
    }
    return linhas;
  }

  function gerarBarras(rnd, n, nlin) {   // colunas de "8" com barras realçadas
    const linhas = [], oito = G('8');
    let on = rnd() < 0.6, resta = 2 + ((rnd() * 10) | 0);
    let on2 = false, resta2 = 4 + ((rnd() * 10) | 0);
    for (let r = 0; r < nlin; r++) {
      const L = novaLinha(n);
      L.g[0] = oito;
      if (n > 2) L.g[2] = rnd() < 0.75 ? oito : G(rnd() < 0.5 ? ')' : '0');
      if (n > 3 && rnd() < 0.35) L.g[3] = G(')');
      if (on) { L.base[0] = 1; if (n > 1) L.base[1] = 1; }
      if (on2 && n > 2) L.base[2] = 1;
      if (--resta <= 0) { on = !on; resta = on ? 6 + ((rnd() * 20) | 0) : 2 + ((rnd() * 8) | 0); }
      if (--resta2 <= 0) { on2 = !on2; resta2 = on2 ? 2 + ((rnd() * 6) | 0) : 6 + ((rnd() * 14) | 0); }
      linhas.push(L);
    }
    return linhas;
  }

  function gerarPontos(rnd, n, nlin) {   // colunas de pontos
    const linhas = [], ponto = CARS.length - 1;   // o último glifo da fonte é o ponto (U+2022)
    let on = rnd() < 0.7, resta = 3 + ((rnd() * 10) | 0);
    for (let r = 0; r < nlin; r++) {
      const L = novaLinha(n);
      if (on) { L.g[0] = ponto; if (n > 1 && rnd() < 0.22) L.g[n - 1] = ponto; }
      else if (rnd() < 0.12) L.g[(rnd() * n) | 0] = ponto;
      if (--resta <= 0) { on = !on; resta = on ? 5 + ((rnd() * 14) | 0) : 1 + ((rnd() * 5) | 0); }
      linhas.push(L);
    }
    return linhas;
  }

  /* ------------------------------------------------------------------ */
  /* Instância                                                           */
  /* ------------------------------------------------------------------ */
  const instancias = [];

  function lerNumero(v, padrao) { const n = parseFloat(v); return isFinite(n) ? n : padrao; }

  function montar(canvas, opcoes) {
    if (!canvas || !canvas.getContext) return null;
    if (canvas.__lcCodigo) return canvas.__lcCodigo;
    const ds = canvas.dataset || {};
    const op = {
      cor: ds.codigoCor || '#A9A9FF',
      fundo: ds.codigoFundo || '#2D2BFF',
      escala: lerNumero(ds.codigoEscala, 0),
      opacidade: lerNumero(ds.codigoOpacidade, 0.78),
      velocidade: lerNumero(ds.codigoVelocidade, 1),
      semente: lerNumero(ds.codigoSemente, 7) | 0,
      raio: 140,      // px CSS em volta do ponteiro
      angulo: 30,     // giro máximo, em graus
      mouse: true,
      suaveGiro: true, // true = sinais girados com borda suave; false = pixel duro (mais barato sem GPU)
      // conteúdo do herói que a digitação e os realces evitam (procurado dentro do pai do canvas).
      // li/span/[data-retrato]: chips de data e formato, cartões e o retrato do topo (atrás do cartão
      // branco a digitação ficava escondida ~40% do tempo)
      evitar: 'img, svg, h1, h2, h3, p, a, button, li, span, [data-retrato], [data-codigo-evitar]',
      // um ponto de atenção por vez: com o ponteiro em cima disto (retrato e moeda do topo têm a própria
      // reação ao mouse) a textura não gira. '' desliga; dá para trocar ao vivo em LCCodigo.instancias[i].opcoes
      semMouse: '[data-retrato], [data-moeda-heroi], [data-codigo-sem-mouse]'
    };
    if (opcoes) for (const k in opcoes) if (opcoes[k] !== undefined && opcoes[k] !== null) op[k] = opcoes[k];

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    if (!canvas.hasAttribute('aria-hidden')) canvas.setAttribute('aria-hidden', 'true');

    // cores já misturadas com o fundo (tudo opaco: menos mistura por quadro)
    const F = lerCor(ctx, op.fundo, '#2D2BFF'), K = lerCor(ctx, op.cor, '#A9A9FF');
    const corTexto = mistura(F, K, Math.max(0, Math.min(1, op.opacidade)));
    const corBloco = mistura(F, K, 0.94);
    const corRealce = mistura(corBloco, F, 0.86);   // letra dentro do bloco
    const U_TEXTO = u32(corTexto), U_BLOCO = u32(corBloco), U_REALCE = u32(corRealce);
    const CSS_FUNDO = rgb(F);

    const mqMov = window.matchMedia ? matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
    const toque = !!(window.matchMedia && matchMedia('(hover: none) and (pointer: coarse)').matches);

    const st = {
      paineis: null, codigos: [], W: 0, H: 0, cssW: 0, cssH: 0, dpr: 1, u: 0, cwD: 0, lhD: 0, cols: 0, nlin: 0,
      t: 0, ultimo: 0, ultDesenho: -1e9, raf: 0, sujo: true, visivel: false, parado: false,
      reduzido: !!mqMov.matches, interativo: !toque && op.mouse !== false,
      ptr: { x: 0, y: 0, dentro: false }, giro: new Map(), marca: 0, lista: [],
      dig: null, realces: [], rnd: Math.random, atlasDev: null,
      stats: { quadros: 0, desenhos: 0, ms: 0, msDes: 0, max: 0 }
    };

    // atlas em baixa resolução: linha 0 = glifo lilás; linha 1 = bloco + glifo na cor do fundo.
    // Cada sprite tem 1 px transparente em volta: sem isso, o filtro bilinear do giro
    // puxa a cor do sprite vizinho e aparece um fio claro na borda.
    const PX = CW + 2, PY = CH + 2;
    const atlas = document.createElement('canvas');
    atlas.width = NG * PX; atlas.height = 2 * PY;
    {
      const larg = atlas.width, buf = new Uint32Array(larg * atlas.height);
      for (let g = 0; g < NG; g++) {
        const x0 = g * PX + 1;
        for (let y = 0; y < BH; y++) buf.fill(U_BLOCO, (PY + 1 + y) * larg + x0, (PY + 1 + y) * larg + x0 + CW);
        const pts = GLIFOS[g];
        for (let k = 0; k < pts.length; k++) {
          const x = x0 + (pts[k] & 7), y = 1 + (pts[k] >> 3);
          buf[y * larg + x] = U_TEXTO;
          buf[(PY + y) * larg + x] = U_REALCE;
        }
      }
      atlas.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(buf.buffer), larg, atlas.height), 0, 0);
    }
    // canto do sprite (glifo g, linha k) no atlas ampliado
    const spriteX = (g) => (g * PX + 1) * st.u;
    const spriteY = (k) => (k * PY + 1) * st.u;

    // pinta uma linha (12 px de altura) num buffer RGBA de largura 'larg'
    function pintarLinha(buf, larg, y0, L) {
      const n = L.g.length;
      buf.fill(0, y0 * larg, (y0 + CH) * larg);
      for (let c = 0; c < n; c++) {
        if (!realcado(L, c)) continue;
        const x0 = c * CW, x1 = Math.min(larg, x0 + CW + (c + 1 < n && realcado(L, c + 1) ? 0 : 1));
        for (let y = 0; y < BH; y++) buf.fill(U_BLOCO, (y0 + y) * larg + x0, (y0 + y) * larg + x1);
      }
      for (let c = 0; c < n; c++) {
        const g = L.g[c];
        if (!g) continue;
        const cor = realcado(L, c) ? U_REALCE : U_TEXTO, x0 = c * CW, pts = GLIFOS[g];
        for (let k = 0; k < pts.length; k++) buf[(y0 + (pts[k] >> 3)) * larg + x0 + (pts[k] & 7)] = cor;
      }
    }

    function criarFaixa(p) {   // a coluna inteira, pré-renderizada uma vez
      p.fw = p.ncols * CW + 1; p.fh = p.nlin * CH;
      p.faixa = document.createElement('canvas');
      p.faixa.width = p.fw; p.faixa.height = p.fh;
      p.fctx = p.faixa.getContext('2d');
      const buf = new Uint32Array(p.fw * p.fh);
      for (let r = 0; r < p.nlin; r++) pintarLinha(buf, p.fw, r * CH, p.linhas[r]);
      p.fctx.putImageData(new ImageData(new Uint8ClampedArray(buf.buffer), p.fw, p.fh), 0, 0);
      p.bufLinha = new Uint32Array(p.fw * CH);
      p.imgLinha = new ImageData(new Uint8ClampedArray(p.bufLinha.buffer), p.fw, CH);
    }
    function repintarLinha(p, r) {   // só a linha que mudou
      pintarLinha(p.bufLinha, p.fw, 0, p.linhas[r]);
      p.fctx.putImageData(p.imgLinha, 0, r * CH);
      st.sujo = true;
    }

    function gerar() {
      const rnd = semear(op.semente);
      st.rnd = semear(op.semente * 31 + 17);
      const cols = st.cols, nlin = st.nlin;
      const base = 8 * Math.max(0, op.velocidade) * (toque ? 0.6 : 1) * st.dpr;   // px de tela por segundo
      const paineis = [];
      let x = -((rnd() * 6) | 0);
      while (x < cols) {
        const lc = Math.max(12, Math.min(46, Math.round(cols * (0.16 + rnd() * 0.16))));
        const dir = rnd() < 0.35;
        paineis.push({ tipo: 'codigo', col0: x, ncols: lc, linhas: gerarCodigo(rnd, lc, nlin, dir), vel: base * (0.45 + rnd() * 0.55) });
        x += lc + 1 + (rnd() < 0.3 ? 1 : 0);
        if (x < cols && rnd() < 0.75) {
          const lb = 3 + ((rnd() * 2) | 0);
          paineis.push({ tipo: 'barras', col0: x, ncols: lb, linhas: gerarBarras(rnd, lb, nlin), vel: base * (0.2 + rnd() * 0.25) });
          x += lb + 1 + ((rnd() * 2) | 0);
        }
        if (x < cols && rnd() < 0.6) {
          const lp = 1 + ((rnd() * 3) | 0);
          paineis.push({ tipo: 'pontos', col0: x, ncols: lp, linhas: gerarPontos(rnd, lp, nlin), vel: base * (0.6 + rnd() * 0.4) });
          x += lp + 1 + ((rnd() * 2) | 0);
        }
      }
      paineis.forEach((p, i) => {
        p.i = i; p.nlin = nlin; p.total = nlin * st.lhD; p.xDev = p.col0 * st.cwD; p.off = 0;
        criarFaixa(p);
      });
      st.paineis = paineis;
      st.codigos = paineis.filter((p) => p.tipo === 'codigo');

      // atlas ampliado para os caracteres girados
      const a = document.createElement('canvas');
      a.width = atlas.width * st.u; a.height = atlas.height * st.u;
      const actx = a.getContext('2d');
      actx.imageSmoothingEnabled = false;
      actx.drawImage(atlas, 0, 0, a.width, a.height);
      st.atlasDev = a;

      st.giro.clear();
      zonasT = -9;   // tamanho novo: relê as áreas do conteúdo
      st.dig = { fase: 'espera', prox: st.t + 0.8, p: null, r: 0, ind: 0, pos: 0, k: 0, txt: '', vis: false };
      const n = Math.max(2, Math.min(6, Math.round((st.cssW * st.cssH) / 180000)));
      st.realces = [];
      for (let i = 0; i < n; i++) st.realces.push({ p: null, r: 0, c0: 0, c1: 0, ult: null, prox: st.t + 0.4 + i * 0.37 });
      st.sujo = true;
    }

    // posição (topo, px de tela) da linha r do painel p, já com a rolagem
    function posLinha(p, r) {
      let y = r * st.lhD - p.off;
      if (y < -st.lhD) y += p.total;
      return y;
    }
    function linhaVisivel(p, r, lo, hi) { const y = posLinha(p, r); return y >= st.H * lo && y + st.lhD <= st.H * hi; }
    function sortearLinha(p, lo, hi) {
      const s0 = Math.ceil((st.H * lo + p.off) / st.lhD), s1 = Math.floor((st.H * hi - st.lhD + p.off) / st.lhD);
      if (s1 < s0) return -1;
      return mod(s0 + ((st.rnd() * (s1 - s0 + 1)) | 0), p.nlin);
    }
    const colunaVisivel = (p, c) => p.col0 + c >= 0 && p.col0 + c < st.cols - 1;

    // Áreas do conteúdo do herói (logo, data...): a digitação e os realces que pulam
    // acontecem fora delas, para o nome, a data e o formato ficarem firmes.
    // Lidas no máximo 1x por segundo (só leitura de layout, nada é escrito no DOM).
    let zonas = [], zonasT = -9;
    function lerZonas() {
      if (st.t - zonasT < 1) return zonas;
      zonasT = st.t;
      zonas = [];
      const pai = canvas.parentElement;
      if (!pai || !op.evitar) return zonas;
      const rc = canvas.getBoundingClientRect();
      if (!rc.width) return zonas;
      const k = st.W / rc.width, m = st.lhD * 0.5;
      const els = pai.querySelectorAll(op.evitar);
      for (let i = 0; i < els.length; i++) {
        if (els[i] === canvas) continue;
        const r = els[i].getBoundingClientRect();
        if (r.width < 4 || r.height < 4) continue;
        zonas.push([(r.left - rc.left) * k - m, (r.top - rc.top) * k - m, (r.right - rc.left) * k + m, (r.bottom - rc.top) * k + m]);
      }
      return zonas;
    }
    function livre(x0, y0, x1, y1) {
      const zs = lerZonas();
      for (let i = 0; i < zs.length; i++) { const z = zs[i]; if (x0 < z[2] && x1 > z[0] && y0 < z[3] && y1 > z[1]) return false; }
      return true;
    }

    /* ---------- movimento constante ---------- */
    function rolar() {
      let mudou = false;
      for (const p of st.paineis) {
        const off = mod(Math.floor(p.vel * st.t), p.total);
        if (off !== p.off) { p.off = off; mudou = true; }
      }
      return mudou;
    }

    function passoDigitacao(t) {   // apaga uma linha e digita outra, com cursor de bloco
      const d = st.dig, rnd = st.rnd;
      let mudou = false, guarda = 0;
      while (t >= d.prox && guarda++ < 12) {
        if (d.fase === 'espera') {
          const cands = st.codigos.filter((p) => p.ncols >= 14 && colunaVisivel(p, 0) && colunaVisivel(p, 13));
          let achou = false;
          for (let tent = 0; tent < 10 && cands.length && !achou; tent++) {
            const p = escolher(rnd, cands), r = sortearLinha(p, 0.1, 0.9);
            if (r < 0) continue;
            const L = p.linhas[r];
            let fim = L.g.length;
            while (fim > 0 && (!L.g[fim - 1] || !colunaVisivel(p, fim - 1))) fim--;   // só o que aparece
            let ini = 0;
            while (ini < fim && !L.g[ini]) ini++;
            const ind = Math.min(ini, 3);
            let lim = p.ncols - ind - 1;
            while (lim > 0 && !colunaVisivel(p, ind + lim)) lim--;
            let txt = escolher(rnd, PARA_DIGITAR);
            if (txt.length > lim) txt = txt.slice(0, lim).replace(/\s+$/, '');
            const y = posLinha(p, r);
            if (txt.length < 6 || !livre(p.xDev + ind * st.cwD, y, p.xDev + Math.max(fim, ind + txt.length + 1) * st.cwD, y + st.lhD)) continue;
            for (let c = fim; c < L.g.length; c++) { L.g[c] = 0; L.base[c] = 0; }   // resto fora da tela
            d.p = p; d.r = r; d.ind = ind; d.pos = fim;
            d.txt = txt; d.k = 0; d.fase = 'apagando'; d.prox = t + 0.45;
            achou = true;
          }
          if (!achou) { d.prox = t + 1; break; }
        } else if (d.fase === 'apagando') {
          const L = d.p.linhas[d.r];
          if (d.pos > d.ind) { d.pos--; L.g[d.pos] = 0; L.base[d.pos] = 0; repintarLinha(d.p, d.r); d.prox += 0.018 + rnd() * 0.02; }
          else { d.fase = 'digitando'; d.prox += 0.35; }
        } else if (d.fase === 'digitando') {
          const L = d.p.linhas[d.r];
          if (d.k < d.txt.length) {
            const ch = d.txt[d.k++];
            L.g[d.ind + d.k - 1] = G(ch);
            d.pos = d.ind + d.k;
            repintarLinha(d.p, d.r);
            d.prox += (ch === ' ' ? 0.045 : 0.055 + rnd() * 0.07) + (rnd() < 0.06 ? 0.28 : 0);
          } else { d.fase = 'pausa'; d.prox += 1.3 + rnd() * 1.2; }
        } else {   // fim da pausa: some o cursor e espera a próxima linha
          d.fase = 'espera'; d.prox += 0.5 + rnd() * 1.2; d.p = null;
        }
        mudou = true;
      }
      let vis = d.p !== null && d.fase !== 'espera';
      if (d.fase === 'pausa') vis = ((t * 1.9) | 0) % 2 === 0;   // pisca parado
      if (vis !== d.vis) { d.vis = vis; mudou = true; }
      return mudou;
    }

    function marcarDyn(p, r, c0, c1, d) {
      const L = p.linhas[r];
      for (let c = c0; c < c1; c++) L.dyn[c] = Math.max(0, L.dyn[c] + d);
      repintarLinha(p, r);
    }
    function escolherProximo(ag) {   // próximo token: de preferência perto do anterior
      const rnd = st.rnd, ant = ag.ult;
      ag.p = null;
      for (let k = 0; k < 12; k++) {
        let p, r;
        if (ant && rnd() < 0.7) {
          p = ant.p; r = mod(ant.r + escolher(rnd, [0, 0, 1, 1, 2, -1]), p.nlin);
          if (!linhaVisivel(p, r, 0.02, 0.98)) continue;
        } else {
          if (!st.codigos.length) return;
          p = escolher(rnd, st.codigos); r = sortearLinha(p, 0.04, 0.96);
          if (r < 0) continue;
        }
        const pw = palavras(p.linhas[r]), np = pw.length / 2;
        if (!np) continue;
        let j = (rnd() * np) | 0;
        if (ant && p === ant.p) {
          if (r === ant.r) { j = 0; while (j < np && pw[2 * j] <= ant.c0) j++; if (j >= np) j = 0; }
          else { let melhor = 1e9; for (let i = 0; i < np; i++) { const dd = Math.abs(pw[2 * i] - ant.c0); if (dd < melhor) { melhor = dd; j = i; } } }
        }
        const c0 = pw[2 * j];
        let c1 = pw[2 * j + 1];
        if (rnd() < 0.3 && j + 1 < np) c1 = pw[2 * j + 3];
        if (!colunaVisivel(p, c0) || !colunaVisivel(p, c1 - 1)) continue;
        const y = posLinha(p, r);
        if (!livre(p.xDev + c0 * st.cwD, y, p.xDev + c1 * st.cwD, y + st.lhD)) continue;
        ag.p = p; ag.r = r; ag.c0 = c0; ag.c1 = c1; ag.ult = { p, r, c0 };
        return;
      }
      ag.ult = null;
    }
    function passoRealces(t) {   // blocos realçados pulando de token em token
      let mudou = false;
      for (const ag of st.realces) {
        if (t < ag.prox) continue;
        if (ag.p) marcarDyn(ag.p, ag.r, ag.c0, ag.c1, -1);
        escolherProximo(ag);
        if (ag.p) marcarDyn(ag.p, ag.r, ag.c0, ag.c1, 1);
        ag.prox = t + 1 + st.rnd() * 1;
        mudou = true;
      }
      return mudou;
    }

    /* ---------- mouse: sinais girando perto do ponteiro ---------- */
    const K_SEGUE = 70, C_SEGUE = 2 * 0.75 * Math.sqrt(K_SEGUE);   // acompanha o ponteiro (~0,4 s)
    const K_VOLTA = 14, C_VOLTA = 2 * 0.85 * Math.sqrt(K_VOLTA);   // volta devagar (~1 s)
    const GIRO_MIN = 0.008;   // abaixo de ~0,5° o giro não se vê: desenha reto (direto da faixa)

    function marcarZona(px, py, R) {
      const R2 = R * R, cw = st.cwD, lh = st.lhD, max = (op.angulo * Math.PI) / 180, marca = st.marca;
      const tmax = Math.tan(max), w = cw;   // w: suaviza a virada quando o ponteiro passa bem embaixo
      for (const p of st.paineis) {
        if (p.xDev > px + R || p.xDev + p.ncols * cw < px - R) continue;
        const c0 = Math.max(0, Math.floor((px - R - p.xDev) / cw));
        const c1 = Math.min(p.ncols - 1, Math.floor((px + R - p.xDev) / cw));
        const s0 = Math.floor((py - R + p.off) / lh) - 1, s1 = Math.floor((py + R + p.off) / lh);
        for (let s = s0; s <= s1; s++) {
          const r = mod(s, p.nlin), y = posLinha(p, r);
          if (y + lh <= 0 || y >= st.H) continue;
          const L = p.linhas[r], cy = y + lh * 0.46;
          for (let c = c0; c <= c1; c++) {
            if (!L.g[c] && !realcado(L, c)) continue;
            const cx = p.xDev + (c + 0.5) * cw, dx = px - cx, dy = py - cy, d2 = dx * dx + dy * dy;
            if (d2 > R2) continue;
            const q = Math.sqrt(d2) / R;
            const f = 1 - suave((q - 0.4) / 0.6);   // força total até 40% do raio, some na borda
            // o sinal inclina a linha de base "olhando" para o ponteiro (≈ atan(dy/dx)),
            // limitado a ±angulo; quem está logo acima/abaixo vira de lado quando ele passa
            const ax = Math.abs(dx) + w;
            const alvo = max * f * (dx / ax) * Math.tanh(dy / ax / tmax);
            const chave = p.i * 4194304 + r * 1024 + c;
            let e = st.giro.get(chave);
            if (!e) { e = { chave, p, r, c, a: 0, v: 0, dA: 0, alvo: 0, marca: 0, x: 0, y: 0, g: 0, re: false }; st.giro.set(chave, e); }
            e.alvo = alvo; e.marca = marca;
          }
        }
      }
    }

    function passoPonteiro(dt) {
      const zona = st.ptr.dentro && st.interativo && !st.reduzido;
      if (!zona && st.giro.size === 0) return false;
      st.marca++;
      if (zona) {
        const rc = canvas.getBoundingClientRect();   // uma leitura por quadro, sem escrita no DOM
        if (rc.width > 0) {
          const k = st.W / rc.width, R = op.raio * st.dpr;
          const px = (st.ptr.x - rc.left) * k, py = (st.ptr.y - rc.top) * k;
          if (px > -R && px < st.W + R && py > -R && py < st.H + R) marcarZona(px, py, R);
        }
      }
      let mexeu = false;
      const passos = Math.max(1, Math.ceil(dt * 60)), h = dt / passos;
      for (const e of st.giro.values()) {
        if (e.marca !== st.marca) e.alvo = 0;
        const k = e.alvo !== 0 ? K_SEGUE : K_VOLTA, c = e.alvo !== 0 ? C_SEGUE : C_VOLTA, a0 = e.a;
        for (let i = 0; i < passos; i++) { e.v += (k * (e.alvo - e.a) - c * e.v) * h; e.a += e.v * h; }
        if (e.alvo === 0 && Math.abs(e.a) < GIRO_MIN && Math.abs(e.v) < 0.02) {
          st.giro.delete(e.chave);
          if (Math.abs(e.dA) >= GIRO_MIN) mexeu = true;   // estava girado na tela: redesenha reto
          continue;
        }
        // só pede quadro novo quando o giro mudou o bastante para aparecer (~0,2°)
        if (Math.abs(e.a - e.dA) > 0.0035 && (Math.abs(e.a) >= GIRO_MIN || Math.abs(e.dA) >= GIRO_MIN)) mexeu = true;
      }
      return mexeu;
    }

    /* ---------- desenho ---------- */
    function desenhar() {
      if (!st.paineis) return;
      const t0 = performance.now();
      const u = st.u, W = st.W, H = st.H, cw = st.cwD, lh = st.lhD;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.imageSmoothingEnabled = false;
      ctx.fillStyle = CSS_FUNDO;
      ctx.fillRect(0, 0, W, H);
      for (const p of st.paineis) {   // faixas pré-renderizadas, ampliadas sem suavização
        const w = p.fw * u, h = p.fh * u, y = -p.off;
        if (p.xDev >= W || p.xDev + w <= 0) continue;
        ctx.drawImage(p.faixa, 0, 0, p.fw, p.fh, p.xDev, y, w, h);
        if (y + h < H) ctx.drawImage(p.faixa, 0, 0, p.fw, p.fh, p.xDev, y + h, w, h);
      }
      if (st.giro.size) {   // caracteres girados: cobre a célula e desenha girado por cima
        const lista = st.lista;
        lista.length = 0;
        ctx.fillStyle = CSS_FUNDO;
        for (const e of st.giro.values()) {
          e.dA = e.a;   // ângulo que ficou na tela
          if (Math.abs(e.a) < GIRO_MIN) continue;
          const p = e.p, y = posLinha(p, e.r);
          if (y + lh <= 0 || y >= H) continue;
          const L = p.linhas[e.r], x = p.xDev + e.c * cw, re = realcado(L, e.c);
          const extra = re && !(e.c + 1 < p.ncols && realcado(L, e.c + 1)) ? u : 0;
          ctx.fillRect(x, y, cw + extra, lh);
          e.x = x; e.y = y; e.re = re; e.g = L.g[e.c];
          lista.push(e);
        }
        if (lista.length) {
          ctx.imageSmoothingEnabled = op.suaveGiro !== false;
          const ax = cw * 0.5, ay = lh * 0.46, atl = st.atlasDev;
          for (let i = 0; i < lista.length; i++) {
            const e = lista[i], co = Math.cos(e.a), si = Math.sin(e.a);
            ctx.setTransform(co, si, -si, co, e.x + ax, e.y + ay);
            ctx.drawImage(atl, spriteX(e.g), spriteY(e.re ? 1 : 0), cw, lh, -ax, -ay, cw, lh);
          }
          ctx.setTransform(1, 0, 0, 1, 0, 0);
          ctx.imageSmoothingEnabled = false;
        }
      }
      const d = st.dig;   // cursor de bloco (inverte a letra embaixo)
      if (d && d.p && d.vis && d.pos < d.p.ncols) {
        const y = posLinha(d.p, d.r);
        if (y + lh > 0 && y < H) ctx.drawImage(st.atlasDev, spriteX(d.p.linhas[d.r].g[d.pos]), spriteY(1), cw, lh, d.p.xDev + d.pos * cw, y, cw, lh);
      }
      st.stats.desenhos++;
      st.stats.msDes += performance.now() - t0;
    }

    /* ---------- laço ---------- */
    function quadro(agora) {
      st.raf = requestAnimationFrame(quadro);
      const t0 = performance.now();
      let dt = (agora - st.ultimo) / 1000;
      st.ultimo = agora;
      if (!(dt > 0)) dt = 0;
      if (dt > 0.1) dt = 0.1;   // volta de pausa sem pulo
      st.t += dt;
      st.stats.quadros++;
      if (toque && agora - st.ultDesenho < 30) return;   // celular: até 30 quadros/s
      let sujo = st.sujo;
      st.sujo = false;
      if (rolar()) sujo = true;
      if (op.velocidade > 0) {
        if (passoDigitacao(st.t)) sujo = true;
        if (passoRealces(st.t)) sujo = true;
      }
      if (passoPonteiro(dt)) sujo = true;
      if (sujo || st.sujo) { st.sujo = false; desenhar(); st.ultDesenho = agora; }
      const ms = performance.now() - t0;
      st.stats.ms += ms;
      if (ms > st.stats.max) st.stats.max = ms;
    }
    function deveAnimar() { return !!st.paineis && st.visivel && !document.hidden && !st.reduzido && !st.parado; }
    function atualizarLoop() {
      if (deveAnimar()) {
        if (!st.raf) { st.ultimo = performance.now(); st.raf = requestAnimationFrame(quadro); }
      } else if (st.raf) { cancelAnimationFrame(st.raf); st.raf = 0; }
    }

    /* ---------- tamanho ---------- */
    function ajustar(cssW, cssH) {
      st.cssW = cssW; st.cssH = cssH;
      if (cssW < 2 || cssH < 2) return;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const W = Math.round(cssW * dpr), H = Math.round(cssH * dpr);
      const linha = op.escala > 0 ? op.escala : cssW < 600 ? 16 : Math.max(17, Math.min(22, cssW * 0.0145));
      // 1 pixel da fonte = u pixels de tela (inteiro: sem borrão); linha nunca abaixo de 14 px CSS
      let u = Math.max(1, Math.round((linha / CH) * dpr));
      if ((u / dpr) * CH < 14) u = Math.ceil((14 * dpr) / CH);
      const cwD = CW * u, lhD = CH * u, cols = Math.ceil(W / cwD) + 1, rows = Math.ceil(H / lhD) + 1;
      if (canvas.width !== W) canvas.width = W;
      if (canvas.height !== H) canvas.height = H;
      st.W = W; st.H = H;
      if (!st.paineis || u !== st.u || cols !== st.cols || rows > st.nlin || dpr !== st.dpr) {
        st.u = u; st.cwD = cwD; st.lhD = lhD; st.cols = cols; st.dpr = dpr;
        st.nlin = rows + Math.max(12, Math.ceil(rows * 0.6));
        gerar();
      }
      if (!st.reduzido) rolar();
      desenhar();
      atualizarLoop();
    }

    let ro = null, io = null, mqDpr = null;
    function aoMudarDpr() { if (mqDpr) largarMQ(mqDpr, aoMudarDpr); vigiarDpr(); ajustar(st.cssW, st.cssH); }
    function vigiarDpr() {
      if (!window.matchMedia) return;
      mqDpr = matchMedia('(resolution: ' + (window.devicePixelRatio || 1) + 'dppx)');
      ouvirMQ(mqDpr, aoMudarDpr);
    }
    function aoRedimensionarJanela() { const r = canvas.getBoundingClientRect(); ajustar(r.width, r.height); }

    if (window.ResizeObserver) {
      ro = new ResizeObserver((ents) => { const b = ents[ents.length - 1].contentRect; ajustar(b.width, b.height); });
      ro.observe(canvas);
    } else {
      window.addEventListener('resize', aoRedimensionarJanela);
      aoRedimensionarJanela();
    }
    if (window.IntersectionObserver) {
      io = new IntersectionObserver((ents) => { st.visivel = ents[ents.length - 1].isIntersecting; atualizarLoop(); }, { rootMargin: '80px' });
      io.observe(canvas);
    } else st.visivel = true;
    vigiarDpr();
    document.addEventListener('visibilitychange', atualizarLoop);

    function aoMudarMovimento() {
      st.reduzido = !!mqMov.matches;
      if (st.reduzido) {   // volta ao quadro parado
        st.t = 0; st.giro.clear();
        if (st.paineis) { gerar(); for (const p of st.paineis) p.off = 0; }
        desenhar();
      }
      atualizarLoop();
    }
    if (mqMov.matches !== undefined && window.matchMedia) ouvirMQ(mqMov, aoMudarMovimento);

    // mouse: ouvimos no pai do canvas (o herói), porque o conteúdo fica por cima
    const alvo = canvas.parentElement || canvas;
    function aoMover(e) {
      if (e.pointerType && e.pointerType !== 'mouse' && e.pointerType !== 'pen') return;
      // em cima do retrato só ele reage; a textura volta devagar, como quando o ponteiro sai
      const t = e.target;
      if (op.semMouse && t && t !== canvas && t.closest && t.closest(op.semMouse)) { st.ptr.dentro = false; return; }
      st.ptr.x = e.clientX; st.ptr.y = e.clientY; st.ptr.dentro = true;
    }
    function aoSair() { st.ptr.dentro = false; }
    if (st.interativo) {
      alvo.addEventListener('pointermove', aoMover, { passive: true });
      alvo.addEventListener('pointerleave', aoSair, { passive: true });
    }

    const api = {
      canvas,
      opcoes: op,
      pausar() { st.parado = true; atualizarLoop(); },
      continuar() { st.parado = false; atualizarLoop(); },
      redesenhar() { desenhar(); },
      destruir() {
        st.parado = true; atualizarLoop();
        if (ro) ro.disconnect();
        if (io) io.disconnect();
        if (mqDpr) largarMQ(mqDpr, aoMudarDpr);
        if (window.matchMedia) largarMQ(mqMov, aoMudarMovimento);
        window.removeEventListener('resize', aoRedimensionarJanela);
        document.removeEventListener('visibilitychange', atualizarLoop);
        alvo.removeEventListener('pointermove', aoMover);
        alvo.removeEventListener('pointerleave', aoSair);
        delete canvas.__lcCodigo;
        const i = instancias.indexOf(api);
        if (i >= 0) instancias.splice(i, 1);
      },
      // números para conferir desempenho (tempo de JS no laço, sem a parte da GPU)
      stats(zerar) {
        const s = st.stats;
        const r = {
          quadros: s.quadros, desenhos: s.desenhos,
          msPorQuadro: s.quadros ? +(s.ms / s.quadros).toFixed(3) : 0,
          msPorDesenho: s.desenhos ? +(s.msDes / s.desenhos).toFixed(3) : 0,
          msMax: +s.max.toFixed(3), girando: st.giro.size, rodando: !!st.raf,
          reduzido: st.reduzido, toque, interativo: st.interativo,
          canvas: st.W + 'x' + st.H, dpr: st.dpr, pixelDaFonte: st.u, celula: st.cwD + 'x' + st.lhD,
          colunas: st.cols, linhas: st.nlin, paineis: st.paineis ? st.paineis.length : 0
        };
        const d = st.dig;
        if (d && d.p) r.cursor = { fase: d.fase, x: Math.round((d.p.xDev + d.pos * st.cwD) / st.dpr), y: Math.round(posLinha(d.p, d.r) / st.dpr) };
        if (zerar) { s.quadros = 0; s.desenhos = 0; s.ms = 0; s.msDes = 0; s.max = 0; }
        return r;
      }
    };
    canvas.__lcCodigo = api;
    instancias.push(api);
    return api;
  }

  function iniciarTodos() {
    const lista = document.querySelectorAll('canvas[data-codigo]');
    for (let i = 0; i < lista.length; i++) montar(lista[i]);
  }

  // _fonte: só para a folha de conferência dos glifos (LP/_trabalho)
  window.LCCodigo = { mount: montar, montar, iniciar: iniciarTodos, instancias, _fonte: { CARS, GLIFOS, CW, CH } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciarTodos, { once: true });
  else iniciarTodos();
})();
