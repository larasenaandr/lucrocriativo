/*
  fx-decode.js · título que se decodifica (Imersão Lucro Criativo · Koko)
  Direção de arte: Lara Sena · 26/11/2026 · referência _refs/pins/3_codigo_vira_palavra.mp4, bem mais sutil

  O que faz
  - Na primeira vez que o elemento entra na tela (~40% dele acima da linha de 85% da altura da tela, para
    não acontecer colado na borda de baixo), cada letra passa rápido por sinais de código e assenta na
    letra certa, da esquerda para a direita, numa onda levemente diagonal (a linha de baixo vem um pouco
    depois), em ~850 ms no total. Se ele ficar inteiro à vista e parado abaixo dessa linha (fim da página),
    dispara depois de 0,6 s.
  - Os sinais (0 1 { } < > / * + = ; # $ _ [ ]) são desenhados na fonte de pixel 5x7 do codigo.js,
    quadrado por quadrado, com o respiro da grade, em azul claro (no fundo azul, lilás). Na frente da
    onda, um sinal por linha acende em laranja: o cursor. Antes de a onda chegar, cada letra é só um
    quadradinho da grade, bem claro, na linha de base, marcando o lugar.
  - Espaços e pontuação ficam fixos o tempo todo. O grifo laranja do <mark> some enquanto as letras dele
    estão em código e se desenha da esquerda para a direita logo que elas assentam (data-decode-grifo="nao"
    deixa o grifo parado).
  - O texto não é mexido: continua no HTML igual, com <mark>, <strong>, <br> e spans. Só a pintura muda:
    esperando a onda, o texto fica transparente por uma classe (.lcd-espera); durante a onda, só as letras
    que faltam ficam transparentes (CSS Custom Highlight API, ::highlight(lc-decode)). Os sinais vão num
    <canvas aria-hidden> dentro do elemento, em posição absoluta. Largura, quebra de linha e kerning não
    mudam (sem CLS), e o leitor de tela lê a frase certa desde o início.
  - Se o elemento já está na tela quando a página abre, ele fica como está (nada some e volta).
  - Desempenho: mede as letras só ao armar (~0,6 tela antes de aparecer) e ao disparar, nunca durante a
    animação; um requestAnimationFrame só para todos; sinais pré-desenhados num atlas e copiados com
    drawImage, num canvas em camada própria só enquanto anima; devicePixelRatio limitado a 2. Esperando, não
    custa nada por quadro (por isso a classe: o highlight faz o Chrome repintar o texto a cada quadro em que
    algo da página muda de estilo). Rodando, as letras prontas saem do highlight em levas (~16 por título)
    e, no celular (ponteiro grosso), a animação pede ~30 quadros por segundo. Saiu da tela no meio: termina
    na hora. Aba escondida: para e continua de onde parou. Depois de pronto, o canvas sai e nada mais roda.
  - prefers-reduced-motion, forced-colors ou navegador sem Highlight API (Safari < 17.2, Firefox < 140):
    o texto aparece direto, parado.
  - O CSS vem junto (um <style id="fx-decode-css">), o lp.css não precisa de nada.

  Uso
    <h2 class="h2" data-decode>Você já usa IA. Só que usa <mark>igual a todo mundo.</mark></h2>
    <script src="js/fx-decode.js" defer></script>
  Opções por atributo (todas opcionais):
    data-decode-tempo    duração total em ms                         (padrão 850)
    data-decode-atraso   espera em ms depois de entrar na tela       (padrão 0)
    data-decode-limiar   fração do elemento acima da linha de 85%    (padrão 0.4)
                         da tela que dispara, 0–1
    data-decode-cor      cor dos sinais de código                    (padrão: azul #0100FE em texto escuro,
                                                                       branco em texto claro, no fundo azul)
    data-decode-acento   cor do sinal que acende                     (padrão #FF5A1F)
    data-decode-grifo    "nao" = não anima o grifo do <mark>
  Use em elementos de bloco (h2, p, li...). À mão:
    LCDecode.iniciar(raiz)    procura [data-decode] novos (o arquivo já chama sozinho)
    LCDecode.rodar(el)        roda de novo agora, mesmo se já rodou (demo, conferência)
    LCDecode.revelar(el)      mostra o texto na hora;  LCDecode.revelarTodos()
    LCDecode.quadro(el, ms)   congela o efeito no instante ms (-1 = antes da onda), para conferir quadro a quadro
    LCDecode.estado(el), LCDecode.stats(zerar)  (tempo por quadro)
*/
(function () {
  'use strict';
  if (window.LCDecode) return;

  var doc = document;
  var NOME = 'lc-decode';            // nome do highlight
  var CSS_ID = 'fx-decode-css';
  var mm = function (q) { return window.matchMedia ? window.matchMedia(q) : null; };
  var mqCalmo = mm('(prefers-reduced-motion: reduce)');
  var mqForcado = mm('(forced-colors: active)');
  var mqToque = mm('(pointer: coarse)');
  var toque = function () { return !!(mqToque && mqToque.matches); };
  var quieto = function () { return !!((mqCalmo && mqCalmo.matches) || (mqForcado && mqForcado.matches)); };
  var temHL = !!(window.CSS && CSS.highlights && typeof window.Highlight === 'function');
  var temIO = 'IntersectionObserver' in window;
  var HL = null;

  var RE_LETRA, RE_MARCA;
  try { RE_LETRA = new RegExp('[\\p{L}\\p{N}]', 'u'); RE_MARCA = new RegExp('\\p{M}', 'u'); }
  catch (e) { RE_LETRA = /[0-9A-Za-z\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u024F]/; RE_MARCA = /[\u0300-\u036F]/; }

  /* ------------------------------------------------------------------ */
  /* Ajustes do desenho                                                  */
  /* ------------------------------------------------------------------ */
  var AJ = {
    onda: 0.8,          // peso da posição na linha na hora em que cada letra começa (o resto vem da linha)
    acaso: 0.025,       // um tiquinho de acaso na onda (fração do tempo da onda)
    sinal: 0.2,         // fração do tempo total que cada letra passa em código (entre 120 e 240 ms)
    escala: 1,          // altura do sinal / altura da maiúscula
    respiro: 0.28,      // vão da grade entre os quadrados do sinal (fração do quadrado)
    grifo: 380,         // ms do grifo do <mark> se desenhando, logo depois que as letras dele assentam
    lote: 55,           // ms entre uma leva de letras reveladas e a próxima: cada mudança no highlight faz o
                        // Chrome repintar o texto, então as letras prontas saem juntas (~16 vezes por título)
    loteToque: 66,      // o mesmo no celular
    passoToque: 33,     // no celular (ponteiro grosso), um quadro a cada ~33 ms (30 qps), como o codigo.js
    claro:  { ponto: 0.22, sinal: 0.5, acende: 0.95 },    // texto escuro no fundo claro (sinais no azul)
    escuro: { ponto: 0.30, sinal: 0.58, acende: 1 },      // texto claro no fundo azul (sinais brancos)
    zona: '60% 0px 60% 0px',                               // arma (esconde e põe os pontos) a ~0,6 tela
    linha: '0px 0px -15% 0px',                             // dispara com o limiar acima da linha de 85% da tela
    parado: 600                                            // inteiro à vista e parado (fim da página): dispara
  };

  /* ------------------------------------------------------------------ */
  /* Fonte de pixel 5x7 (o mesmo desenho do codigo.js)                   */
  /* 5 colunas em hexa; bit 0 = linha de cima.                           */
  /* ------------------------------------------------------------------ */
  var BITS = {
    '0': '3e5149453e', '1': '00427f4000', '{': '0008364100', '}': '0041360800',
    '<': '0814224100', '>': '0041221408', '/': '2010080402', '*': '14083e0814',
    '+': '08083e0808', '=': '1414141414', ';': '0056360000', '#': '147f147f14',
    '$': '242a7f2a12', '_': '4040404040', '[': '007f414100', ']': '0041417f00'
  };
  var PX = Object.keys(BITS).map(function (ch) {
    var h = BITS[ch], p = [];
    for (var x = 0; x < 5; x++) { var c = parseInt(h.substr(x * 2, 2), 16); for (var y = 0; y < 8; y++) if ((c >> y) & 1) p.push(x, y); }
    return p;
  });
  var NS = PX.length;           // sinais sorteáveis
  var PONTO = NS; PX.push([2, 6]);   // o quadradinho da grade que marca o lugar da letra (na linha de base)

  // atlas: todos os sinais num canvas, por tamanho do quadrado (px do aparelho) e cor
  var atlas = new Map();
  function pegaAtlas(u, cor) {
    var k = u + '|' + cor, a = atlas.get(k);
    if (a) return a;
    var g = u >= 3 ? Math.max(1, Math.round(u * AJ.respiro)) : 0;   // respiro da grade entre os quadrados
    var cw = 5 * u, ch = 7 * u, c = doc.createElement('canvas');
    c.width = cw * PX.length; c.height = ch;
    var x = c.getContext('2d');
    x.fillStyle = cor;
    for (var i = 0; i < PX.length; i++) { var p = PX[i]; for (var j = 0; j < p.length; j += 2) x.fillRect(i * cw + p[j] * u, p[j + 1] * u, u - g, u - g); }
    a = { c: c, cw: cw, ch: ch, g: g };
    atlas.set(k, a);
    return a;
  }

  // sorteio com semente (a mesma frase sempre se decodifica igual)
  function semente(s) {
    var h = 2166136261;
    for (var i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 16777619);
    return function () {
      h = (h + 0x6D2B79F5) | 0;
      var t = Math.imul(h ^ (h >>> 15), h | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // métricas da fonte para achar a linha de base dentro da caixa da letra
  var ctxMede = null, metricas = new Map();
  function metrica(cs) {
    var f = cs.fontStyle + ' ' + cs.fontWeight + ' 100px ' + cs.fontFamily, m = metricas.get(f);
    if (m) return m;
    if (!ctxMede) ctxMede = doc.createElement('canvas').getContext('2d');
    ctxMede.font = f;
    var H = ctxMede.measureText('H');
    var asc = H.fontBoundingBoxAscent > 0 ? H.fontBoundingBoxAscent : 90.5;     // (Arial, se o navegador não souber)
    var desc = H.fontBoundingBoxDescent > 0 ? H.fontBoundingBoxDescent : 21.2;
    var cap = H.actualBoundingBoxAscent > 0 ? H.actualBoundingBoxAscent : 71.6;
    m = { base: asc / (asc + desc), cap: cap / 100 };
    metricas.set(f, m);
    return m;
  }

  function textoClaro(cor) {   // a cor do texto é clara? (texto branco no fundo azul)
    var m = /rgba?\(([^)]+)\)/.exec(cor || '');
    if (!m) return false;
    var p = m[1].split(/[\s,\/]+/).map(parseFloat);
    return (0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) / 255 > 0.55;
  }

  /* ------------------------------------------------------------------ */
  /* Instâncias                                                          */
  /* ------------------------------------------------------------------ */
  var mapa = new Map();          // elemento -> instância
  var rodando = new Set();
  var ioArma = null, ioDispara = null, ioVisto = null, ro = null;
  var raf = 0, ultimo = 0;
  var est = { quadros: 0, soma: 0, max: 0, ult: new Float32Array(240) };   // ult: os últimos quadros (para o p95)

  function opcoes(el) {
    var d = el.dataset, num = function (v, p) { v = parseFloat(v); return isFinite(v) ? v : p; };
    var gr = String(d.decodeGrifo || '').toLowerCase();
    return {
      tempo: Math.max(300, num(d.decodeTempo, 850)),
      atraso: Math.max(0, num(d.decodeAtraso, 0)),
      limiar: Math.min(1, Math.max(0.05, num(d.decodeLimiar, 0.4))),
      cor: d.decodeCor || '',
      acento: d.decodeAcento || '#FF5A1F',
      grifo: !(gr === 'nao' || gr === 'n\u00e3o' || gr === 'false' || gr === '0')
    };
  }

  var PULA = /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE|CANVAS|svg|SVG|TEXTAREA|SELECT|OPTION|BUTTON|INPUT)$/;
  // as letras e números do elemento, cada um com um Range (o texto em si não é tocado)
  function coletar(el) {
    var us = [];
    var tw = doc.createTreeWalker(el, NodeFilter.SHOW_TEXT, {
      acceptNode: function (n) {
        for (var p = n.parentNode; p && p !== el; p = p.parentNode) {
          if (PULA.test(p.nodeName) || (p.hasAttribute && p.hasAttribute('data-decode'))) return NodeFilter.FILTER_REJECT;
        }
        return NodeFilter.FILTER_ACCEPT;
      }
    });
    for (var n = tw.nextNode(); n; n = tw.nextNode()) {
      var s = n.data;
      for (var i = 0; i < s.length;) {
        var ch = String.fromCodePoint(s.codePointAt(i)), j = i + ch.length;
        while (j < s.length && RE_MARCA.test(s[j])) j++;     // acento solto vai junto da letra
        if (RE_LETRA.test(ch)) { var rg = doc.createRange(); rg.setStart(n, i); rg.setEnd(n, j); us.push({ rg: rg, fora: true, oculta: false, pronta: false }); }
        i = j;
      }
    }
    return us;
  }

  function registrar(el) {
    var inst = mapa.get(el);
    if (!inst) {
      inst = { el: el, o: opcoes(el), estado: 'novo', t: 0, unidades: coletar(el), cv: null, ctx: null,
               pos: null, marcas: [], marcasMed: [], tam: null, n: 0 };
      mapa.set(el, inst);
    }
    return inst;
  }

  // LEITURAS: caixa do elemento, caixa de cada letra, estilos. Nada é escrito aqui.
  function medir(inst) {
    var el = inst.el;
    if (!el.isConnected) return false;
    var r = el.getBoundingClientRect();
    if (!r.width || !r.height) return false;
    var sx = el.offsetWidth ? r.width / el.offsetWidth : 1, sy = el.offsetHeight ? r.height / el.offsetHeight : 1;
    var cs = getComputedStyle(el), estilos = new Map();
    var minX = Infinity, maxX = -Infinity, fsMax = 0, n = 0;
    for (var i = 0; i < inst.unidades.length; i++) {
      var u = inst.unidades[i], no = u.rg.startContainer;
      u.fora = true;
      if (!no || !no.isConnected || u.rg.collapsed) continue;
      var q = u.rg.getBoundingClientRect();
      if (!q.width || !q.height) continue;                     // letra escondida (display:none etc.)
      var p = no.parentElement, e = estilos.get(p);
      if (!e) { var c = p === el ? cs : getComputedStyle(p); e = { fs: parseFloat(c.fontSize) || 16, m: metrica(c) }; estilos.set(p, e); }
      u.fora = false;
      u.x = (q.left - r.left) / sx;
      u.w = q.width / sx;
      u.base = (q.top - r.top) / sy + (q.height / sy) * e.m.base;
      u.cap = e.m.cap * e.fs * AJ.escala;
      u.fs = e.fs;
      if (u.x < minX) minX = u.x;
      if (u.x + u.w > maxX) maxX = u.x + u.w;
      if (e.fs > fsMax) fsMax = e.fs;
      n++;
    }
    inst.n = n;
    inst.caixa = { x: r.left, y: r.top, w: r.width / sx, h: r.height / sy, bl: el.clientLeft, bt: el.clientTop };
    inst.minX = minX; inst.maxX = maxX; inst.fsMax = fsMax || 16;
    inst.posCalc = cs.position;
    if (!inst.espera) inst.corTexto = cs.color;          // (esperando, a cor calculada é a transparente da classe)
    inst.marcasMed = [];
    if (inst.o.grifo && !inst.marcas.length) {
      var ms = el.querySelectorAll('mark');
      for (var k = 0; k < ms.length; k++) { var mc = getComputedStyle(ms[k]); inst.marcasMed.push({ m: ms[k], bi: mc.backgroundImage, bs: mc.backgroundSize }); }
    }
    return n > 0;
  }

  // a onda: quando cada letra começa, quanto tempo fica em código e por quais sinais passa
  function planejar(inst) {
    var T = inst.o.tempo, S = Math.min(240, Math.max(120, T * AJ.sinal)), V = T - S;
    var rnd = semente(inst.el.textContent || '');
    var nl = 0, bAtual = null, i, u;
    for (i = 0; i < inst.unidades.length; i++) {
      u = inst.unidades[i];
      if (u.fora) continue;
      if (bAtual === null || Math.abs(u.base - bAtual) > u.fs * 0.5) { bAtual = u.base; nl++; }
      u.li = nl - 1;
    }
    var larg = Math.max(1, inst.maxX - inst.minX);
    for (i = 0; i < inst.unidades.length; i++) {
      u = inst.unidades[i];
      // 3 ou 4 sinais por letra (o da letra na frente da onda sai em laranja: o cursor)
      var j = rnd() - 0.5, sv = rnd(), nk = 3 + Math.floor(rnd() * 2);
      u.seq = [];
      for (var k = 0, ant = -1; k < nk; k++) { var g; do { g = Math.floor(rnd() * NS); } while (g === ant); u.seq.push(g); ant = g; }
      if (u.fora) continue;
      var xn = (u.x + u.w / 2 - inst.minX) / larg, yn = nl > 1 ? u.li / (nl - 1) : 0;
      u.a = Math.max(0, Math.min(V, V * (AJ.onda * xn + (1 - AJ.onda) * yn) + j * AJ.acaso * V));
      u.s = Math.max(80, Math.min(T - u.a, S * (0.9 + 0.2 * sv)));
    }
    inst.frente = new Int16Array(Math.max(1, nl));
    // o grifo de cada <mark> se desenha logo depois que as letras dele assentam
    for (i = 0; i < inst.marcas.length; i++) {
      var mk = inst.marcas[i], fim = -1;
      for (var q = 0; q < inst.unidades.length; q++) {
        u = inst.unidades[q];
        if (!u.fora && mk.m.contains(u.rg.startContainer) && u.a + u.s > fim) fim = u.a + u.s;
      }
      mk.ini = Math.max(0, fim - 80);
      mk.dur = fim < 0 ? 1 : AJ.grifo;
    }
  }

  // ESCRITAS: canvas no lugar, sinais posicionados em px do aparelho
  function montar(inst) {
    var el = inst.el, cx = inst.caixa, dpr = Math.min(2, window.devicePixelRatio || 1);
    if (!inst.cv) {
      var cv = doc.createElement('canvas');
      cv.className = 'lcd-camada';
      cv.setAttribute('aria-hidden', 'true');
      inst.cv = cv; inst.ctx = cv.getContext('2d');
    }
    if (inst.pos === null && inst.posCalc === 'static') { inst.posSt = el.hasAttribute('style'); inst.pos = el.style.position; el.style.position = 'relative'; }
    var P = Math.ceil(inst.fsMax * 0.3);
    // canto do canvas alinhado à grade de pixels da tela (quadrados nítidos)
    var xd = Math.round(cx.x * dpr) / dpr, yd = Math.round((cx.y - P) * dpr) / dpr;
    var ox = xd - cx.x, oy = yd - cx.y;
    var bw = Math.ceil((cx.w - ox) * dpr) + 1, bh = Math.ceil((cx.h - oy + P) * dpr) + 1;
    if (bw * bh > 16e6) { dpr = 1; bw = Math.ceil(cx.w - ox) + 1; bh = Math.ceil(cx.h - oy + P) + 1; }
    inst.dpr = dpr;
    if (inst.cv.width !== bw) inst.cv.width = bw;
    if (inst.cv.height !== bh) inst.cv.height = bh;
    var st = inst.cv.style;
    st.left = (ox - cx.bl) + 'px'; st.top = (oy - cx.bt) + 'px';
    st.width = bw / dpr + 'px'; st.height = bh / dpr + 'px';
    if (inst.cv.parentNode !== el) el.appendChild(inst.cv);

    var noAzul = textoClaro(inst.corTexto);
    inst.alfa = noAzul ? AJ.escuro : AJ.claro;
    var cor = inst.o.cor || (noAzul ? '#FFFFFF' : '#0100FE');
    for (var i = 0; i < inst.unidades.length; i++) {
      var u = inst.unidades[i];
      if (u.fora) { u.atC = u.atA = null; continue; }
      var U = Math.max(2, Math.round(u.cap * dpr / 7));
      u.atC = pegaAtlas(U, cor);
      u.atA = pegaAtlas(U, inst.o.acento);
      var g = u.atC.g;
      u.dx = Math.round((u.x + u.w / 2 - ox) * dpr - (5 * U - g) / 2);
      u.dy = Math.round((u.base - oy) * dpr) - 7 * U + g;
    }
  }

  // o highlight esconde (só na pintura) as letras que ainda não assentaram
  function ocultar(inst) {
    for (var i = 0; i < inst.unidades.length; i++) {
      var u = inst.unidades[i], quer = !u.fora && !u.pronta;
      if (quer && !u.oculta) { HL.add(u.rg); u.oculta = true; }
      else if (!quer && u.oculta) { HL.delete(u.rg); u.oculta = false; }
    }
  }

  // grifo do <mark>: some ao armar e se desenha da esquerda para a direita junto com as letras
  var voltasPendentes = new Map();   // <mark> -> função que devolve o estilo original (fim da transição)
  function prepararGrifos(inst) {
    for (var i = 0; i < inst.marcasMed.length; i++) {
      var mm2 = inst.marcasMed[i];
      if (!mm2.bi || mm2.bi === 'none' || mm2.bs.indexOf(',') >= 0) continue;
      var partes = mm2.bs.trim().split(/\s+/);
      if (partes.length !== 2) continue;
      var m = mm2.m;
      if (voltasPendentes.has(m)) voltasPendentes.get(m)();
      inst.marcas.push({ m: m, bs0: m.style.backgroundSize, tr0: m.style.transition, st0: m.hasAttribute('style'), alvo: mm2.bs, alt: partes[1], ini: 0, dur: 1, foi: false, fimEm: 0 });
      m.style.transition = 'none';
      m.style.backgroundSize = '0% ' + partes[1];
    }
    inst.marcasMed = [];
  }
  function semStyleVazio(el, tinha) { if (!tinha && el.getAttribute('style') === '') el.removeAttribute('style'); }

  function desenhar(inst, t) {
    var c = inst.ctx;
    if (!c) return;
    c.clearRect(0, 0, inst.cv.width, inst.cv.height);
    var A = inst.alfa, us = inst.unidades, fr = inst.frente, i, u;
    // o cursor laranja: em cada linha, a letra que acabou de entrar na onda
    for (i = 0; i < fr.length; i++) fr[i] = -1;
    for (i = 0; i < us.length; i++) {
      u = us[i];
      if (u.fora || u.pronta || t < u.a) continue;
      if (fr[u.li] < 0 || us[fr[u.li]].a <= u.a) fr[u.li] = i;
    }
    // desenha toda letra ainda escondida (a que já ficou pronta segura o último sinal até a próxima leva)
    for (i = 0; i < us.length; i++) {
      u = us[i];
      if (u.fora || !u.atC || !(inst.espera || u.oculta)) continue;
      var g, at, al, d = t - u.a;
      if (d < 0) { g = PONTO; at = u.atC; al = A.ponto; }                       // esperando a onda
      else {                                                                     // em código
        g = u.seq[Math.min(u.seq.length - 1, Math.floor(d / u.s * u.seq.length))];
        if (fr[u.li] === i) { at = u.atA; al = A.acende; } else { at = u.atC; al = A.sinal; }
      }
      c.globalAlpha = al;
      c.drawImage(at.c, g * at.cw, 0, at.cw, at.ch, u.dx, u.dy, at.cw, at.ch);
    }
    c.globalAlpha = 1;
  }

  // esperando a onda: o texto some pela classe (custo zero por quadro) e o canvas mostra os quadradinhos
  function esperar(inst, sim) {
    if (sim === !!inst.espera) return;
    inst.espera = sim;
    inst.el.classList.toggle('lcd-espera', sim);
    if (!sim && !inst.el.classList.length) inst.el.removeAttribute('class');
  }

  function armar(inst) {
    for (var i = 0; i < inst.unidades.length; i++) inst.unidades[i].pronta = false;
    prepararGrifos(inst);
    planejar(inst);
    montar(inst);
    esperar(inst, true);
    desenhar(inst, -1);
    inst.estado = 'armado';
    if (ro) ro.observe(inst.el);
  }

  // na hora de animar: as letras passam para o highlight (a pontuação aparece) no mesmo quadro em que a classe sai
  function acordar(inst) {
    ocultar(inst);
    esperar(inst, false);
    if (inst.cv) inst.cv.classList.add('lcd-viva');
  }

  function limpar(inst, imediato) {
    for (var i = 0; i < inst.unidades.length; i++) { var u = inst.unidades[i]; if (u.oculta) { HL.delete(u.rg); u.oculta = false; } u.pronta = true; }
    esperar(inst, false);
    if (inst.cv) {
      if (inst.cv.parentNode) inst.cv.parentNode.removeChild(inst.cv);
      inst.cv.width = inst.cv.height = 0;                       // libera a memória do canvas
      inst.cv = null; inst.ctx = null;
    }
    if (inst.pos !== null) { inst.el.style.position = inst.pos; semStyleVazio(inst.el, inst.posSt); inst.pos = null; }
    var agora = performance.now();
    inst.marcas.forEach(function (mk) {
      var volta = function () {
        if (voltasPendentes.get(mk.m) === volta) voltasPendentes.delete(mk.m);
        mk.m.style.transition = mk.tr0; mk.m.style.backgroundSize = mk.bs0; semStyleVazio(mk.m, mk.st0);
      };
      if (!imediato && mk.foi && mk.fimEm > agora) {   // deixa o grifo terminar de correr
        voltasPendentes.set(mk.m, volta);
        setTimeout(function () { if (voltasPendentes.get(mk.m) === volta) volta(); }, mk.fimEm - agora + 60);
      } else volta();
    });
    inst.marcas = [];
  }

  function soltar(inst) {
    if (inst.planoB) { clearTimeout(inst.planoB); inst.planoB = 0; }
    if (ioArma) ioArma.unobserve(inst.el);
    if (ioDispara) ioDispara.unobserve(inst.el);
    if (ioVisto) ioVisto.unobserve(inst.el);
    if (ro) ro.unobserve(inst.el);
  }
  function encerrar(inst) { rodando.delete(inst); limpar(inst, true); inst.estado = 'feito'; soltar(inst); }    // na hora
  function concluir(inst) { rodando.delete(inst); limpar(inst, false); inst.estado = 'feito'; soltar(inst); }   // fim natural

  // um quadro de uma instância rodando (t em ms desde o disparo)
  function passo(inst) {
    var t = inst.t, vivas = 0, prontas = 0, i, u;
    for (i = 0; i < inst.unidades.length; i++) {
      u = inst.unidades[i];
      if (u.fora || !u.oculta) continue;
      if (u.pronta || t >= u.a + u.s) { u.pronta = true; prontas++; } else vivas++;
    }
    // revela as prontas em leva (uma mudança no highlight a cada AJ.lote ms, e a última no fim)
    if (prontas && (!vivas || t - inst.leva >= (toque() ? AJ.loteToque : AJ.lote))) {
      for (i = 0; i < inst.unidades.length; i++) {
        u = inst.unidades[i];
        if (u.oculta && u.pronta) { HL.delete(u.rg); u.oculta = false; }
      }
      inst.leva = t; prontas = 0;
    }
    for (i = 0; i < inst.marcas.length; i++) {
      var mk = inst.marcas[i];
      if (!mk.foi && t >= mk.ini) {
        var resto = Math.max(1, mk.dur - (t - mk.ini));
        mk.m.style.transition = 'background-size ' + Math.round(resto) + 'ms cubic-bezier(.25,.6,.3,1)';
        mk.m.style.backgroundSize = mk.alvo;
        mk.foi = true; mk.fimEm = performance.now() + resto;
      }
    }
    if (vivas || prontas) desenhar(inst, t); else concluir(inst);
  }

  function laco(agora) {
    raf = 0;
    var t0 = performance.now();
    var dt = ultimo ? Math.min(100, Math.max(0, agora - ultimo)) : 16.7;   // aba escondida/engasgo: continua de onde parou
    ultimo = agora; inicioQuadro = t0;
    rodando.forEach(function (inst) { inst.t += dt; if (inst.t >= 0) passo(inst); });
    var gasto = performance.now() - t0;
    est.quadros++; est.soma += gasto; if (gasto > est.max) est.max = gasto;
    est.ult[(est.quadros - 1) % est.ult.length] = gasto;
    if (rodando.size && !doc.hidden) agenda(); else ultimo = 0;
  }
  // o próximo quadro: no computador, o seguinte; no celular, ~33 ms depois (metade dos quadros para o navegador pintar)
  var adiado = 0, inicioQuadro = 0;
  function agenda() {
    if (raf || adiado) return;
    var falta = toque() && inicioQuadro ? AJ.passoToque - (performance.now() - inicioQuadro) - 12 : 0;
    if (falta <= 0) raf = requestAnimationFrame(laco);
    else adiado = setTimeout(function () { adiado = 0; if (rodando.size && !doc.hidden) raf = requestAnimationFrame(laco); }, falta);
  }
  function acorda() { if (rodando.size && !raf && !adiado && !doc.hidden) { ultimo = 0; inicioQuadro = 0; agenda(); } }
  function dorme() { if (raf) { cancelAnimationFrame(raf); raf = 0; } if (adiado) { clearTimeout(adiado); adiado = 0; } ultimo = 0; }

  function disparar(lote) {
    var ok = lote.map(medir);                              // leituras primeiro
    lote.forEach(function (inst, i) {                      // depois escritas
      if (inst.planoB) { clearTimeout(inst.planoB); inst.planoB = 0; }
      if (!ok[i]) { encerrar(inst); return; }
      planejar(inst); montar(inst); acordar(inst);
      desenhar(inst, -1);
      inst.t = -inst.o.atraso;
      inst.leva = 0;
      inst.estado = 'rodando';
      rodando.add(inst);
    });
    acorda();
  }

  /* ------------------------------------------------------------------ */
  /* Observadores                                                         */
  /* ------------------------------------------------------------------ */
  function visivelAgora(r) {
    var vh = window.innerHeight || doc.documentElement.clientHeight, vw = window.innerWidth || doc.documentElement.clientWidth;
    return r.bottom > 0 && r.right > 0 && r.top < vh && r.left < vw;
  }

  // perto da tela (~0,6 tela antes): esconde as letras e põe os pontos. Se já está à vista, fica como está.
  function aoArmar(es) {
    var lote = [];
    es.forEach(function (e) { var inst = mapa.get(e.target); if (inst && inst.estado === 'novo' && e.isIntersecting) lote.push(inst); });
    if (!lote.length) return;
    var vis = lote.map(function (inst) { return visivelAgora(inst.el.getBoundingClientRect()); });
    var med = lote.map(function (inst, i) { return vis[i] ? false : medir(inst); });
    lote.forEach(function (inst, i) { if (vis[i] || !med[i]) encerrar(inst); else armar(inst); });
  }

  // ~40% do elemento acima da linha de 85% da tela: dispara (antes disso ele ainda está colado na borda de baixo)
  function aoDisparar(es) {
    var lote = [];
    es.forEach(function (e) {
      var inst = mapa.get(e.target);
      if (!inst || inst.estado !== 'armado' || !e.isIntersecting) return;
      var rh = e.rootBounds ? e.rootBounds.height : window.innerHeight * 0.85;
      if (e.intersectionRatio >= inst.o.limiar - 0.001 || e.intersectionRect.height >= rh * 0.5) lote.push(inst);
    });
    if (lote.length) disparar(lote);
  }

  // a tela inteira: saiu da tela no meio = termina na hora; parado inteiro à vista abaixo da linha
  // (fim da página, sem como rolar mais) = dispara depois de AJ.parado ms
  function aoVer(es) {
    es.forEach(function (e) {
      var inst = mapa.get(e.target);
      if (!inst) return;
      var rh = e.rootBounds ? e.rootBounds.height : window.innerHeight;
      inst.inteiro = e.isIntersecting && (e.intersectionRatio >= 0.98 || e.intersectionRect.height >= rh * 0.6);
      if (inst.estado === 'rodando') { if (!e.isIntersecting) encerrar(inst); return; }
      if (inst.estado !== 'armado') return;
      if (inst.inteiro && !inst.planoB) {
        inst.planoB = setTimeout(function () { inst.planoB = 0; if (inst.estado === 'armado' && inst.inteiro) disparar([inst]); }, AJ.parado);
      } else if (!inst.inteiro && inst.planoB) { clearTimeout(inst.planoB); inst.planoB = 0; }
    });
  }

  // mudou de tamanho: armado = mede de novo; rodando = termina na hora
  function aoRedimensionar(es) {
    var lote = [];
    es.forEach(function (e) {
      var inst = mapa.get(e.target);
      if (!inst) return;
      var w = Math.round(e.contentRect.width), h = Math.round(e.contentRect.height);
      if (!inst.tam) { inst.tam = [w, h]; return; }
      if (inst.tam[0] === w && inst.tam[1] === h) return;
      inst.tam = [w, h];
      if (inst.estado === 'rodando') encerrar(inst);
      else if (inst.estado === 'armado') lote.push(inst);
    });
    if (!lote.length) return;
    var ok = lote.map(medir);
    lote.forEach(function (inst, i) {
      if (!ok[i]) { encerrar(inst); return; }
      planejar(inst); montar(inst); desenhar(inst, -1);
    });
  }

  function injetaCSS() {
    if (doc.getElementById(CSS_ID)) return;
    var s = doc.createElement('style');
    s.id = CSS_ID;
    s.textContent =
      // rodando: só as letras que faltam ficam transparentes (a pontuação fica)
      '::highlight(' + NOME + '){color:transparent;-webkit-text-fill-color:transparent;text-shadow:none}' +
      // esperando a onda: o texto todo transparente por classe (o highlight custa uma repintura a cada quadro em que
      // algo da página muda de estilo, então ele só entra durante a animação)
      '.lcd-espera,.lcd-espera *{color:transparent!important;-webkit-text-fill-color:transparent!important;' +
      'text-shadow:none!important;text-decoration-color:transparent!important}' +
      '.lcd-camada{position:absolute;display:block;margin:0;padding:0;border:0;max-width:none;pointer-events:none;' +
      '-webkit-user-select:none;user-select:none}' +
      '.lcd-camada.lcd-viva{will-change:transform}' +          // camada própria só enquanto anima
      '@media print{.lcd-camada{display:none}}';                // (e o beforeprint revela tudo)
    (doc.head || doc.documentElement).appendChild(s);
  }

  function revelarTodos() { mapa.forEach(function (inst) { if (inst.estado !== 'feito') encerrar(inst); }); }

  function pronto() {
    if (!temHL || !temIO || quieto()) return false;
    if (ioArma) return true;
    injetaCSS();
    HL = new Highlight();
    CSS.highlights.set(NOME, HL);
    ioArma = new IntersectionObserver(aoArmar, { rootMargin: AJ.zona, threshold: 0 });
    ioDispara = new IntersectionObserver(aoDisparar, { rootMargin: AJ.linha, threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1] });
    ioVisto = new IntersectionObserver(aoVer, { threshold: [0, 0.25, 0.5, 0.75, 0.98, 1] });
    if ('ResizeObserver' in window) ro = new ResizeObserver(aoRedimensionar);
    doc.addEventListener('visibilitychange', function () { if (doc.hidden) dorme(); else acorda(); });
    window.addEventListener('beforeprint', revelarTodos);
    var muda = function () { if (quieto()) revelarTodos(); };
    [mqCalmo, mqForcado].forEach(function (q) { if (q) { if (q.addEventListener) q.addEventListener('change', muda); else if (q.addListener) q.addListener(muda); } });
    return true;
  }

  function iniciar(raiz) {
    if (!pronto()) return 0;
    var n = 0;
    (raiz || doc).querySelectorAll('[data-decode]').forEach(function (el) {
      if (mapa.has(el)) return;
      var inst = registrar(el);
      n++;
      if (!inst.unidades.length) { inst.estado = 'feito'; return; }
      ioArma.observe(el);
      ioDispara.observe(el);
      ioVisto.observe(el);
    });
    return n;
  }

  /* ------------------------------------------------------------------ */
  /* À mão (demo e conferência)                                          */
  /* ------------------------------------------------------------------ */
  function reiniciar(el) {
    var inst = registrar(el);
    encerrar(inst);
    inst.unidades = coletar(el);
    inst.estado = 'novo'; inst.tam = null;
    if (!medir(inst)) { encerrar(inst); return null; }
    armar(inst);
    return inst;
  }
  function rodar(el) {
    if (!pronto() || !el) return false;
    var inst = reiniciar(el);
    if (!inst) return false;
    disparar([inst]);
    ioVisto.observe(el);             // saiu da tela no meio: termina na hora
    return true;
  }
  function quadro(el, ms) {
    if (!pronto() || !el) return false;
    var inst = mapa.get(el);
    if (!inst || inst.estado !== 'congelado') {
      inst = reiniciar(el);
      if (!inst) return false;
      soltar(inst);
      inst.estado = 'congelado';
    }
    var t = ms, i;
    for (i = 0; i < inst.unidades.length; i++) { var u = inst.unidades[i]; u.pronta = !u.fora && t >= u.a + u.s; }
    if (t < 0) {                                   // antes da onda: o estado de espera de verdade (classe)
      for (i = 0; i < inst.unidades.length; i++) inst.unidades[i].pronta = true;
      ocultar(inst);
      for (i = 0; i < inst.unidades.length; i++) inst.unidades[i].pronta = false;
      esperar(inst, true);
      if (inst.cv) inst.cv.classList.remove('lcd-viva');
    } else acordar(inst);
    for (i = 0; i < inst.marcas.length; i++) {
      var mk = inst.marcas[i], p = Math.max(0, Math.min(1, (t - mk.ini) / mk.dur)), e = 1 - (1 - p) * (1 - p);
      mk.m.style.transition = 'none';
      mk.m.style.backgroundSize = p >= 1 ? mk.alvo : (e * 100).toFixed(2) + '% ' + mk.alt;
    }
    inst.t = t;
    desenhar(inst, t);
    return true;
  }

  window.LCDecode = {
    iniciar: iniciar,
    rodar: rodar,
    quadro: quadro,
    revelar: function (el) { var inst = mapa.get(el); if (inst && inst.estado !== 'feito') encerrar(inst); },
    revelarTodos: revelarTodos,
    estado: function (el) {
      var inst = mapa.get(el);
      if (!inst) return null;
      var oc = 0, hl = 0;
      inst.unidades.forEach(function (u) { if (u.oculta) hl++; if (u.oculta || (inst.espera && !u.fora)) oc++; });
      return { estado: inst.estado, letras: inst.unidades.length, ocultas: oc, noHighlight: hl, espera: !!inst.espera, canvas: inst.cv ? inst.cv.width + 'x' + inst.cv.height : null, t: Math.round(inst.t) };
    },
    stats: function (zerar) {
      var n = Math.min(est.quadros, est.ult.length), v = Array.prototype.slice.call(est.ult, 0, n).sort(function (a, b) { return a - b; });
      var r = { quadros: est.quadros, mediaMs: est.quadros ? +(est.soma / est.quadros).toFixed(3) : 0, p95Ms: n ? +v[Math.floor(n * 0.95)].toFixed(3) : 0, maxMs: +est.max.toFixed(3), rodando: rodando.size };
      if (zerar) { est.quadros = 0; est.soma = 0; est.max = 0; est.ult.fill(0); }
      return r;
    },
    get instancias() { return Array.from(mapa.values()); }
  };

  if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', function () { iniciar(); });
  else iniciar();
})();
