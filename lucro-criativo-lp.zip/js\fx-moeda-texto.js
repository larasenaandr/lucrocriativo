/*
  fx-moeda-texto.js · moeda no meio do texto (Imersão Lucro Criativo · Koko)
  Direção de arte: Lara Sena · 26/11/2026 · referência _refs/pins/5_moeda.mp4, bem mais sutil

  O que faz
  - Põe a moeda da logo (19x19 quadrados, do motor js/logo.js) num vão dentro de uma frase grande.
    Enquanto a moeda atravessa a tela, ela dá uma volta no eixo vertical: moeda azul de frente,
    borda fininha (90°), faísca laranja (180°), borda (270°) e moeda de novo (360°).
  - A volta segue a rolagem, com uma inércia curta. Ela entra de frente, vira a faísca antes do meio da
    tela, fica na faísca enquanto a frase é lida e volta a ser moeda antes de sair por cima. Nas faces
    ela fica parada (é a logo, quadrados encostados); no giro, sai devagar da face e passa rápido pela
    borda, com os quadrados do motor (de tamanhos variados e, a partir de 5 px, com o vão da grade).
    Moeda pequena (quadrado abaixo de 5 px) gira com quadrado inteiro ou nada, para não sujar.
  - Desempenho: um canvas pequeno, redesenhado só quando o ângulo muda (de 2 em 2° na moeda do texto).
    Cada quadro do giro é calculado uma vez com a mesma conta do LCLogo.frameSVG (conferida contra ele)
    e fica guardado; a volta inteira é preparada em tempo ocioso quando a moeda chega a 1,5 tela de
    distância. Pausa fora da tela (IntersectionObserver) e com a aba escondida; rolagem com listener
    passivo; uma leitura de layout por quadro, antes de qualquer escrita; devicePixelRatio limitado a 2;
    ResizeObserver para o tamanho (quadrados nítidos, em pixel inteiro).
  - prefers-reduced-motion: a moeda fica parada, de frente, sem ouvir a rolagem.
  - Acessível: o texto continua inteiro no HTML; o vão e o canvas ficam com aria-hidden.
  - O vão não muda a altura da linha (a caixa de margem dele cabe na linha). O CSS vem deste arquivo
    (<style id="fx-moeda-texto-css">); sem o LCLogo, nada é injetado e o vão fica fechado.

  Uso
    <p class="frase" data-moeda-texto>Na mão do seu cliente, a IA faz um post.
      <span class="moeda-vao" aria-hidden="true"></span> <mark>Na sua, vira um serviço que ele paga todo mês.</mark></p>
    <script src="js/logo-data.js" defer></script>
    <script src="js/logo.js" defer></script>
    <script src="js/fx-moeda-texto.js" defer></script>
  Opções no elemento com data-moeda-texto (todas opcionais):
    data-moeda-voltas   voltas enquanto a moeda atravessa a tela, de meia em meia (padrão 1; 0.5 termina na faísca)
    data-moeda-cor      cor da moeda e da borda       (padrão #0100FE)
    data-moeda-faisca   cor da faísca                 (padrão #FF5A1F)
    data-moeda-forma    outro lado: faísca ✢ ✳ ✶ ✻ ✽  (padrão faísca)
  Tamanho: --moeda-tam no .moeda-vao ou num pai (padrão 1.05em; acima de ~1.1em a moeda começa a
  encostar nas descendentes da linha de cima).

  Reuso
    LCMoedaTexto.desenha(canvas, angulo[, opcoes]) desenha a moeda num canvas qualquer, no ângulo dado
    (0 = moeda, 90 = borda, 180 = faísca, 360 = moeda). Só redesenha se algo mudou. O canvas precisa ter
    tamanho pelo CSS, ou passe largura/altura em px CSS (aí não lê o layout). Opções:
      cor, faisca, forma, fundo (padrão transparente), escala (fração do lado menor que a moeda ocupa,
      padrão 1), largura, altura, passo (grau do cache; padrão 1°, ou 0,5° em moeda grande),
      cheio (quadrados encostados; padrão: só nas faces, 0° e 180°).
    LCMoedaTexto.quadro(grau, forma) devolve os quadrados de um ângulo num Uint8Array de 4 em 4:
      [u+16, v+16, lado (0 moeda/borda, 1 faísca), tamanho do quadrado de 0 a 255].
*/
(function () {
  'use strict';
  if (window.LCMoedaTexto) return;

  var AZUL = '#0100FE', LARANJA = '#FF5A1F';
  var CSS_ID = 'fx-moeda-texto-css';
  var N = 19;                 // a moeda tem 19x19 quadrados
  var TAU = 90;               // ms: inércia do giro atrás da rolagem
  var FAIXA = [0.96, 0.04];   // a volta começa com o centro da moeda a 96% da altura da tela e termina a 4%
  var PARADA = 0.18;          // em cada meia-volta, a fração do caminho em que ela fica parada na face (cada ponta)
  var CSS =
    '.moeda-vao{position:relative;display:inline-block;width:var(--moeda-tam,1.05em);height:var(--moeda-tam,1.05em);' +
    'margin:calc((.85em - var(--moeda-tam,1.05em)) / 2) .02em;vertical-align:-.105em;line-height:0;' +
    'pointer-events:none;-webkit-user-select:none;user-select:none}' +
    '.moeda-vao>canvas{position:absolute;left:0;top:0;width:100%;height:100%;display:block}';
  /* a conta do vão: a caixa de margem tem .85em e vai de -.105em a +.745em da linha de base, dentro da
     linha (cabe em line-height a partir de ~.95; a .frase usa 1.1), então a altura da linha não muda.
     A moeda (1.05em) fica centrada a .32em acima da base, entre o meio da altura-x e o meio da
     maiúscula, e passa .1em para cima e para baixo da caixa sem empurrar nada. */

  /* ---------------- motor da logo ---------------- */
  var L = null, CC, GX, GY, CW, R = 9.4, MOEDA = null;
  function prepara() {
    if (L) return true;
    var lc = window.LCLogo;
    if (!lc || typeof lc.frameSVG !== 'function' || !lc.grid || !lc.coinCenter) return false;
    L = lc; CC = lc.coinCenter; GX = lc.grid.px; GY = lc.grid.py; CW = GX * lc.grid.sq;
    var d = lc.data && lc.data.coin;
    if (d && d.cells && d.r) {
      R = d.r; MOEDA = new Uint8Array(21 * 21);
      d.cells.forEach(function (c) { if (Math.abs(c[0]) <= 10 && Math.abs(c[1]) <= 10) MOEDA[(c[0] + 10) * 21 + c[1] + 10] = 1; });
      confereDepois();
    } else rapido = false;
    return true;
  }

  /* quadros do giro (Uint8Array de 4 em 4: u+16, v+16, lado 0 moeda/borda 1 faísca, tamanho 0..255).
     Caminho lento: LCLogo.frameSVG (o motor da logo: ~4 ms por ângulo no desktop e 25 ms ou mais com a
     CPU 6x mais lenta, porque refaz a trigonometria de cada raio da faísca a cada amostra e monta um SVG em texto).
     Caminho rápido: a mesma conta do cover()/frameSVG do logo.js (mesma moeda do logo-data.js, mesmas
     formas, mesma espessura, mesmas amostras 3x3 e mesmos cortes), com os raios calculados uma vez e
     distâncias ao quadrado: ~0,2 ms (conferido igual ao frameSVG nas 6 formas, em 360 graus inteiros e 720
     quebrados). Depois que a página carrega, ele é conferido de novo contra o frameSVG em 3 ângulos, em tempo
     ocioso; se o logo.js mudar e os dois divergirem, volta ao frameSVG. */
  var T = 1.6;                                           // espessura da moeda (logo.js)
  var FORMAS = {                                         // formas do verso (SHAPES do logo.js)
    '✢': { n: 4, len: [.86, .86, .86, .86], jit: [0, 0, 0, 0], hw: 1.05, hub: 1.8, tip: [1.25, .62] },
    '✳': { n: 8, len: [.94, .94, .94, .94, .94, .94, .94, .94], jit: [0, 0, 0, 0, 0, 0, 0, 0], hw: .6, hub: 1.4 },
    '✶': { n: 6, len: [.98, .98, .98, .98, .98, .98], jit: [0, 0, 0, 0, 0, 0], hw: .95, hub: 2.4 },
    '✻': { n: 8, len: [.7, .7, .7, .7, .7, .7, .7, .7], jit: [22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5], hw: .42, hub: 1.2, tip: [1.25, .78] },
    '✽': { n: 8, len: [.9, .9, .9, .9, .9, .9, .9, .9], jit: [0, 0, 0, 0, 0, 0, 0, 0], hw: .78, hub: 1.6, tip: [1.0, .9] },
    'faísca': { n: 11, len: [1, .855, .942, .797, .913, .841, .768, .957, .826, .899, .783], jit: [0, 4, -3, 5, -2, 3, -4, 2, -1, -3, 3], hw: .62, hub: 1.7 }
  };
  var SUB = [-1 / 3, 0, 1 / 3], POOL = [], rapido = true, compiladas = {};
  for (var pu = -10; pu <= 10; pu++) for (var pv = -10; pv <= 10; pv++) if (Math.hypot(pu, pv) <= 10.8) POOL.push(pu, pv);

  function compila(nome) {
    if (compiladas[nome]) return compiladas[nome];
    var sh = FORMAS[nome], raios = [];
    for (var n = 0; n < sh.n; n++) {
      var a = (n * 360 / sh.n + sh.jit[n] - 90 + 0) * Math.PI / 180, l = sh.len[n] * R;
      var ex = Math.cos(a) * l, ey = Math.sin(a) * l;
      raios.push(ex, ey, l * l, sh.tip ? ex * sh.tip[1] : 0, sh.tip ? ey * sh.tip[1] : 0);
    }
    return (compiladas[nome] = { fora: (R + .5) * (R + .5), hub: sh.hub * sh.hub, hw: sh.hw * sh.hw, tip: sh.tip ? sh.tip[0] * sh.tip[0] : -1, raios: raios });
  }
  function naFaisca(f, x, y) {                           // sparkHit(sh, x, y, 0)
    var d = x * x + y * y;
    if (d > f.fora) return false;
    if (d <= f.hub) return true;
    var r = f.raios;
    for (var i = 0; i < r.length; i += 5) {
      var ex = r[i], ey = r[i + 1], t = (x * ex + y * ey) / r[i + 2];
      t = t < 0 ? 0 : t > 1 ? 1 : t;
      var dx = x - t * ex, dy = y - t * ey;
      if (dx * dx + dy * dy <= f.hw) return true;
      if (f.tip >= 0) { dx = x - r[i + 3]; dy = y - r[i + 4]; if (dx * dx + dy * dy <= f.tip) return true; }
    }
    return false;
  }
  function naMoeda(u, v) { return u >= -10 && u <= 10 && v >= -10 && v <= 10 && MOEDA[(u + 10) * 21 + v + 10] === 1; }

  var tipo = 0;
  function cobre(u, v, c, s, f) {                        // cover(u, v, a, shape, 0); o lado fica em `tipo`
    var k = 0, ac = 0, RR = R * R;
    for (var i = 0; i < 3; i++) for (var j = 0; j < 3; j++) {
      var x = u + SUB[i], y = v + SUB[j];
      if (y * y > RR) continue;
      var ry = Math.sqrt(RR - y * y), hit = 0;
      if (Math.abs(c) > .02) {
        var zf = c > 0 ? T / 2 : -T / 2, xo = (x - zf * s) / c;
        if (xo * xo + y * y <= RR) {
          if (c > 0) { if (naMoeda(Math.round(xo), Math.round(y))) hit = 1; }
          else if (naFaisca(f, -xo, y)) hit = 2;
        }
      }
      if (!hit) {
        var w = (T / 2) * Math.abs(s);
        if (w > .02 && (Math.abs(x - ry * c) <= w || Math.abs(x + ry * c) <= w)) hit = 1;
      }
      if (hit === 1) k++; else if (hit === 2) ac++;
    }
    if (ac > k) { tipo = 1; return ac / 9; }
    tipo = 0; return k / 9;
  }

  function quadroRapido(a, forma) {                     // frameSVG(a, forma), sem o SVG
    var f = compila(FORMAS[forma] ? forma : 'faísca');
    var ar = a * Math.PI / 180, c = Math.cos(ar), s = Math.sin(ar), plano = a % 180 === 0, out = [];
    for (var p = 0; p < POOL.length; p += 2) {
      var u = POOL[p], v = POOL[p + 1], cov, lado;
      if (a === 0) { cov = naMoeda(u, v) ? 1 : 0; lado = 0; } else { cov = cobre(u, v, c, s, f); lado = tipo; }
      if (plano ? cov < .5 : cov < .12) continue;
      out.push(u + 16, v + 16, lado, Math.round((plano ? 1 : Math.sqrt(cov)) * 255));
    }
    return new Uint8Array(out);
  }

  var RX = /<rect x="(-?[\d.]+)" y="(-?[\d.]+)" width="([\d.]+)" height="([\d.]+)"\/>/g;
  function quadroSVG(a, forma) {                         // o mesmo quadro, lido do SVG do motor
    var svg = L.frameSVG(a, forma), corte = svg.indexOf('class="fa"'), out = [], m, w;
    RX.lastIndex = 0;
    while ((m = RX.exec(svg))) {
      w = +m[3];
      out.push(
        Math.round((+m[1] + w / 2 - CC[0]) / GX) + 16,
        Math.round((+m[2] + +m[4] / 2 - CC[1]) / GY) + 16,
        m.index > corte ? 1 : 0,
        Math.round(Math.min(1, w / CW) * 255));
    }
    return new Uint8Array(out);
  }

  var cache = new Map(), CACHE_MAX = 900;
  var est = { quadros: 0, quadroMs: 0, quadroMax: 0, calculos: 0, calculoMs: 0, calculoMax: 0, leituraMs: 0, leituraMax: 0, pinturas: 0, pinturaMs: 0, pinturaMax: 0 };
  function quadro(grau, forma) {
    var chave = forma + grau, f = cache.get(chave);
    if (f) return f;
    var t0 = performance.now();
    f = rapido ? quadroRapido(grau, forma) : quadroSVG(grau, FORMAS[forma] ? forma : 'faísca');
    if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value);
    cache.set(chave, f);
    var ms = performance.now() - t0;
    est.calculos++; est.calculoMs += ms; if (ms > est.calculoMax) est.calculoMax = ms;
    return f;
  }

  /* confere o caminho rápido contra o frameSVG: mesmos quadrados, mesmo lado, tamanho até ±3/255 */
  function confere(formas, angulos) {
    var difs = 0, total = 0;
    (formas || ['faísca']).forEach(function (forma) {
      (angulos || [0, 37, 90, 143, 180, 211, 300]).forEach(function (a) {
        var A = quadroSVG(a, forma), B = quadroRapido(a, forma), mapa = {};
        total++;
        for (var i = 0; i < A.length; i += 4) mapa[A[i] * 64 + A[i + 1]] = [A[i + 2], A[i + 3]];
        var igual = A.length === B.length;
        for (var j = 0; igual && j < B.length; j += 4) {
          var e = mapa[B[j] * 64 + B[j + 1]];
          if (!e || e[0] !== B[j + 2] || Math.abs(e[1] - B[j + 3]) > 3) igual = false;
        }
        if (!igual) difs++;
      });
    });
    return { quadros: total, diferentes: difs };
  }
  // em tempo ocioso, um ângulo por vez (no celular fraco cada conferência leva ~25 ms)
  function ocioso(f) { if (window.requestIdleCallback) requestIdleCallback(f, { timeout: 4000 }); else setTimeout(f, 60); }
  var conferePendente = false;
  function confereDepois() {
    var angs = [180, 143, 37];
    var vai = function () {
      if (!rapido || !L || !angs.length) return;
      if (reduz) { conferePendente = true; return; }        // parada de frente não usa o giro
      conferePendente = false;
      if (confere(['faísca'], [angs.shift()]).diferentes) {
        rapido = false; cache.clear();
        lista.forEach(function (m) { m.grau = NaN; m.aquecido = false; });
        sujo = true; agenda();
        return;
      }
      if (angs.length) ocioso(vai);
    };
    ocioso(vai);
  }

  /* deixa prontos, em tempo ocioso, os quadros de uma volta inteira (quando a moeda chega perto da tela) */
  function aquece(m) {
    if (m.aquecido || reduz || !m.W) return;
    m.aquecido = true;
    var angs = [];
    for (var a = m.passo; a < 360; a += m.passo) angs.push(a);
    var vai = function (prazo) {
      var t0 = performance.now();
      while (angs.length && m.aquecido) {
        quadro(angs.shift(), m.forma);
        if (prazo && prazo.timeRemaining ? prazo.timeRemaining() < 3 : performance.now() - t0 > 4) break;
      }
      if (angs.length && m.aquecido) ocioso(vai);
    };
    ocioso(vai);
  }

  function quantiza(a, passo) {
    var g = (Math.round(a / passo) * passo) % 360;
    if (g < 0) g += 360;
    return Math.round(g * 100) / 100;
  }

  /* pinta um quadro num canvas de W x H pixels. Quadrado de 2 px ou mais: bordas em pixel inteiro
     (nítido, encostado sem fresta). Girando: vão da grade a partir de 5 px; abaixo disso, quadrado
     inteiro ou nada (meio quadrado de 1 px vira sujeira). */
  function pinta(ctx, W, H, f, cor, faisca, cheio, escala, fundo) {
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    if (fundo) { ctx.fillStyle = fundo; ctx.fillRect(0, 0, W, H); } else ctx.clearRect(0, 0, W, H);
    var c = Math.min(W, H) * (escala || 1) / N;
    if (!(c > 0)) return;
    var ox = (W - N * c) / 2, oy = (H - N * c) / 2;
    var vao = cheio ? 0 : (c >= 5 ? Math.floor(c * 0.15 + 0.25) : 0);
    var binario = !cheio && c < 5, lado = c - vao, encaixa = c >= 2, ini = 9.5 - 16;
    for (var p = 0; p < 2; p++) {
      ctx.fillStyle = p ? faisca : cor;
      for (var i = 0; i < f.length; i += 4) {
        if (f[i + 2] !== p) continue;
        var q = f[i + 3] / 255;
        if (binario) { if (q < 0.7) continue; q = 1; }
        var s = lado * q / 2, cx = ox + (f[i] + ini) * c, cy = oy + (f[i + 1] + ini) * c;
        var x0 = cx - s, y0 = cy - s, x1 = cx + s, y1 = cy + s;
        if (encaixa) { x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1); }
        if (x1 > x0 && y1 > y0) ctx.fillRect(x0, y0, x1 - x0, y1 - y0);
      }
    }
  }
  /* ---------------- reuso: desenha(canvas, angulo, opcoes) ---------------- */
  var ultimo = new WeakMap();
  function desenha(canvas, angulo, op) {
    if (!canvas || !canvas.getContext || !prepara()) return false;
    op = op || {};
    var ctx = canvas.getContext('2d');
    if (!ctx) return false;
    var dpr = Math.min(2, window.devicePixelRatio || 1), cw = +op.largura || 0, ch = +op.altura || 0;
    if (!cw) {
      var r = canvas.getBoundingClientRect();
      // canvas sem tamanho no CSS: congela o tamanho de agora, senão ele cresceria a cada desenho
      if (!canvas.style.width && Math.round(r.width) === canvas.width && Math.round(r.height) === canvas.height) {
        canvas.style.width = r.width + 'px'; canvas.style.height = r.height + 'px';
      }
      cw = r.width; ch = ch || r.height;
    }
    ch = ch || cw;
    var W = Math.max(1, Math.round(cw * dpr)), H = Math.max(1, Math.round(ch * dpr));
    var forma = op.forma || 'faísca', escala = +op.escala || 1, cor = op.cor || AZUL, fa = op.faisca || LARANJA;
    var passo = +op.passo || (Math.min(W, H) * escala / N >= 12 ? 0.5 : 1);
    var g = quantiza(+angulo || 0, passo), cheio = op.cheio != null ? !!op.cheio : g % 180 === 0;
    if (canvas.width !== W || canvas.height !== H) { canvas.width = W; canvas.height = H; ultimo.delete(canvas); }
    var chave = [g, forma, W, H, cor, fa, cheio ? 1 : 0, op.fundo || '', escala].join('|');
    if (ultimo.get(canvas) === chave) return true;
    ultimo.set(canvas, chave);
    pinta(ctx, W, H, quadro(g, forma), cor, fa, cheio, escala, op.fundo);
    return true;
  }

  /* ---------------- moeda no texto ---------------- */
  var lista = [], porVao = new WeakMap(), porCanvas = new WeakMap();
  var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var reduz = !!(mq && mq.matches);
  var raf = 0, ultimoT = 0, sujo = true, ouvindo = false, io = null, ioPerto = null, ro = null, globais = false;

  /* ângulo pela posição do centro da moeda na tela (y, em px da janela) */
  function anguloDe(y, vh, voltas) {
    var a = vh * FAIXA[0], b = vh * FAIXA[1], p = (a - y) / (a - b);
    p = p < 0 ? 0 : p > 1 ? 1 : p;
    var s = p * 2 * voltas, k = Math.floor(s), x;
    if (k >= 2 * voltas) return 360 * voltas;
    x = (s - k - PARADA) / (1 - 2 * PARADA);
    x = x < 0 ? 0 : x > 1 ? 1 : x;
    return 180 * (k + x * x * (3 - 2 * x));   // parada na face, sai devagar, passa rápido pela borda
  }

  function pintaInst(m, grau) {
    if (!m.W || !m.H) return;
    var f = quadro(grau, m.forma), t0 = performance.now();
    pinta(m.ctx, m.W, m.H, f, m.cor, m.faisca, grau % 180 === 0, 1, null);
    var ms = performance.now() - t0;
    est.pinturas++; est.pinturaMs += ms; if (ms > est.pinturaMax) est.pinturaMax = ms;
    m.grau = grau; m.desenhos++;
  }

  function injetaCSS() {
    if (document.getElementById(CSS_ID)) return;
    var s = document.createElement('style');
    s.id = CSS_ID; s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  function cria(vao, dono) {
    if (porVao.has(vao)) return null;
    var cv = document.createElement('canvas'), ctx = cv.getContext && cv.getContext('2d');
    if (!ctx) return null;
    cv.setAttribute('aria-hidden', 'true');
    vao.setAttribute('aria-hidden', 'true');
    vao.appendChild(cv);
    var v = parseFloat(dono.getAttribute('data-moeda-voltas'));
    var m = {
      vao: vao, cv: cv, ctx: ctx, dono: dono,
      voltas: isFinite(v) && v > 0 ? Math.max(0.5, Math.round(v * 2) / 2) : 1,
      cor: dono.getAttribute('data-moeda-cor') || AZUL,
      faisca: dono.getAttribute('data-moeda-faisca') || LARANJA,
      forma: dono.getAttribute('data-moeda-forma') || 'faísca',
      W: 0, H: 0, passo: 1, ang: 0, alvo: 0, grau: NaN, ativo: false, pular: true, perto: false, aquecido: false, desenhos: 0
    };
    porVao.set(vao, m); porCanvas.set(cv, m);
    return m;
  }

  function agenda() { if (!raf && !reduz && !document.hidden) raf = requestAnimationFrame(anima); }

  function anima(t) {
    raf = 0;
    if (document.hidden || reduz) { ultimoT = 0; return; }
    var t0 = performance.now(), dt = ultimoT ? Math.min(64, t - ultimoT) : 1000 / 60, i, m;
    ultimoT = t;
    // 1) leituras: todas antes de qualquer escrita, e só quando a página rolou ou mudou de tamanho
    if (sujo) {
      sujo = false;
      var vh = window.innerHeight;
      for (i = 0; i < lista.length; i++) {
        m = lista[i];
        if (!m.ativo) continue;
        var r = m.vao.getBoundingClientRect();
        m.alvo = anguloDe(r.top + r.height / 2, vh, m.voltas);
      }
      var lm = performance.now() - t0;
      est.leituraMs += lm; if (lm > est.leituraMax) est.leituraMax = lm;
    }
    // 2) escritas: só pinta quando o grau muda
    var k = 1 - Math.exp(-dt / TAU), segue = false;
    for (i = 0; i < lista.length; i++) {
      m = lista[i];
      if (!m.ativo) continue;
      if (m.pular) { m.pular = false; m.ang = m.alvo; }
      else {
        var d = m.alvo - m.ang;
        m.ang = Math.abs(d) < 0.05 ? m.alvo : m.ang + d * k;
      }
      var g = quantiza(m.ang, m.passo);
      if (g !== m.grau) pintaInst(m, g);
      if (m.ang !== m.alvo) segue = true;
    }
    var ms = performance.now() - t0;
    est.quadros++; est.quadroMs += ms; if (ms > est.quadroMax) est.quadroMax = ms;
    if (segue) raf = requestAnimationFrame(anima); else ultimoT = 0;
  }

  function aoRolar() { sujo = true; agenda(); }
  function aoRedimensionarJanela() { if (ouvindo) { sujo = true; agenda(); } }

  function atualizaOuvinte() {
    var algum = false;
    for (var i = 0; i < lista.length; i++) if (lista[i].ativo) { algum = true; break; }
    if (algum && !ouvindo) { window.addEventListener('scroll', aoRolar, { passive: true }); ouvindo = true; }
    else if (!algum && ouvindo) { window.removeEventListener('scroll', aoRolar, { passive: true }); ouvindo = false; }
  }

  function aoCruzar(es) {
    es.forEach(function (e) {
      var m = porVao.get(e.target);
      if (!m) return;
      if (e.isIntersecting && !m.ativo) { m.ativo = true; m.pular = true; }
      else if (!e.isIntersecting && m.ativo) m.ativo = false;
    });
    atualizaOuvinte();
    sujo = true; agenda();
  }

  // a moeda chegou a uma tela e meia de distância: prepara a volta inteira em tempo ocioso
  function aoChegarPerto(es) {
    es.forEach(function (e) {
      var m = porVao.get(e.target);
      if (!m || !e.isIntersecting) return;
      m.perto = true; aquece(m);
      if (m.aquecido) ioPerto.unobserve(m.vao);
    });
  }

  function aoMedir(es) {
    var real = window.devicePixelRatio || 1, dpr = Math.min(2, real);
    es.forEach(function (e) {
      var m = porCanvas.get(e.target);
      if (!m) return;
      var cb = e.contentBoxSize && (e.contentBoxSize[0] || e.contentBoxSize);
      var w = cb ? cb.inlineSize : e.contentRect.width, h = cb ? cb.blockSize : e.contentRect.height;
      var W = Math.round(w * dpr), H = Math.round(h * dpr);
      // pixels exatos do aparelho (quadrados nítidos), quando o navegador informa e bate com a conta
      var dp = e.devicePixelContentBoxSize && e.devicePixelContentBoxSize[0];
      if (dp && real <= 2 && Math.abs(dp.inlineSize - w * real) < 2 && Math.abs(dp.blockSize - h * real) < 2) { W = dp.inlineSize; H = dp.blockSize; }
      if (W === m.W && H === m.H) return;
      m.W = W; m.H = H; m.cv.width = Math.max(1, W); m.cv.height = Math.max(1, H);
      // moeda pequena (quadrado abaixo de 5 px): de 2 em 2° já é liso, e a volta cabe em 180 quadros
      var passo = Math.min(W, H) / N < 5 ? 2 : 1;
      if (passo !== m.passo) { m.passo = passo; m.aquecido = false; }
      pintaInst(m, quantiza(reduz ? 0 : m.ang, m.passo));   // o canvas acabou de ser limpo: pinta antes da tela sair
      if (m.perto) { aquece(m); if (m.aquecido && ioPerto) ioPerto.unobserve(m.vao); }
    });
  }

  function mudouMovimento() {
    reduz = !!(mq && mq.matches);
    if (raf) { cancelAnimationFrame(raf); raf = 0; }
    lista.forEach(function (m) {
      if (io) { if (reduz) io.unobserve(m.vao); else io.observe(m.vao); }
      m.ativo = !reduz && !io; m.pular = true; m.ang = m.alvo = 0;
      pintaInst(m, 0);
      if (!reduz && m.perto) aquece(m);
    });
    atualizaOuvinte();
    if (!reduz) { sujo = true; agenda(); if (conferePendente) confereDepois(); }
  }

  function ligaGlobais() {
    if (globais) return;
    globais = true;
    window.addEventListener('resize', aoRedimensionarJanela, { passive: true });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) { if (raf) { cancelAnimationFrame(raf); raf = 0; } ultimoT = 0; }
      else if (ouvindo) { sujo = true; agenda(); }
    });
    if (mq) { if (mq.addEventListener) mq.addEventListener('change', mudouMovimento); else if (mq.addListener) mq.addListener(mudouMovimento); }
  }

  function iniciar(raiz) {
    if (!prepara()) return 0;
    var novos = [];
    Array.prototype.forEach.call((raiz || document).querySelectorAll('[data-moeda-texto]'), function (d) {
      var vaos = d.classList.contains('moeda-vao') ? [d] : d.querySelectorAll('.moeda-vao');
      Array.prototype.forEach.call(vaos, function (v) { var m = cria(v, d); if (m) novos.push(m); });
    });
    if (!novos.length) return 0;
    injetaCSS();
    ligaGlobais();
    if (!io && 'IntersectionObserver' in window) io = new IntersectionObserver(aoCruzar, { rootMargin: '12% 0px 12% 0px' });
    if (!ioPerto && 'IntersectionObserver' in window) ioPerto = new IntersectionObserver(aoChegarPerto, { rootMargin: '150% 0px 150% 0px' });
    if (!ro && 'ResizeObserver' in window) ro = new ResizeObserver(aoMedir);
    // uma leitura para todas, depois de criar tudo: o ângulo de partida de cada moeda
    var vh = window.innerHeight, dpr = Math.min(2, window.devicePixelRatio || 1);
    var caixas = novos.map(function (m) { return m.vao.getBoundingClientRect(); });
    novos.forEach(function (m, n) {
      var r = caixas[n];
      m.ang = m.alvo = reduz ? 0 : anguloDe(r.top + r.height / 2, vh, m.voltas);
      lista.push(m);
      if (ro) {
        try { ro.observe(m.cv, { box: 'device-pixel-content-box' }); } catch (e) { ro.observe(m.cv); }
      } else {
        m.W = Math.round(r.width * dpr); m.H = Math.round(r.height * dpr);
        m.cv.width = Math.max(1, m.W); m.cv.height = Math.max(1, m.H);
        m.passo = Math.min(m.W, m.H) / N < 5 ? 2 : 1;
        pintaInst(m, quantiza(m.ang, m.passo));
      }
      if (!reduz) { if (io) io.observe(m.vao); else m.ativo = true; if (ioPerto) ioPerto.observe(m.vao); else { m.perto = true; aquece(m); } }
    });
    atualizaOuvinte();
    sujo = true; agenda();
    return novos.length;
  }

  function estado() {
    return {
      reduz: reduz, ouvindo: ouvindo, rodando: !!raf, rapido: rapido, cache: cache.size,
      quadros: est.quadros, mediaMs: est.quadros ? +(est.quadroMs / est.quadros).toFixed(3) : 0, maxMs: +est.quadroMax.toFixed(3),
      calculos: est.calculos, calculoMedioMs: est.calculos ? +(est.calculoMs / est.calculos).toFixed(3) : 0, calculoMaxMs: +est.calculoMax.toFixed(3),
      leituraMedioMs: est.quadros ? +(est.leituraMs / est.quadros).toFixed(3) : 0, pinturaMedioMs: est.pinturas ? +(est.pinturaMs / est.pinturas).toFixed(3) : 0,
      leituraMaxMs: +est.leituraMax.toFixed(3), pinturaMaxMs: +est.pinturaMax.toFixed(3),
      moedas: lista.map(function (m) {
        return { ativo: m.ativo, angulo: +m.ang.toFixed(2), alvo: +m.alvo.toFixed(2), grau: m.grau, passo: m.passo, W: m.W, H: m.H, perto: m.perto, aquecido: m.aquecido, desenhos: m.desenhos };
      })
    };
  }
  function zeraEstat() { est.quadros = est.quadroMs = est.quadroMax = est.calculos = est.calculoMs = est.calculoMax = est.leituraMs = est.leituraMax = est.pinturas = est.pinturaMs = est.pinturaMax = 0; lista.forEach(function (m) { m.desenhos = 0; }); }

  window.LCMoedaTexto = {
    desenha: desenha,
    quadro: function (g, f) { return prepara() ? quadro(quantiza(+g || 0, 0.01), f || 'faísca') : null; },
    iniciar: iniciar, estado: estado, zeraEstat: zeraEstat, anguloDe: anguloDe,
    confere: function (formas, angulos) { return prepara() ? confere(formas, angulos) : null; }
  };

  function vai() { if (!iniciar() && !L) window.addEventListener('load', function () { iniciar(); }, { once: true }); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', vai, { once: true }); else vai();
})();
