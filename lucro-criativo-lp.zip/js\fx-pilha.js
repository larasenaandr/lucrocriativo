/* Lucro Criativo · fx-pilha.js · os passos viram uma pilha de fichas ao rolar (v1, 26/11)
   Uso: <ol class="passos" data-pilha> <li class="passo">…</li> … </ol>  +  <script src="js/fx-pilha.js" defer></script>

   Até 1099 px (celular e tablet): cada cartão gruda no topo (position: sticky, top = topo + faixa × índice) e o próximo
     sobe por cima. Do cartão coberto fica à vista uma tirinha com o número e o nome do passo (e a data da etiqueta);
     ele encolhe de leve (0,96) e ganha um véu azul (6% → 10% conforme afunda na pilha), tudo calculado pela rolagem.
     Os cartões ficam com a mesma altura (fichas), para a pilha fechar limpa quando a lista acaba.
     Se a tela for baixa demais para ler um cartão inteiro grudado (celular deitado, zoom de texto), a lista fica normal.
   A partir de 1100 px: sem sticky; quando a grade entra na tela os cartões entram um depois do outro
     (fade + 16 px, 80 ms entre eles), uma vez só.
   prefers-reduced-motion: sem entrada e sem encolher; a pilha (sticky) e o véu ficam, porque só acompanham a rolagem.

   Opções no <ol>:
     data-pilha-topo="72"     px do topo da tela até o 1º cartão grudado
     data-pilha-faixa="20"    px da tirinha que fica à vista de cada cartão coberto
     data-pilha-rotulo="nao"  tirinha sem texto (só a borda do cartão)
     data-pilha-ate="1099"    maior largura de tela com pilha (acima disso: entrada em sequência)
     data-pilha-reserva="66"  px cobertos no pé da tela (padrão: altura da #buybar, se ela estiver na página)
   Num <li>: data-pilha-rotulo="Texto" troca o nome que aparece na tirinha.
   O texto real fica no HTML; a tirinha e o véu são <span aria-hidden="true"> e não mudam o layout (position: absolute).
   Teste: window.LCPilha.instancias[0].stats(zerar) e .estado() */
(function () {
  'use strict';
  if (window.LCPilha) return;
  var D = document, W = window;
  var CSS_ID = 'lc-pilha-css';
  var suporta = function (p, v) { return !!(W.CSS && CSS.supports && CSS.supports(p, v)); };
  var temSticky = suporta('position', 'sticky') || suporta('position', '-webkit-sticky');
  var temIO = 'IntersectionObserver' in W;
  var temRO = 'ResizeObserver' in W;
  var temSvh = suporta('height', '100svh');
  var calmoMQ = W.matchMedia ? W.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var calmo = function () { return !!(calmoMQ && calmoMQ.matches); };
  var ouve = function (mq, fn) { if (!mq) return; if (mq.addEventListener) mq.addEventListener('change', fn); else if (mq.addListener) mq.addListener(fn); };
  var c01 = function (x) { return x < 0 ? 0 : x > 1 ? 1 : x; };
  var num = function (v, d) { var x = parseFloat(v); return isFinite(x) ? x : d; };
  var agora = function () { return W.performance && performance.now ? performance.now() : Date.now(); };

  var CSS_TXT = [
    /* pilha (celular e tablet): uma coluna, cada cartão gruda um pouco abaixo do anterior */
    '[data-pilha].lcp-on{display:flex;flex-direction:column;gap:16px}',
    '@media (min-width:700px){[data-pilha].lcp-on{max-width:680px}}',
    '[data-pilha].lcp-on>li{position:-webkit-sticky;position:sticky;top:var(--lcp-t,72px);margin:0;min-height:var(--lcp-h,0px);-webkit-transform-origin:50% 0;transform-origin:50% 0}',
    '[data-pilha] .lcp-veu,[data-pilha] .lcp-rot{display:none}',
    '[data-pilha].lcp-on .lcp-veu{display:block;position:absolute;top:0;right:0;bottom:0;left:0;border-radius:inherit;background:#0100FE;opacity:0;pointer-events:none}',
    '[data-pilha].lcp-on .lcp-rot{display:flex;align-items:center;gap:9px;position:absolute;top:0;left:22px;right:22px;height:var(--lcp-f,20px);opacity:0;pointer-events:none;white-space:nowrap;overflow:hidden;font:800 10px/16px "JetBrains Mono",ui-monospace,Menlo,Consolas,monospace;letter-spacing:.06em;text-transform:uppercase;color:#0100FE}',
    '.lcp-rot .lcp-nome{color:#0A0A0A;overflow:hidden;text-overflow:ellipsis}',
    '.lcp-rot .lcp-data{margin-left:auto;display:inline-flex;align-items:center;gap:6px;color:rgba(10,10,10,.62)}',
    '.lcp-rot .lcp-data i{display:block;width:6px;height:6px;background:#0A0A0A}',
    /* entrada em sequência (telas largas) */
    '[data-pilha].lcp-espera>li{opacity:0;-webkit-transform:translateY(16px);transform:translateY(16px)}',
    '[data-pilha].lcp-entra>li{transition:opacity .6s cubic-bezier(.2,.7,.2,1),transform .6s cubic-bezier(.2,.7,.2,1);transition-delay:calc(var(--lcp-i,0) * 80ms)}',
    '@media print{[data-pilha]>li{position:relative!important;opacity:1!important;-webkit-transform:none!important;transform:none!important}[data-pilha] .lcp-veu,[data-pilha] .lcp-rot{display:none!important}}'
  ].join('\n');

  function injetaCSS() {
    if (D.getElementById(CSS_ID)) return;
    var s = D.createElement('style'); s.id = CSS_ID; s.textContent = CSS_TXT;
    (D.head || D.documentElement).appendChild(s);
  }

  // altura da tela "pequena" (com as barras do navegador à mostra): não muda quando a barra do celular some na rolagem
  var sonda = null;
  function alturaTela() {
    var h = W.innerHeight || D.documentElement.clientHeight;
    if (temSvh && D.body) {
      if (!sonda) {
        sonda = D.createElement('div'); sonda.setAttribute('aria-hidden', 'true');
        sonda.style.cssText = 'position:fixed;top:0;left:0;width:0;height:100svh;visibility:hidden;pointer-events:none';
        D.body.appendChild(sonda);
      }
      var s = sonda.offsetHeight; if (s > 0 && s < h) h = s;
    }
    return h;
  }

  function Pilha(ol) {
    var i, cards = [];
    for (i = 0; i < ol.children.length; i++) if (ol.children[i].tagName === 'LI') cards.push(ol.children[i]);
    var n = cards.length;
    var op = {
      topo: num(ol.getAttribute('data-pilha-topo'), 72),
      faixa: num(ol.getAttribute('data-pilha-faixa'), 20),
      rotulo: ol.getAttribute('data-pilha-rotulo') !== 'nao',
      ate: num(ol.getAttribute('data-pilha-ate'), 1099),
      reserva: ol.hasAttribute('data-pilha-reserva') ? num(ol.getAttribute('data-pilha-reserva'), 0) : null
    };
    var larguraMQ = W.matchMedia ? W.matchMedia('not all and (min-width: ' + (op.ate + 1) + 'px)') : null;
    var modo = '';                 // 'pilha' | 'grade' (telas largas) | 'solta' (pilha não coube na tela)
    var perto = !temIO;            // a lista está perto da tela? (fora dela a rolagem não custa nada)
    var raf = 0, rafMedida = 0, medidaForcada = false, chaveTela = '';
    var M = { T: op.topo, S: op.faixa, H: 0, gap: 16, total: 0 };
    var veus = [], rots = [], ult = [];
    var y = [], p = [];
    var st = { quadros: 0, soma: 0, max: 0, leitura: 0, leituraMax: 0, lentos: 0, medidas: 0 };
    var entrou = false, ioEntrada = null, timerEntrada = 0;

    // véu e tirinha de cada cartão (enfeites: aria-hidden, absolutos, não mexem no layout)
    for (i = 0; i < n; i++) {
      var li = cards[i];
      var r = op.rotulo && i < n - 1 ? criaRotulo(li, i) : null;
      if (r) li.appendChild(r);
      var v = D.createElement('span'); v.className = 'lcp-veu'; v.setAttribute('aria-hidden', 'true'); li.appendChild(v);
      veus.push(v); rots.push(r); ult.push({ t: '', v: '', r: '' }); y.push(0); p.push(0);
    }

    function criaRotulo(li, k) {
      var s = D.createElement('span'); s.className = 'lcp-rot'; s.setAttribute('aria-hidden', 'true');
      var nEl = li.querySelector('.passo-n'), nTxt = nEl ? nEl.textContent.replace(/\s+/g, '') : '';
      if (!nTxt) nTxt = String(k + 1);
      if (/^\d$/.test(nTxt)) nTxt = '0' + nTxt;
      var nome = li.getAttribute('data-pilha-rotulo');
      if (nome == null) { var h = li.querySelector('h1,h2,h3,h4,h5,h6'); nome = h ? h.textContent.replace(/\s+/g, ' ').trim() : ''; }
      var b = D.createElement('b'); b.textContent = nTxt; s.appendChild(b);
      if (nome) { var t = D.createElement('span'); t.className = 'lcp-nome'; t.textContent = nome; s.appendChild(t); }
      var tag = li.querySelector('.tag'), m = tag ? /(\d{1,2}\/\d{1,2})/.exec(tag.textContent) : null;
      if (m) {
        var d = D.createElement('span'); d.className = 'lcp-data';
        var q = D.createElement('i'); q.style.background = getComputedStyle(tag).backgroundColor;   // preto = live, laranja = sábado
        d.appendChild(q); d.appendChild(D.createTextNode(m[1])); s.appendChild(d);
      }
      var cs = getComputedStyle(li);
      if (num(cs.paddingLeft, 0) > 0) { s.style.left = cs.paddingLeft; s.style.right = cs.paddingRight; }
      return s;
    }

    // altura do conteúdo do cartão, sem a altura mínima que a pilha põe (a base para igualar as fichas)
    function alturaNatural(li) {
      var c = li.lastElementChild;
      while (c && /^(absolute|fixed)$/.test(getComputedStyle(c).position)) c = c.previousElementSibling;   // pula o véu e a tirinha
      if (!c || c.offsetParent !== li) return li.offsetHeight;
      var cs = getComputedStyle(li);
      return c.offsetTop + c.offsetHeight + num(getComputedStyle(c).marginBottom, 0) + num(cs.paddingBottom, 0) + num(cs.borderBottomWidth, 0);
    }

    function reserva() {
      if (op.reserva != null) return op.reserva;
      var b = D.getElementById('buybar');
      if (!b) return 0;
      var cs = getComputedStyle(b);
      return cs.display === 'none' || cs.position !== 'fixed' ? 0 : b.offsetHeight;
    }

    function poe(el, k, v) { if (el.style.getPropertyValue(k) !== v) el.style.setProperty(k, v); }

    // mede com a pilha ligada; devolve false se não couber (aí a lista fica normal)
    function mede() {
      st.medidas++;
      var H = 0, k;
      for (k = 0; k < n; k++) H = Math.max(H, alturaNatural(cards[k]));
      H = Math.ceil(H) + 1;
      var cs = getComputedStyle(ol), gap = num(cs.rowGap, NaN);
      if (!isFinite(gap)) gap = num(cs.gap, 16);
      var S = op.faixa, T = op.topo, vh = alturaTela() - reserva();
      // o penúltimo cartão grudado precisa caber inteiro acima do pé da tela (senão o fim do texto dele nunca aparece)
      var sobra = vh - 8 - (T + (n - 2) * S + H);
      if (sobra < 0) T += sobra;
      if (T < 8) return false;
      M.T = T; M.S = S; M.H = H; M.gap = gap; M.total = n * H + (n - 1) * gap;
      poe(ol, '--lcp-h', H + 'px');
      poe(ol, '--lcp-f', S + 'px');
      for (k = 0; k < n; k++) poe(cards[k], '--lcp-t', (T + k * S) + 'px');
      return true;
    }

    function limpaPilha() {
      ol.classList.remove('lcp-on');
      ol.style.removeProperty('--lcp-h'); ol.style.removeProperty('--lcp-f');
      for (var k = 0; k < n; k++) {
        cards[k].style.removeProperty('--lcp-t'); cards[k].style.transform = '';
        veus[k].style.opacity = ''; if (rots[k]) rots[k].style.opacity = '';
        ult[k].t = ult[k].v = ult[k].r = '';
      }
    }

    function aplicaModo() {
      var quer = larguraMQ && larguraMQ.matches && temSticky && n > 1 ? 'pilha' : 'grade';
      if (quer === 'pilha') {
        revelaEntrada();
        ol.classList.add('lcp-on');
        if (!mede()) { limpaPilha(); quer = 'solta'; }
      } else if (ol.classList.contains('lcp-on')) limpaPilha();
      modo = quer;
      chaveTela = (W.innerWidth || 0) + 'x' + alturaTela();
      if (modo === 'grade') preparaEntrada(); else revelaEntrada();
      if (modo === 'pilha') quadroJa();
    }

    // a única medida por quadro: o topo da lista. Lida no evento de rolagem, que vem antes dos requestAnimationFrame do quadro
    // (antes de os outros efeitos da página escreverem no DOM), para não forçar um layout extra no meio deles.
    var topoLido = NaN, msLido = 0;
    function quadroJa() { topoLido = NaN; if (raf) { W.cancelAnimationFrame(raf); raf = 0; } quadro(); }   // fora da rolagem: lê na hora
    function leTopo() {
      var t0 = agora(), t = ol.getBoundingClientRect().top;
      msLido = agora() - t0;
      return t;
    }

    // um quadro da pilha: conta em cima do topo lido e escreve só o que mudou (transform e opacidade: nada de layout)
    function quadro() {
      raf = 0;
      if (modo !== 'pilha') return;
      var topo = topoLido === topoLido ? topoLido : leTopo();
      topoLido = NaN;
      st.leitura += msLido; if (msLido > st.leituraMax) st.leituraMax = msLido;
      var t0 = agora() - msLido; msLido = 0;
      var H = M.H, S = M.S, T = M.T, passo = H + M.gap, curso = Math.max(1, passo - S), fundo = topo + M.total - H, k;
      for (k = 0; k < n; k++) y[k] = Math.max(topo + k * passo, Math.min(T + k * S, fundo));   // onde o sticky põe cada cartão
      for (k = 0; k < n - 1; k++) p[k] = c01((passo - (y[k + 1] - y[k])) / curso);           // quanto o de cima já cobriu
      p[n - 1] = 0;
      // todos os cobertos na mesma escala (as tirinhas ficam alinhadas); o véu escurece conforme o cartão afunda na pilha
      var encolhe = !calmo(), funda = 0;
      for (k = n - 1; k >= 0; k--) {
        var esc = encolhe ? 1 - 0.04 * p[k] : 1;
        var veu = Math.min(0.10, 0.06 * p[k] + 0.012 * funda);
        var rot = k < n - 1 ? c01(1 - (y[k + 1] - y[k] - S) / 24) : 0;   // a tirinha acende enquanto o número some (últimos 24 px)
        escreve(k, esc, veu, rot);
        funda += p[k];
      }
      var dt = agora() - t0; st.quadros++; st.soma += dt; if (dt > st.max) st.max = dt; if (dt > 2) st.lentos++;
    }

    function escreve(k, esc, veu, rot) {
      var u = ult[k];
      var t = esc > 0.9999 ? '' : 'scale(' + esc.toFixed(4) + ')';
      if (t !== u.t) { cards[k].style.transform = t; u.t = t; }
      var v = veu < 0.001 ? '' : veu.toFixed(3);
      if (v !== u.v) { veus[k].style.opacity = v; u.v = v; }
      if (rots[k]) { var r = rot < 0.01 ? '' : rot.toFixed(2); if (r !== u.r) { rots[k].style.opacity = r; u.r = r; } }
    }

    function agenda() { if (!raf && modo === 'pilha' && perto && !D.hidden) raf = W.requestAnimationFrame(quadro); }

    // medidas de novo (mudou a largura, a altura útil da tela, a fonte carregou…), no máximo uma vez por quadro
    function pedeMedida(forca) {
      if (forca) medidaForcada = true;
      if (!rafMedida) rafMedida = W.requestAnimationFrame(function () {
        rafMedida = 0;
        var f = medidaForcada; medidaForcada = false;
        if (!f && (W.innerWidth || 0) + 'x' + alturaTela() === chaveTela) return;   // só a barra do celular mexeu: nada a fazer
        aplicaModo();
      });
    }

    // entrada em sequência (telas largas), uma vez
    function preparaEntrada() {
      if (entrou || ioEntrada || calmo() || !temIO) return;
      var rr = ol.getBoundingClientRect();
      if (rr.top < (W.innerHeight || 0) * 0.92) { entrou = true; return; }   // já está à vista (ou já passou): sem entrada
      for (var k = 0; k < n; k++) cards[k].style.setProperty('--lcp-i', k);
      ol.classList.add('lcp-espera');
      ioEntrada = new IntersectionObserver(function (es) {
        for (var j = 0; j < es.length; j++) if (es[j].isIntersecting) { entra(); break; }
      }, { threshold: 0.2 });
      ioEntrada.observe(ol);
    }
    function entra() {
      entrou = true;
      if (ioEntrada) { ioEntrada.disconnect(); ioEntrada = null; }
      ol.classList.add('lcp-entra');
      ol.classList.remove('lcp-espera');
      timerEntrada = setTimeout(fimEntrada, (n - 1) * 80 + 700);
    }
    function fimEntrada() {
      timerEntrada = 0;
      ol.classList.remove('lcp-entra');
      for (var k = 0; k < n; k++) cards[k].style.removeProperty('--lcp-i');
    }
    function revelaEntrada() {   // cancela uma entrada pendente (trocou de modo, ligou o movimento reduzido)
      if (ioEntrada) { ioEntrada.disconnect(); ioEntrada = null; }
      ol.classList.remove('lcp-espera');
      if (timerEntrada) { clearTimeout(timerEntrada); fimEntrada(); }
      else if (!ol.classList.contains('lcp-entra')) for (var k = 0; k < n; k++) cards[k].style.removeProperty('--lcp-i');
    }

    // ligações
    if (temIO) new IntersectionObserver(function (es) {
      perto = es[es.length - 1].isIntersecting;
      if (perto) agenda();
      else if (modo === 'pilha') quadroJa();   // saiu de perto: assenta o estado e para
    }, { rootMargin: '50% 0px 50% 0px' }).observe(ol);
    W.addEventListener('scroll', function () { if (perto && modo === 'pilha' && !D.hidden) { topoLido = leTopo(); agenda(); } }, { passive: true });
    W.addEventListener('resize', function () { pedeMedida(false); }, { passive: true });
    W.addEventListener('pageshow', function () { pedeMedida(true); });
    D.addEventListener('visibilitychange', function () {
      if (D.hidden) { if (raf) { W.cancelAnimationFrame(raf); raf = 0; } }
      else agenda();
    });
    if (temRO) new ResizeObserver(function () { pedeMedida(true); }).observe(ol);
    if (D.fonts && D.fonts.ready) D.fonts.ready.then(function () { pedeMedida(true); });
    ouve(larguraMQ, aplicaModo);
    ouve(calmoMQ, function () { if (calmo()) revelaEntrada(); if (modo === 'pilha') quadroJa(); });

    aplicaModo();

    this.el = ol;
    this.opcoes = op;
    this.stats = function (zerar) {
      var q = st.quadros || 1;
      var o = { modo: modo, perto: perto, quadros: st.quadros, msMedio: +(st.soma / q).toFixed(4), msMax: +st.max.toFixed(3), quadrosAcimaDe2ms: st.lentos,
        msLeituraMedio: +(st.leitura / q).toFixed(4), msLeituraMax: +st.leituraMax.toFixed(3), medidas: st.medidas, topo: M.T, faixa: M.S, alturaCartao: M.H };
      if (zerar) { st.quadros = 0; st.soma = 0; st.max = 0; st.leitura = 0; st.leituraMax = 0; st.lentos = 0; }
      return o;
    };
    this.estado = function () { return { modo: modo, y: y.map(function (a) { return Math.round(a * 10) / 10; }), p: p.map(function (a) { return Math.round(a * 1000) / 1000; }) }; };
    this.remede = function () { pedeMedida(true); };
  }

  var instancias = [];
  function inicia() {
    var lista = D.querySelectorAll('[data-pilha]');
    if (!lista.length) return;
    injetaCSS();
    for (var i = 0; i < lista.length; i++) {
      if (lista[i].__lcPilha) continue;
      lista[i].__lcPilha = true;
      instancias.push(new Pilha(lista[i]));
    }
  }
  W.LCPilha = { instancias: instancias, inicia: inicia };
  if (D.readyState === 'loading') D.addEventListener('DOMContentLoaded', inicia); else inicia();
})();
