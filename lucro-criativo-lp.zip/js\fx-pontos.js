/*
  fx-pontos.js · grade de quadradinhos que acende perto do ponteiro (Imersão Lucro Criativo · Koko)
  Direção de arte: Lara Sena (26/11/2026)
  Referência: _refs/pins/4_hover_branco.mp4 (pontos que crescem e mudam de cor perto do
  cursor), aqui bem mais sutil e na identidade: quadrados da grade, azul dominando,
  laranja só no miolo, como o cursor da marca.

  O que faz
  - Repouso: grade de quadradinhos quase invisível atrás do conteúdo da seção (3 px na tela
    comum, 2,5 px na retina; #0100FE a 8%; passo de 30 px). É só CSS (gradiente cônico
    repetido numa camada atrás do conteúdo): custo zero e igual em qualquer aparelho.
    A grade é presa à página: de uma seção [data-pontos] para a vizinha ela continua sem emenda.
  - Mouse (só em '(hover: hover) and (pointer: fine)'): até ~140 px do ponteiro os
    quadradinhos crescem até 9 px e o azul ganha força; no centro acendem em laranja
    #FF5A1F, que cresce de dentro do quadrado azul (sem passar por roxo). Queda suave com a
    distância. Acendem em ~160 ms e voltam em ~600 ms quando o ponteiro se afasta ou sai.
    Perto da divisa entre duas seções com o efeito, as duas acendem (o halo não é cortado).
  - Leitura: atrás de texto (títulos, parágrafos, itens, links, botões) o efeito fica a 20% e
    o laranja não aparece, com borda suave; nas margens e entre os blocos ele vem inteiro.
    A camada não recebe ponteiro (pointer-events:none): clique, seleção e foco seguem iguais.
  - Desempenho: um laço só para todas as seções, que só roda enquanto algo muda (dorme com o
    mouse parado, longe das seções, fora da tela e com a aba escondida). As medidas são lidas
    nos eventos de ponteiro e de rolagem (que o navegador entrega no começo do quadro, com o
    layout limpo, antes dos requestAnimationFrame dos outros módulos); o laço de desenho não
    lê nada do DOM. Cada canvas tem só o tamanho da área acesa (nunca maior que a parte
    visível da seção) e fica sem memória quando nada está aceso. Listeners passivos,
    devicePixelRatio limitado a 2.
  - Toque: fica a grade parada (ou nada, com data-pontos-toque="nada").
  - prefers-reduced-motion: a grade parada, sem reagir ao mouse.
  - Layout: a camada é absoluta (inset 0, z-index -1, atrás do conteúdo); a seção só ganha
    position:relative (se for static) e isolation:isolate. Nada se mexe (sem CLS).
    A camada é aria-hidden e não tem texto: o conteúdo da seção não muda.
  - Estrutura: <div class="fxp" aria-hidden> como 1º filho da seção, com a grade parada em CSS,
    e dentro dele um <canvas aria-hidden> que só existe do tamanho da área acesa (0×0 em repouso).
    O ponteiro é ouvido no documento (um ouvinte só para todas as seções), não em cada seção:
    é o que deixa o halo atravessar a divisa entre duas seções vizinhas com o efeito.

  Uso
    <section class="s dor" data-pontos> ... </section>
    <script src="js/fx-pontos.js" defer></script>
  Se inicia sozinho em todo [data-pontos]. Opções por atributo (todas opcionais):
    data-pontos-cor        cor da grade e do halo                    (padrão #0100FE)
    data-pontos-acento     cor do miolo aceso                        (padrão #FF5A1F)
    data-pontos-opacidade  força da grade em repouso, 0–1            (padrão 0.08)
    data-pontos-halo       força máxima do azul aceso, 0–1           (padrão 0.5)
    data-pontos-passo      distância entre quadradinhos, px          (padrão 30)
    data-pontos-tam        lado em repouso, px                       (padrão 2.5)
    data-pontos-max        lado máximo, no centro, px                (padrão 9)
    data-pontos-raio       alcance do ponteiro, px                   (padrão 140)
    data-pontos-entrada    ms para acender                           (padrão 160)
    data-pontos-volta      ms para voltar ao repouso                 (padrão 600)
    data-pontos-texto      força atrás de texto, 0–1 (1 = ignora)    (padrão 0.2)
    data-pontos-evitar     seletor do que conta como texto, ou "nada" (padrão títulos, p, li, a, button…)
    data-pontos-sem        ponteiro em cima disso não acende nada    (padrão nenhum; ex.: ".versus")
    data-pontos-toque      sem mouse: "grade" (parada) ou "nada"     (padrão grade)
    data-pontos-fundo      cor atrás da seção, se a detecção errar   (padrão automático)
  Em seção azul: data-pontos-cor="#FFFFFF" (grade branca, miolo laranja).
  Ou à mão: LCPontos.montar(el, { cor, raio, ... }) devolve
  { pausar, continuar, medir, redesenhar, destruir, stats, celula }.
  LCPontos.stats(zerar) dá o tempo do laço compartilhado (todas as seções juntas).
*/
(function () {
  'use strict';
  if (window.LCPontos) return;

  const PADRAO = {
    cor: '#0100FE',
    acento: '#FF5A1F',
    opacidade: 0.08,
    halo: 0.5,
    passo: 30,
    tam: 2.5,
    max: 9,
    raio: 140,
    entrada: 160,
    volta: 600,
    texto: 0.2,
    evitar: 'h1,h2,h3,h4,h5,h6,p,li,dt,dd,blockquote,figcaption,label,a,button',
    sem: '',
    toque: 'grade',
    fundo: ''
  };
  const LIMITES = {
    opacidade: [0, 1], halo: [0, 1], passo: [8, 240], tam: [1, 40], max: [1, 200],
    raio: [16, 2000], entrada: [16, 3000], volta: [16, 6000], texto: [0, 1]
  };
  const MIOLO = [0.8, 0.97];   // ativação em que o miolo laranja aparece e em que ocupa o quadrado todo
  const NP = 64;               // degraus de força do azul
  const FOLGA = 6, PENA = 24;  // texto: folga em volta de cada linha e borda suave (px CSS)
  const SOME = 0.01;           // abaixo disso a célula volta à grade de CSS

  const CSS_ID = 'fx-pontos-css';
  const CSS =
    '.fxp-pos{position:relative}' +
    '.fxp-iso{isolation:isolate}' +
    '.fxp{position:absolute;top:0;right:0;bottom:0;left:0;z-index:-1;pointer-events:none;overflow:hidden;contain:strict;background-repeat:repeat}' +
    '.fxp>canvas{position:absolute;left:0;top:0;width:0;height:0;display:block;pointer-events:none}' +
    '@media print{.fxp{display:none}}' +
    '@media (forced-colors:active){.fxp{display:none}}';

  function injetarCSS() {
    if (document.getElementById(CSS_ID)) return;
    const s = document.createElement('style');
    s.id = CSS_ID;
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  const suave = (a, b, x) => { const t = Math.min(1, Math.max(0, (x - a) / (b - a))); return t * t * (3 - 2 * t); };
  const rolagemY = () => window.scrollY || window.pageYOffset || 0;
  const dprAtual = () => Math.min(2, window.devicePixelRatio || 1);
  // linha da grade presa à página: y da página múltiplo do passo (em px de tela)
  const faseDe = (topo, dpr, passoD) => { const f = Math.round(-topo * dpr) % passoD; return f < 0 ? f + passoD : f; };

  /* ---------- cores ---------- */
  let ctxCor = null;
  function rgba(s) {
    if (s == null) return null;
    s = String(s).trim();
    if (!s) return null;
    let m = /^#([0-9a-f]{3,8})$/i.exec(s);
    if (!m && !/^rgba?\(/i.test(s)) {   // nomes e outros formatos: o canvas normaliza
      if (!ctxCor) { try { ctxCor = document.createElement('canvas').getContext('2d'); } catch (e) { ctxCor = null; } }
      if (!ctxCor) return null;
      ctxCor.fillStyle = '#010203';
      ctxCor.fillStyle = s;
      const n = String(ctxCor.fillStyle);
      if (n === '#010203' && s.toLowerCase() !== '#010203') return null;
      s = n;
      m = /^#([0-9a-f]{6})$/i.exec(s);
    }
    if (m) {
      let h = m[1];
      if (h.length === 3 || h.length === 4) h = h.replace(/./g, '$&$&');
      if (h.length !== 6 && h.length !== 8) return null;
      const n = parseInt(h.slice(0, 6), 16);
      return [(n >> 16) & 255, (n >> 8) & 255, n & 255, h.length === 8 ? parseInt(h.slice(6), 16) / 255 : 1];
    }
    m = /^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+)(%?))?\s*\)$/i.exec(s);
    if (m) return [+m[1], +m[2], +m[3], m[4] == null ? 1 : (m[5] ? +m[4] / 100 : +m[4])];
    return null;
  }
  const cssCor = (c, a) => 'rgba(' + Math.round(c[0]) + ',' + Math.round(c[1]) + ',' + Math.round(c[2]) + ',' + (+(+a).toFixed(3)) + ')';

  // cor sólida que aparece atrás da seção (sobe pelos pais até achar fundo opaco); null se houver imagem
  function fundoAtras(el) {
    const camadas = [];
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.backgroundImage && cs.backgroundImage !== 'none') return null;
      const c = rgba(cs.backgroundColor);
      if (c && c[3] > 0) { camadas.push(c); if (c[3] >= 0.999) break; }
    }
    let r = 255, g = 255, b = 255;   // página sem fundo = branco
    for (let k = camadas.length - 1; k >= 0; k--) {
      const c = camadas[k], a = Math.min(1, c[3]);
      r += (c[0] - r) * a; g += (c[1] - g) * a; b += (c[2] - b) * a;
    }
    return cssCor([r, g, b], 1);
  }

  /* ---------- opções ---------- */
  function seletorOk(s) {
    if (!s) return '';
    try { document.createDocumentFragment().querySelector(s); return s; } catch (e) { return ''; }
  }
  function lerOpcoes(el, extra) {
    const op = {};
    for (const k in PADRAO) {
      op[k] = PADRAO[k];
      const v = el.getAttribute('data-pontos-' + k);
      if (v != null && v !== '') op[k] = v;
    }
    if (extra) for (const k in extra) if (extra[k] != null && k in PADRAO) op[k] = extra[k];
    for (const k in LIMITES) {
      let v = parseFloat(op[k]);
      if (!isFinite(v)) v = PADRAO[k];
      op[k] = Math.min(LIMITES[k][1], Math.max(LIMITES[k][0], v));
    }
    op.max = Math.max(op.tam, op.max);
    if (/^(nada|none|0|false)$/i.test(String(op.evitar).trim())) op.evitar = '';
    op.evitar = seletorOk(op.evitar);
    op.sem = seletorOk(op.sem);
    op.toque = String(op.toque).trim().toLowerCase() === 'nada' ? 'nada' : 'grade';
    return op;
  }

  function ouvirMQ(mq, f) { if (!mq) return; if (mq.addEventListener) mq.addEventListener('change', f); else if (mq.addListener) mq.addListener(f); }
  function largarMQ(mq, f) { if (!mq) return; if (mq.removeEventListener) mq.removeEventListener('change', f); else if (mq.removeListener) mq.removeListener(f); }

  /* ================================================================== */
  /* Controle compartilhado: um ponteiro, um laço                       */
  /* ================================================================== */
  const instancias = [];
  const P = { x: 0, y: 0, ok: false, alvo: null };   // mouse/caneta dentro da janela
  const G = { raf: 0, ultimo: 0, ouvindo: false, vw: 0, vh: 0, tLido: -1e9, quadros: 0, ms: 0, max: 0, amostras: new Float32Array(256), na: 0, leituras: 0 };
  const mm = (q) => (window.matchMedia ? window.matchMedia(q) : null);
  const mqHover = mm('(hover: hover) and (pointer: fine)');
  const mqCalmo = mm('(prefers-reduced-motion: reduce)');
  let comMouse = false;     // o aparelho tem mouse (ou caneta fina) como ponteiro principal
  let interativo = false;   // com mouse e sem pedido de movimento reduzido

  // Medidas: lidas nos eventos de ponteiro e de rolagem, que chegam no começo do quadro (layout
  // limpo, antes dos requestAnimationFrame dos outros módulos). No máximo uma rodada por quadro.
  function lerTodas(forcar) {
    const agora = performance.now();
    if (!forcar && agora - G.tLido < 6) return;
    G.tLido = agora;
    for (let i = 0; i < instancias.length; i++) if (instancias[i]._pronta()) { instancias[i]._ler(); G.leituras++; }
  }
  function aoMover(e) {
    if (e.pointerType && e.pointerType !== 'mouse' && e.pointerType !== 'pen') return;
    P.x = e.clientX; P.y = e.clientY; P.alvo = e.target; P.ok = true;
    lerTodas(false);
    acordar();
  }
  function aoSairJanela() { P.ok = false; acordar(); }
  function aoSairDoc(e) { if (!e.relatedTarget && e.pointerType !== 'touch') aoSairJanela(); }   // outros navegadores
  function aoRolar() { if (P.ok || algumAceso()) { lerTodas(true); acordar(); } }   // a página passa por baixo do ponteiro parado
  function aoJanela() { G.vw = window.innerWidth; G.vh = window.innerHeight; if (P.ok || algumAceso()) { lerTodas(true); acordar(); } }
  function aoAba() { if (document.hidden) pararLaco(); else acordar(); }
  function algumAceso() { for (let i = 0; i < instancias.length; i++) if (instancias[i]._acesos()) return true; return false; }

  function porOuvintes() {
    if (G.ouvindo) return;
    G.ouvindo = true;
    document.addEventListener('pointermove', aoMover, { passive: true });
    document.documentElement.addEventListener('pointerleave', aoSairJanela, { passive: true });
    document.addEventListener('pointerout', aoSairDoc, { passive: true });
    window.addEventListener('blur', aoSairJanela);
    window.addEventListener('scroll', aoRolar, { passive: true });
  }
  function tirarOuvintes() {
    if (!G.ouvindo) return;
    G.ouvindo = false;
    document.removeEventListener('pointermove', aoMover);
    document.documentElement.removeEventListener('pointerleave', aoSairJanela);
    document.removeEventListener('pointerout', aoSairDoc);
    window.removeEventListener('blur', aoSairJanela);
    window.removeEventListener('scroll', aoRolar);
  }

  // há trabalho: alguma seção na tela com o ponteiro no alcance (medido no último evento) ou com algo aceso
  function temTrabalho() { for (let i = 0; i < instancias.length; i++) { const it = instancias[i]; if (it._pronta() && it._quer()) return true; } return false; }
  function acordar() {
    if (G.raf || !interativo || document.hidden || !temTrabalho()) return;   // ponteiro longe ou seções fora da tela: nem agenda
    const agora = performance.now();
    if (agora - G.ultimo > 100) G.ultimo = agora;   // voltando do repouso: sem pulo
    G.raf = requestAnimationFrame(quadro);
  }
  function pararLaco() { if (G.raf) { cancelAnimationFrame(G.raf); G.raf = 0; } }

  // o laço só faz contas e desenha: não lê nada do DOM
  function quadro(agora) {
    G.raf = 0;
    if (!interativo || document.hidden) return;
    const t0 = performance.now();
    let dt = (agora - G.ultimo) / 1000;
    G.ultimo = agora;
    if (!(dt > 0)) dt = 1 / 60; else if (dt > 0.1) dt = 0.1;
    let seguir = false;
    for (let i = 0; i < instancias.length; i++) { const it = instancias[i]; if (it._pronta() && it._passo(dt, G.vw, G.vh)) seguir = true; }
    if (seguir) acordar();
    const ms = performance.now() - t0;
    G.quadros++; G.ms += ms;
    if (ms > G.max) G.max = ms;
    G.amostras[G.na++ & 255] = ms;
  }

  let mqDpr = null;
  function vigiarDpr() { mqDpr = mm('(resolution: ' + (window.devicePixelRatio || 1) + 'dppx)'); ouvirMQ(mqDpr, aoMudarDpr); }
  function aoMudarDpr() { largarMQ(mqDpr, aoMudarDpr); vigiarDpr(); for (let i = 0; i < instancias.length; i++) instancias[i]._remedir(); }

  function modo() {
    comMouse = !!(mqHover && mqHover.matches);
    interativo = comMouse && !(mqCalmo && mqCalmo.matches);
    for (let i = 0; i < instancias.length; i++) instancias[i]._modo();
    if (interativo && instancias.length) porOuvintes();
    else { tirarOuvintes(); pararLaco(); P.ok = false; }
  }
  let globalPronto = false, roCorpo = null;
  function prepararGlobal() {
    if (globalPronto) return;
    globalPronto = true;
    injetarCSS();
    ouvirMQ(mqHover, modo);
    ouvirMQ(mqCalmo, modo);
    vigiarDpr();
    document.addEventListener('visibilitychange', aoAba);
    window.addEventListener('resize', aoJanela, { passive: true });
    G.vw = window.innerWidth; G.vh = window.innerHeight;
    comMouse = !!(mqHover && mqHover.matches);
    interativo = comMouse && !(mqCalmo && mqCalmo.matches);
    // algo acima de uma seção mudou de altura (fonte, <details>, etc.): ela muda de lugar sem mudar
    // de tamanho; a grade precisa seguir presa à página
    if (window.ResizeObserver && document.body) {
      roCorpo = new ResizeObserver(() => { for (let i = 0; i < instancias.length; i++) instancias[i]._remedir(); });
      roCorpo.observe(document.body);
    }
  }

  /* ================================================================== */
  /* Uma seção                                                          */
  /* ================================================================== */
  function montar(sec, extra) {
    if (!sec || sec.nodeType !== 1) return null;
    if (sec.__lcPontos) return sec.__lcPontos;
    prepararGlobal();
    const op = lerOpcoes(sec, extra);

    const cor = rgba(op.cor) || rgba(PADRAO.cor);
    const acento = rgba(op.acento) || rgba(PADRAO.acento);
    const PAL = [];   // força do azul por degrau de ativação
    for (let k = 0; k <= NP; k++) PAL.push(cssCor(cor, op.opacidade + (op.halo - op.opacidade) * suave(0, 0.7, k / NP)));
    const ACENTO = cssCor(acento, 1);

    /* ---------- camada atrás do conteúdo ---------- */
    const ganhouPos = getComputedStyle(sec).position === 'static';
    if (ganhouPos) sec.classList.add('fxp-pos');
    sec.classList.add('fxp-iso');
    const camada = document.createElement('div');
    camada.className = 'fxp';
    camada.setAttribute('aria-hidden', 'true');
    const cv = document.createElement('canvas');
    cv.width = 0; cv.height = 0;
    cv.setAttribute('aria-hidden', 'true');
    camada.appendChild(cv);
    sec.insertBefore(camada, sec.firstChild);
    let ctx = null;
    try { ctx = cv.getContext('2d'); } catch (e) { ctx = null; }

    const st = {
      W: 0, H: 0, topo: 0, fase: -1, dpr: 1, passoD: 0, s0D: 0, maxD: 0, oxD: 0, oyD: 0, cols: 0, rows: 0,
      val: null, w: null, ativo: null, lista: null, n: 0,
      fr: null, pertoAntes: false, semAlvo: null, semDentro: false, refazer: false,
      interativo: false, mostraGrade: true, bg: '',
      visivel: !('IntersectionObserver' in window), parado: false, sujo: false,
      textoOk: false, tTexto: -1e9,
      cvX: 0, cvY: 0, limpoOk: false, lx0: 0, ly0: 0, lx1: 0, ly1: 0,
      visT: NaN, visL: NaN, visW: 0, visH: 0,
      fundo: null,
      stats: { quadros: 0, desenhos: 0, ms: 0, max: 0 }
    };
    const fundoOp = rgba(op.fundo);
    st.fundo = fundoOp ? cssCor(fundoOp, 1) : fundoAtras(sec);

    /* ---------- grade (em pixels de tela, para ficar nítida) ---------- */
    function grade(W, H, topo) {
      st.W = W; st.H = H; st.topo = topo;
      const dprAntes = st.dpr;
      const dpr = st.dpr = dprAtual();
      const passoD = Math.max(4, Math.round(op.passo * dpr));
      const s0D = Math.max(1, Math.min(passoD - 2, Math.round(op.tam * dpr)));
      const maxD = Math.max(s0D, Math.min(passoD - 2, Math.round(op.max * dpr)));
      const WD = W * dpr, HD = H * dpr;
      // colunas centradas (as seções têm a largura toda, então ficam iguais em todas)
      const cols = WD >= s0D ? Math.floor((WD - s0D) / passoD) + 1 : 0;
      const oxD = Math.floor((WD - ((cols - 1) * passoD + s0D)) / 2);
      // linhas presas à página, incluindo os quadradinhos cortados nas bordas de cima e de baixo
      // (a outra metade é da seção vizinha: juntas, a grade continua sem emenda)
      const fase = faseDe(topo, dpr, passoD);
      const oyD = fase > passoD - s0D ? fase - passoD : fase;
      const rows = HD > oyD ? Math.ceil((HD - oyD) / passoD) : 0;
      const mudou = cols !== st.cols || rows !== st.rows || passoD !== st.passoD || s0D !== st.s0D || oxD !== st.oxD || oyD !== st.oyD || dpr !== dprAntes;
      st.fase = fase;
      st.passoD = passoD; st.s0D = s0D; st.maxD = maxD; st.oxD = oxD; st.oyD = oyD; st.cols = cols; st.rows = rows;
      // a grade parada é CSS: o quadradinho fica no canto de cada ladrilho
      const q = s0D / dpr;
      st.bg = 'conic-gradient(from 0deg at ' + q + 'px ' + q + 'px,rgba(0,0,0,0) 75%,' + cssCor(cor, op.opacidade) + ' 0)';
      camada.style.backgroundImage = st.mostraGrade ? st.bg : 'none';
      camada.style.backgroundSize = passoD / dpr + 'px ' + passoD / dpr + 'px';
      camada.style.backgroundPosition = oxD / dpr + 'px ' + oyD / dpr + 'px';
      if (mudou) {
        const n = cols * rows;
        st.val = new Float32Array(n);
        st.w = new Float32Array(n).fill(1);
        st.ativo = new Uint8Array(n);
        st.lista = new Int32Array(n);
        st.n = 0;
        st.textoOk = false;
        liberar();
      }
    }

    /* ---------- texto: onde o efeito fica fraco ---------- */
    function medirTexto(fr) {
      if (!st.w) return;
      st.w.fill(1);
      st.textoOk = true;
      st.tTexto = performance.now();
      if (!op.evitar || op.texto >= 1) return;
      let els;
      try { els = sec.querySelectorAll(op.evitar); } catch (e) { return; }
      if (!els.length) return;
      const rng = document.createRange();
      for (let e = 0; e < els.length; e++) {
        const el = els[e];
        if (camada.contains(el)) continue;
        rng.selectNodeContents(el);   // as linhas de verdade (não a caixa inteira do bloco)
        const rs = rng.getClientRects();
        for (let k = 0; k < rs.length; k++) {
          const r = rs[k];
          if (r.width < 1 || r.height < 1) continue;
          amortecer(r.left - fr.left, r.top - fr.top, r.right - fr.left, r.bottom - fr.top);
        }
      }
      if (rng.detach) rng.detach();
    }
    function amortecer(x0, y0, x1, y1) {
      const dpr = st.dpr, k = 1 - op.texto, meio = st.s0D / 2;
      x0 -= FOLGA; y0 -= FOLGA; x1 += FOLGA; y1 += FOLGA;
      const i0 = Math.max(0, Math.ceil(((x0 - PENA) * dpr - st.oxD - meio) / st.passoD));
      const i1 = Math.min(st.cols - 1, Math.floor(((x1 + PENA) * dpr - st.oxD - meio) / st.passoD));
      const j0 = Math.max(0, Math.ceil(((y0 - PENA) * dpr - st.oyD - meio) / st.passoD));
      const j1 = Math.min(st.rows - 1, Math.floor(((y1 + PENA) * dpr - st.oyD - meio) / st.passoD));
      for (let j = j0; j <= j1; j++) {
        const cy = (st.oyD + j * st.passoD + meio) / dpr;
        const dy = cy < y0 ? y0 - cy : cy > y1 ? cy - y1 : 0;
        for (let i = i0; i <= i1; i++) {
          const cx = (st.oxD + i * st.passoD + meio) / dpr;
          const dx = cx < x0 ? x0 - cx : cx > x1 ? cx - x1 : 0;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d >= PENA) continue;
          const w = 1 - k * (1 - suave(0, PENA, d)), idx = j * st.cols + i;
          if (w < st.w[idx]) st.w[idx] = w;
        }
      }
    }

    /* ---------- leitura (só nos eventos e observadores: layout limpo) ---------- */
    function ler() {
      const fr = camada.getBoundingClientRect();
      st.fr = fr;
      const topo = fr.top + rolagemY();
      if (st.passoD && faseDe(topo, st.dpr, st.passoD) !== st.fase) { st.topo = topo; st.refazer = true; }   // algo acima mudou de altura
      // o texto pode ter mudado de lugar: mede quando o ponteiro chega (no máximo a cada 3 s)
      const R = op.raio, px = P.x - fr.left, py = P.y - fr.top;
      const perto = P.ok && px > -R && py > -R && px < fr.width + R && py < fr.height + R;
      if (perto && !st.refazer && (!st.textoOk || (!st.pertoAntes && performance.now() - st.tTexto > 3000))) medirTexto(fr);
      st.pertoAntes = perto;
    }

    /* ---------- quadro: contas e desenho (sem ler o DOM) ---------- */
    function passo(dt, vw, vh) {
      const fr = st.fr;
      if (!fr) return false;
      const t0 = performance.now();
      if (st.refazer) { st.refazer = false; grade(st.W, st.H, st.topo); }   // mede o texto de novo no próximo evento
      const dpr = st.dpr, passoD = st.passoD, meio = st.s0D / 2, cols = st.cols, rows = st.rows, oxD = st.oxD, oyD = st.oyD;
      const R = op.raio, R2 = R * R;
      const px = P.x - fr.left, py = P.y - fr.top;
      let perto = P.ok && px > -R && py > -R && px < fr.width + R && py < fr.height + R;
      if (perto && op.sem && P.alvo) {
        if (st.semAlvo !== P.alvo) { st.semAlvo = P.alvo; st.semDentro = !!(P.alvo.closest && P.alvo.closest(op.sem)); }
        if (st.semDentro) perto = false;
      }
      const val = st.val, w = st.w, ativo = st.ativo, lista = st.lista;
      let n = st.n;
      if (!perto && n === 0) { st.sujo = false; liberar(); return false; }

      // células no alcance do ponteiro entram na lista
      if (perto) {
        const i0 = Math.max(0, Math.ceil(((px - R) * dpr - oxD - meio) / passoD));
        const i1 = Math.min(cols - 1, Math.floor(((px + R) * dpr - oxD - meio) / passoD));
        const j0 = Math.max(0, Math.ceil(((py - R) * dpr - oyD - meio) / passoD));
        const j1 = Math.min(rows - 1, Math.floor(((py + R) * dpr - oyD - meio) / passoD));
        for (let j = j0; j <= j1; j++) {
          const base = j * cols;
          for (let i = i0; i <= i1; i++) { const idx = base + i; if (!ativo[idx]) { ativo[idx] = 1; lista[n++] = idx; } }
        }
      }

      // cada célula segue o alvo: sobe rápido, desce devagar
      const kA = 1 - Math.exp((-dt * 3500) / op.entrada);
      const kR = 1 - Math.exp((-dt * 3500) / op.volta);
      let mudou = false;
      for (let a = n - 1; a >= 0; a--) {
        const idx = lista[a];
        let g = 0;
        if (perto) {
          const i = idx % cols, j = (idx - i) / cols;
          const dx = (oxD + i * passoD + meio) / dpr - px, dy = (oyD + j * passoD + meio) / dpr - py;
          const d2 = dx * dx + dy * dy;
          if (d2 < R2) { const q = 1 - d2 / R2; g = q * q * w[idx]; }
        }
        const v = val[idx];
        let nv = v + (g - v) * (g > v ? kA : kR);
        if (nv - v > 0.0008 || v - nv > 0.0008) mudou = true;
        if (g === 0 && nv < SOME) {   // volta para a grade de CSS (as do canto do alcance nem chegam a acender)
          if (v > 0) mudou = true;
          nv = 0; ativo[idx] = 0; lista[a] = lista[--n];
        }
        val[idx] = nv;
      }
      st.n = n;

      // desenha só se algo mudou (valores ou a parte da seção que está na tela)
      const visMudou = fr.top !== st.visT || fr.left !== st.visL || vw !== st.visW || vh !== st.visH;
      st.visT = fr.top; st.visL = fr.left; st.visW = vw; st.visH = vh;
      if (n > 0) {
        if (mudou || visMudou || st.sujo) { desenhar(fr, vw, vh); st.sujo = false; }
      } else liberar();

      const ms = performance.now() - t0;
      st.stats.quadros++; st.stats.ms += ms;
      if (ms > st.stats.max) st.stats.max = ms;
      return n > 0 && mudou;
    }

    /* ---------- desenho (só a área acesa) ---------- */
    const teto64 = (x) => Math.ceil(x / 64) * 64;
    // garante que o canvas cobre a caixa (px de tela, relativos à camada); true se mudou de lugar ou de tamanho
    function posicionar(x0, y0, x1, y1) {
      const bw = x1 - x0, bh = y1 - y0;
      let cw = cv.width, ch = cv.height;
      if (cw >= bw && ch >= bh && x0 >= st.cvX && y0 >= st.cvY && x1 <= st.cvX + cw && y1 <= st.cvY + ch) return false;
      if (cw < bw || ch < bh) {   // cresce com folga, em múltiplos de 64 px de tela
        cw = Math.max(cw, teto64(bw + 160));
        ch = Math.max(ch, teto64(bh + 160));
        cv.width = cw; cv.height = ch;
        cv.style.width = cw / st.dpr + 'px';
        cv.style.height = ch / st.dpr + 'px';
      }
      st.cvX = Math.round(x0 - (cw - bw) / 2);
      st.cvY = Math.round(y0 - (ch - bh) / 2);
      cv.style.transform = 'translate(' + st.cvX / st.dpr + 'px,' + st.cvY / st.dpr + 'px)';
      return true;
    }
    function liberar() {
      st.limpoOk = false;
      if (cv.width || cv.height) { cv.width = 0; cv.height = 0; cv.style.width = '0px'; cv.style.height = '0px'; }
    }
    function desenhar(fr, vw, vh) {
      const dpr = st.dpr, passoD = st.passoD, s0D = st.s0D, maxD = st.maxD, cols = st.cols, oxD = st.oxD, oyD = st.oyD;
      const val = st.val, lista = st.lista, n = st.n;
      // parte visível da camada (px de tela, relativos à camada)
      const vx0 = Math.max(0, -fr.left) * dpr, vy0 = Math.max(0, -fr.top) * dpr;
      const vx1 = Math.min(fr.width, vw - fr.left) * dpr, vy1 = Math.min(fr.height, vh - fr.top) * dpr;
      let bx0 = Infinity, by0 = Infinity, bx1 = -Infinity, by1 = -Infinity;
      for (let a = 0; a < n; a++) {
        const idx = lista[a], i = idx % cols, j = (idx - i) / cols;
        const x = oxD + i * passoD, y = oyD + j * passoD;
        if (x < bx0) bx0 = x;
        if (x > bx1) bx1 = x;
        if (y < by0) by0 = y;
        if (y > by1) by1 = y;
      }
      const m = Math.ceil((maxD - s0D) / 2) + 3;
      bx0 = Math.floor(Math.max(vx0, bx0 - m)); by0 = Math.floor(Math.max(vy0, by0 - m));
      bx1 = Math.ceil(Math.min(vx1, bx1 + s0D + m)); by1 = Math.ceil(Math.min(vy1, by1 + s0D + m));
      if (bx1 <= bx0 || by1 <= by0) { if (cv.width && st.limpoOk) { ctx.clearRect(0, 0, cv.width, cv.height); st.limpoOk = false; } return; }
      const moveu = posicionar(bx0, by0, bx1, by1);
      const X = st.cvX, Y = st.cvY;
      const cx0 = bx0 - X, cy0 = by0 - Y, cx1 = bx1 - X, cy1 = by1 - Y;   // área deste quadro, no canvas
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      // limpa só o que foi desenhado no quadro anterior e o que vai ser desenhado agora
      if (moveu || !st.limpoOk) ctx.clearRect(0, 0, cv.width, cv.height);
      else ctx.clearRect(Math.min(cx0, st.lx0), Math.min(cy0, st.ly0), Math.max(cx1, st.lx1) - Math.min(cx0, st.lx0), Math.max(cy1, st.ly1) - Math.min(cy0, st.ly0));
      st.lx0 = cx0; st.ly0 = cy0; st.lx1 = cx1; st.ly1 = cy1; st.limpoOk = true;
      ctx.save();
      ctx.beginPath();
      ctx.rect(cx0, cy0, cx1 - cx0, cy1 - cy0);
      ctx.clip();   // nada fora da área deste quadro (assim a próxima limpeza alcança tudo)

      // 1) cobre o quadradinho de CSS de baixo com a cor do fundo (assim o aceso não soma com ele)
      if (st.fundo) {
        ctx.fillStyle = st.fundo;
        ctx.beginPath();
        for (let a = 0; a < n; a++) {
          const idx = lista[a], i = idx % cols, j = (idx - i) / cols;
          const x = oxD + i * passoD - X, y = oyD + j * passoD - Y;
          if (x + s0D + 2 < cx0 || y + s0D + 2 < cy0 || x - 2 > cx1 || y - 2 > cy1) continue;
          ctx.rect(x - 2, y - 2, s0D + 4, s0D + 4);
        }
        ctx.fill();
      }
      // 2) o quadrado azul cresce do centro e ganha força (lado inteiro em px de tela: nítido)
      let ult = -1;
      for (let a = 0; a < n; a++) {
        const idx = lista[a], v = val[idx], i = idx % cols, j = (idx - i) / cols;
        const sz = Math.round(s0D + (maxD - s0D) * v);
        const x = oxD + i * passoD - X + Math.round((s0D - sz) / 2), y = oyD + j * passoD - Y + Math.round((s0D - sz) / 2);
        if (x + sz < cx0 || y + sz < cy0 || x > cx1 || y > cy1) continue;
        const k = Math.round(v * NP);
        if (k !== ult) { ctx.fillStyle = PAL[k]; ult = k; }
        ctx.fillRect(x, y, sz, sz);
      }
      // 3) miolo laranja, de dentro para fora, só no centro
      ctx.fillStyle = ACENTO;
      for (let a = 0; a < n; a++) {
        const idx = lista[a], v = val[idx];
        if (v <= MIOLO[0]) continue;
        const sz = Math.round(s0D + (maxD - s0D) * v), c = Math.round(sz * suave(MIOLO[0], MIOLO[1], v));
        if (c < 1) continue;
        const i = idx % cols, j = (idx - i) / cols;
        const x = oxD + i * passoD - X + Math.round((s0D - sz) / 2) + ((sz - c) >> 1);
        const y = oyD + j * passoD - Y + Math.round((s0D - sz) / 2) + ((sz - c) >> 1);
        if (x + c < cx0 || y + c < cy0 || x > cx1 || y > cy1) continue;
        ctx.fillRect(x, y, c, c);
      }
      ctx.restore();
      st.stats.desenhos++;
    }

    function zerar() {
      if (st.val) for (let a = 0; a < st.n; a++) { const idx = st.lista[a]; st.val[idx] = 0; st.ativo[idx] = 0; }
      st.n = 0;
      liberar();
    }

    /* ---------- modo, tamanho, tela ---------- */
    function aplicarModo() {
      st.mostraGrade = comMouse || op.toque !== 'nada';
      if (st.bg) camada.style.backgroundImage = st.mostraGrade ? st.bg : 'none';
      const novo = interativo && !!ctx;
      if (!novo && st.interativo) zerar();
      if (novo && !st.interativo) st.textoOk = false;
      st.interativo = novo;
    }
    // chamado nos observadores (layout limpo): tamanho, lugar na página e texto
    function ajustar(W, H) {
      const fr = camada.getBoundingClientRect();
      st.fr = fr;
      const topo = fr.top + rolagemY();
      if (W === st.W && H === st.H && dprAtual() === st.dpr && st.cols && faseDe(topo, st.dpr, st.passoD) === st.fase) return;
      grade(W, H, topo);
      if (st.interativo) medirTexto(fr); else st.textoOk = false;
      st.sujo = true;
      if (st.n) acordar();
    }
    function remedir() { const r = camada.getBoundingClientRect(); ajustar(r.width, r.height); }

    let ro = null, io = null;
    if (window.ResizeObserver) {
      ro = new ResizeObserver((es) => { const b = es[es.length - 1].contentRect; ajustar(b.width, b.height); });
      ro.observe(camada);
    } else {
      window.addEventListener('resize', remedir);
      remedir();
    }
    if (window.IntersectionObserver) {
      io = new IntersectionObserver((es) => {
        st.visivel = es[es.length - 1].isIntersecting;
        if (!st.visivel) zerar();
        else if (st.cols && st.interativo) { ler(); acordar(); }
      }, { rootMargin: '0px' });
      io.observe(sec);
    }
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { st.textoOk = false; });

    const api = {
      el: sec,
      camada,
      canvas: cv,
      opcoes: op,
      pausar() { st.parado = true; zerar(); },
      continuar() { st.parado = false; acordar(); },
      medir() { if (st.cols) medirTexto(camada.getBoundingClientRect()); },
      redesenhar() { st.sujo = true; acordar(); },
      destruir() {
        zerar();
        if (ro) ro.disconnect();
        if (io) io.disconnect();
        window.removeEventListener('resize', remedir);
        if (camada.parentNode) camada.parentNode.removeChild(camada);
        sec.classList.remove('fxp-iso');
        if (ganhouPos) sec.classList.remove('fxp-pos');
        delete sec.__lcPontos;
        const i = instancias.indexOf(api);
        if (i >= 0) instancias.splice(i, 1);
        if (!instancias.length) { tirarOuvintes(); pararLaco(); }
      },
      // números desta seção (tempo de JS das contas e do desenho, sem a GPU)
      stats(zerarStats) {
        const s = st.stats;
        const r = {
          quadros: s.quadros, desenhos: s.desenhos,
          msPorQuadro: s.quadros ? +(s.ms / s.quadros).toFixed(3) : 0,
          msMax: +s.max.toFixed(3),
          acesos: st.n, rodando: !!G.raf, interativo: st.interativo, grade: st.mostraGrade,
          visivel: st.visivel, canvas: cv.width + 'x' + cv.height, dpr: st.dpr,
          celulas: st.cols + 'x' + st.rows, passoTela: st.passoD, ladoTela: st.s0D, fase: st.fase, fundo: st.fundo
        };
        if (zerarStats) { s.quadros = 0; s.desenhos = 0; s.ms = 0; s.max = 0; }
        return r;
      },
      // célula mais perto de (x, y) em px CSS relativos à seção: ativação e força (1 = livre, menor = atrás de texto)
      celula(x, y) {
        if (!st.cols) return null;
        const i = Math.round((x * st.dpr - st.oxD - st.s0D / 2) / st.passoD);
        const j = Math.round((y * st.dpr - st.oyD - st.s0D / 2) / st.passoD);
        if (i < 0 || j < 0 || i >= st.cols || j >= st.rows) return null;
        const idx = j * st.cols + i;
        return { i, j, val: +st.val[idx].toFixed(3), forca: +st.w[idx].toFixed(3) };
      },
      // para o controle compartilhado
      _pronta() { return st.interativo && st.visivel && !st.parado && st.cols > 0 && st.rows > 0; },
      _ler: ler,
      _passo: passo,
      _acesos() { return st.n > 0; },
      _quer() { return st.n > 0 || st.sujo || st.refazer || (P.ok && st.pertoAntes); },
      _modo: aplicarModo,
      _remedir: remedir
    };
    sec.__lcPontos = api;
    instancias.push(api);
    aplicarModo();
    if (interativo) porOuvintes();
    return api;
  }

  function iniciarTodos() {
    const lista = document.querySelectorAll('[data-pontos]');
    for (let i = 0; i < lista.length; i++) montar(lista[i]);
  }

  window.LCPontos = {
    montar,
    iniciar: iniciarTodos,
    instancias,
    // tempo do laço compartilhado (todas as seções juntas; o laço não lê o DOM)
    stats(zerarStats) {
      const k = Math.min(G.na, 256), a = Array.prototype.slice.call(G.amostras, 0, k).sort((x, y) => x - y);
      const r = {
        quadros: G.quadros,
        msPorQuadro: G.quadros ? +(G.ms / G.quadros).toFixed(3) : 0,
        msP95: k ? +a[Math.min(k - 1, Math.floor(k * 0.95))].toFixed(3) : 0,
        msMax: +G.max.toFixed(3), leituras: G.leituras,
        rodando: !!G.raf, interativo, comMouse, ouvindo: G.ouvindo, ponteiro: P.ok
      };
      if (zerarStats) { G.quadros = 0; G.ms = 0; G.max = 0; G.na = 0; G.leituras = 0; }
      return r;
    }
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciarTodos, { once: true });
  else iniciarTodos();
})();
