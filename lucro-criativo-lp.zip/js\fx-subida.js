/*
  fx-subida.js · passagem em quadrados entre duas seções (Imersão Lucro Criativo · Koko)
  Direção de arte: Lara Sena · referência: _refs/pins/2_pixels_subindo.mp4, em versão bem mais sutil

  O que faz
  - A faixa [data-subida] tem altura fixa: N fileiras (padrão 6) de quadrados de max(14px, 2,2vw).
    A fileira de cima é sempre da cor "de" (a seção de cima) e a de baixo sempre da cor "para"
    (a seção de baixo). No meio, cada coluna é uma pilha só, "de" em cima e "para" embaixo, e a
    divisa muda de altura de coluna para coluna numa escada irregular (ruído suave em degraus de
    um quadrado, com uns poucos pilares de uma coluna). Nenhum quadrado fica solto no ar.
  - Com a rolagem, a divisa sobe em degraus, coluna por coluna (o quadrado troca de cor inteiro,
    sem fade): a cor "para" toma a faixa e a cor de cima se desmancha subindo. O progresso vai de
    0 (a faixa entrando por baixo da tela) a 1 (saindo por cima); a escada se forma e se desfaz no
    meio desse caminho, e nas pontas a divisa fica reta, como uma borda de seção comum.
  - Uns poucos quadrados que viram piscam um instante (0,11 a 0,2 s) numa cor de acento e assentam.
    As cores de acento são as de data-cores menos "de" e "para" (no padrão: laranja e branco).
    No máximo 2 ao mesmo tempo por faixa; o mesmo quadrado não repete em seguida.
  - Parada, a faixa fica no degrau em que está, sem nada piscando. Com prefers-reduced-motion,
    fica numa escada parada no meio da passagem (não acompanha a rolagem, sem faíscas).
  - Nítido: os quadrados têm bordas em pixel inteiro do aparelho, encostam um no outro e cobrem a
    faixa inteira; o canvas tem o tamanho da faixa em pixels do aparelho (devicePixelRatio
    limitado a 2) e image-rendering: pixelated como garantia.
  - Desempenho: não tem laço contínuo. Com a faixa na tela (IntersectionObserver), cada evento de
    rolagem (passivo, um por quadro) lê uma medida por faixa (getBoundingClientRect) e pede um
    quadro; o quadro só calcula e pinta os quadrados que mudaram, sem ler layout. A leitura fica no
    evento de rolagem porque ele chega antes dos requestAnimationFrame dos outros efeitos, com o
    layout em dia (não força reflow). Fora da tela a faixa nem ouve a rolagem; com a aba escondida
    não pinta. Tamanho e primeiro desenho pelo ResizeObserver (inclusive troca de zoom/monitor).
  - O CSS vem junto (um <style id="fx-subida-css">), o lp.css não precisa de nada (ver CLS abaixo).
  - Acessível: a faixa é enfeite (aria-hidden) e não tem texto; o conteúdo da página não muda.

  Uso
    <div class="subida" data-subida data-de="#0100FE" data-para="#F2F2F2" data-cores="#0100FE,#FF5A1F,#FFFFFF"></div>
    <script src="js/fx-subida.js" defer></script>
  O módulo se inicia sozinho em todo [data-subida]. Opções por atributo:
    data-de        cor de cima (a seção anterior)                              padrão #0100FE
    data-para      cor de baixo (a seção seguinte)                             padrão #F2F2F2
    data-cores     cores das faíscas, separadas por vírgula; as iguais a "de" e "para" ficam de fora
                                                                               padrão #0100FE,#FF5A1F,#FFFFFF
    data-fileiras  número de fileiras de quadrados (3 a 16)                    padrão 6
    data-quadrado  lado do quadrado, em vw                                     padrão 2.2
    data-min       lado mínimo do quadrado, em px                              padrão 14
    data-faiscas   chance de um quadrado que vira piscar (0 a 1; 0 = nenhuma)  padrão 0.06
    data-semente   muda o desenho da escada                                    padrão 1, 2, 3… na ordem da página
    data-parado    número de 0 a 1: fica parado nesse ponto da passagem (não acompanha a rolagem)
  Ou à mão: LCSubida.montar(el, { de, para, cores, fileiras, quadrado, min, faiscas, semente, parado })
  devolve { el, atualizar, destruir, stats, alturas }; LCSubida.instancias lista as faixas.
  Altura e CLS: o CSS injetado dá a altura, mas o script é defer e pode rodar depois da primeira
  pintura; se a faixa já estiver na tela nessa hora, o que vem embaixo pula. Para CLS zero, a
  altura (e a cor de repouso) precisam vir no HTML/CSS da página, por exemplo no próprio div:
    style="height:calc(6*max(14px,2.2vw));background:linear-gradient(#0100FE calc(100% - max(14px,2.2vw)),#FFFFFF 0)"
  (6 = data-fileiras; 2.2vw/14px = data-quadrado/data-min; as duas cores = data-de/data-para).
*/
(function () {
  'use strict';
  if (window.LCSubida) return;

  var CSS_ID = 'fx-subida-css';
  var CSS =
    '[data-subida]{--subida-q:max(var(--subida-min,14px),var(--subida-vw,2.2vw));position:relative;display:block;' +
    'height:calc(var(--subida-fileiras,6) * var(--subida-q));overflow:hidden;contain:layout paint;' +
    // antes do primeiro desenho: o estado de repouso (tudo "de", só a fileira de baixo "para")
    'background:linear-gradient(var(--subida-de,#0100FE) calc(100% - var(--subida-q)),var(--subida-para,#F2F2F2) 0)}' +
    '[data-subida]>canvas{position:absolute;left:0;top:0;width:100%;height:100%;display:block;image-rendering:pixelated}';

  var PADRAO = { de: '#0100FE', para: '#F2F2F2', cores: '#0100FE,#FF5A1F,#FFFFFF', fileiras: 6, quadrado: 2.2, min: 14, faiscas: 0.06 };
  var JANELA = [0.08, 0.84];    // trecho do progresso da rolagem em que a escada se forma e se desfaz
  var P_CALMO = 0.5;            // ponto da passagem no prefers-reduced-motion
  var DPR_MAX = 2;
  var FAISCA_MS = [110, 200];   // quanto dura o piscar
  var MAX_ACESAS = 2;           // faíscas acesas ao mesmo tempo, por faixa
  var DESCANSO_MS = 900;        // o mesmo quadrado não pisca de novo antes disso
  // forma da escada (unidades: colunas e fileiras)
  var ESCADA = { l1: 5.5, a1: 1, l2: 2.2, a2: 0.35, pilar: 0.2, folga: 3, abre: 0.95 };

  /* ------------------------------------------------------------------ */
  /* utilidades                                                          */
  /* ------------------------------------------------------------------ */
  function semear(s) {   // mulberry32: o mesmo desenho a cada visita
    var a = (Math.imul(s | 0, 2654435761) >>> 0) || 1;
    return function () {
      a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function ruido(rnd, n) {   // ruído de valor 1D, suave, em [-1, 1]
    var v = [];
    for (var i = 0; i < n; i++) v.push(rnd() * 2 - 1);
    return function (x) {
      var k = Math.floor(x), f = x - k, s = f * f * (3 - 2 * f);
      var a = v[((k % n) + n) % n], b = v[(((k + 1) % n) + n) % n];
      return a + (b - a) * s;
    };
  }
  function lim(x, a, b) { return x < a ? a : x > b ? b : x; }
  function pega() { for (var i = 0; i < arguments.length; i++) { var v = arguments[i]; if (v !== undefined && v !== null && v !== '') return v; } }
  function num(v, d, a, b) { var x = parseFloat(v); return isFinite(x) ? lim(x, a, b) : d; }
  var ctxCor = null;
  function cor(v) {   // qualquer cor CSS, normalizada (#rrggbb); '' se não for cor
    v = String(v == null ? '' : v).trim();
    if (!v) return '';
    if (!ctxCor) ctxCor = document.createElement('canvas').getContext('2d');
    ctxCor.fillStyle = '#010203'; ctxCor.fillStyle = v;
    var a = String(ctxCor.fillStyle).toLowerCase();
    if (a === '#010203') { ctxCor.fillStyle = '#040506'; ctxCor.fillStyle = v; if (String(ctxCor.fillStyle).toLowerCase() === '#040506') return ''; }
    return a;
  }
  function ouvirMQ(mq, f) { if (mq.addEventListener) mq.addEventListener('change', f); else if (mq.addListener) mq.addListener(f); }
  function largarMQ(mq, f) { if (mq.removeEventListener) mq.removeEventListener('change', f); else if (mq.removeListener) mq.removeListener(f); }
  var agora = (window.performance && performance.now) ? function () { return performance.now(); } : function () { return Date.now(); };

  function injetarCSS() {
    if (document.getElementById(CSS_ID)) return;
    var s = document.createElement('style');
    s.id = CSS_ID;
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  /* ------------------------------------------------------------------ */
  /* estado comum                                                        */
  /* ------------------------------------------------------------------ */
  var instancias = [];
  var calmoMQ = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
  var calmo = !!(calmoMQ && calmoMQ.matches);
  var temIO = 'IntersectionObserver' in window, temRO = 'ResizeObserver' in window;
  var io = null, ro = null, raf = 0, rolagemLigada = false, mqDpr = null;
  var alturaTela = window.innerHeight || document.documentElement.clientHeight || 800;
  var geral = { quadros: 0, ms: 0, msMax: 0, ultimos: new Float32Array(240) };

  /* ------------------------------------------------------------------ */
  /* uma faixa                                                           */
  /* ------------------------------------------------------------------ */
  function montar(el, op) {
    if (!el) return null;
    if (el.__lcSubida) return el.__lcSubida;
    op = op || {};
    injetarCSS();
    var at = function (n) { return el.getAttribute('data-' + n); };
    var de = cor(pega(op.de, at('de'))) || PADRAO.de.toLowerCase();
    var para = cor(pega(op.para, at('para'))) || PADRAO.para.toLowerCase();
    var acentos = [];
    String(pega(op.cores, at('cores'), PADRAO.cores)).split(',').forEach(function (s) {
      var c = cor(s);
      if (c && c !== de && c !== para && acentos.indexOf(c) < 0) acentos.push(c);
    });
    var R = Math.round(num(pega(op.fileiras, at('fileiras')), PADRAO.fileiras, 3, 16));
    var vw = num(pega(op.quadrado, at('quadrado')), PADRAO.quadrado, 0.2, 20);
    var minPx = num(pega(op.min, at('min')), PADRAO.min, 2, 200);
    var taxa = num(pega(op.faiscas, at('faiscas')), PADRAO.faiscas, 0, 1);
    var semente = Math.round(num(pega(op.semente, at('semente')), instancias.length + 1, -1e9, 1e9));
    var paradoEm = num(pega(op.parado, at('parado')), NaN, 0, 1);
    var pal = [de, para].concat(acentos);   // 0 = de, 1 = para, 2… = acentos

    if (!el.hasAttribute('data-subida')) el.setAttribute('data-subida', '');
    if (!el.hasAttribute('aria-hidden')) el.setAttribute('aria-hidden', 'true');
    var st = el.style;
    st.setProperty('--subida-fileiras', String(R));
    st.setProperty('--subida-vw', vw + 'vw');
    st.setProperty('--subida-min', minPx + 'px');
    st.setProperty('--subida-de', de);
    st.setProperty('--subida-para', para);

    var cv = document.createElement('canvas');
    cv.setAttribute('aria-hidden', 'true');
    el.appendChild(cv);
    var ctx = cv.getContext('2d');

    // grade
    var C = 0, Wd = 0, Hd = 0, dpr = 0, wCss = 0, hCss = 0;
    var xs = null, ys = null;
    // escada
    var desloc = null, pilar = null, g0 = 0, g1 = 1, alt = null;
    // pintura e faíscas
    var mostrado = null, alvo = null, fimF = null, corF = null, ativas = [];
    var topo = 0, prog = -1, vivo = true;
    var est = { quadros: 0, ms: 0, msMax: 0, pintadas: 0, faiscas: 0 };

    function montarEscada() {
      var r1 = ruido(semear(semente * 7 + 1), Math.ceil(C / ESCADA.l1) + 3);
      var r2 = ruido(semear(semente * 13 + 5), Math.ceil(C / ESCADA.l2) + 3);
      var r3 = semear(semente * 17 + 9);
      desloc = new Float32Array(C); pilar = new Int8Array(C);
      var lo = Infinity, hi = -Infinity, c, v, espera = 0;
      for (c = 0; c < C; c++) {
        v = ESCADA.a1 * r1(c / ESCADA.l1 + 0.37) + ESCADA.a2 * r2(c / ESCADA.l2 + 0.11);
        desloc[c] = v; if (v < lo) lo = v; if (v > hi) hi = v;
        var q = r3();   // pilares e entalhes de uma coluna, sempre afastados entre si
        if (espera > 0) espera--;
        else if (q < ESCADA.pilar) { pilar[c] = q < ESCADA.pilar / 2 ? -1 : 1; espera = ESCADA.folga - 1; }
      }
      // a escada ocupa as fileiras do meio
      var abre = (R - 2) * ESCADA.abre, meio = (lo + hi) / 2, k = hi > lo ? abre / (hi - lo) : 0;
      for (c = 0; c < C; c++) desloc[c] = (desloc[c] - meio) * k;
      hi = abre / 2 + 1; lo = -abre / 2 - 1;   // +-1 dos pilares
      g0 = 1.49 - hi;        // progresso 0: só a fileira de baixo na cor "para"
      g1 = R - 1.5 - lo;     // progresso 1: só a fileira de cima na cor "de"
      alt = new Int8Array(C);   // 0 = ainda sem altura
      fimF = new Float64Array(C * R); corF = new Uint8Array(C * R); ativas = [];
    }

    // tamanho: w/h em px CSS; wD/hD (opcionais) em pixels do aparelho, exatos
    function medir(w, h, wD, hD) {
      var d = Math.min(DPR_MAX, window.devicePixelRatio || 1);
      var W = wD && (window.devicePixelRatio || 1) <= DPR_MAX ? wD : Math.round(w * d);
      var H = hD && (window.devicePixelRatio || 1) <= DPR_MAX ? hD : Math.round(h * d);
      wCss = w; hCss = h;
      if (W === Wd && H === Hd && d === dpr && C) return false;
      dpr = d; Wd = W; Hd = H;
      if (W < 1 || H < 1) { C = 0; return false; }
      cv.width = W; cv.height = H;
      var nC = Math.max(1, Math.round(W / (H / R))), i;
      xs = new Int32Array(nC + 1); for (i = 0; i <= nC; i++) xs[i] = Math.round(i * W / nC);
      ys = new Int32Array(R + 1); for (i = 0; i <= R; i++) ys[i] = Math.round(i * H / R);
      if (nC !== C) { C = nC; montarEscada(); }
      mostrado = new Uint8Array(C * R); mostrado.fill(255);   // canvas novo: pinta tudo
      alvo = new Uint8Array(C * R);
      return true;
    }

    function faiscar(c, v, n, t, limite) {   // quadrados que viraram nesta coluna
      var a = v < n ? v : n, b = v < n ? n : v;
      for (var k = a; k < b; k++) {
        if (ativas.length >= limite) return;
        var r = R - 1 - k, i = c * R + r;
        if (t < fimF[i] + DESCANSO_MS || Math.random() >= taxa) continue;
        corF[i] = 2 + ((Math.random() * acentos.length) | 0);
        fimF[i] = t + FAISCA_MS[0] + Math.random() * (FAISCA_MS[1] - FAISCA_MS[0]);
        ativas.push(i); est.faiscas++;
      }
    }

    function calcular(t, quieto) {   // quieto: redesenho por tamanho, sem faísca nova
      var fixo = calmo || paradoEm === paradoEm, pe;
      if (fixo) pe = paradoEm === paradoEm ? paradoEm : P_CALMO;
      else {
        var p = (alturaTela - topo) / (alturaTela + hCss);
        pe = lim((p - JANELA[0]) / (JANELA[1] - JANELA[0]), 0, 1);
      }
      prog = pe;
      var g = g0 + (g1 - g0) * pe, pode = !fixo && !quieto && taxa > 0 && acentos.length > 0;
      var limite = MAX_ACESAS;
      for (var c = 0; c < C; c++) {
        var n = Math.round(g + desloc[c]) + pilar[c];
        n = n < 1 ? 1 : n > R - 1 ? R - 1 : n;
        var v = alt[c];
        if (n !== v) { if (v && pode) faiscar(c, v, n, t, limite); alt[c] = n; }
      }
    }

    function pintar(t) {
      var j, i, c, r, k;
      for (j = ativas.length - 1; j >= 0; j--) if (fimF[ativas[j]] <= t) { ativas[j] = ativas[ativas.length - 1]; ativas.pop(); }
      var muda = 0;
      for (c = 0; c < C; c++) {
        var h = alt[c], base = c * R;
        for (r = 0; r < R; r++) {
          i = base + r;
          k = (R - 1 - r) < h ? 1 : 0;
          if (fimF[i] > t) k = corF[i];
          alvo[i] = k;
          if (mostrado[i] !== k) muda++;
        }
      }
      if (muda) {
        for (k = 0; k < pal.length; k++) {   // uma troca de cor por paleta
          var pronta = false;
          for (c = 0; c < C; c++) {
            var x = xs[c], w = xs[c + 1] - x;
            for (r = 0; r < R; r++) {
              i = c * R + r;
              if (alvo[i] !== k || mostrado[i] === k) continue;
              if (!pronta) { ctx.fillStyle = pal[k]; pronta = true; }
              ctx.fillRect(x, ys[r], w, ys[r + 1] - ys[r]);
              mostrado[i] = k;
            }
          }
        }
        est.pintadas += muda;
      }
      return ativas.length > 0;
    }

    var I = {
      el: el,
      _visivel: !temIO,
      _fixo: paradoEm === paradoEm,
      _ler: function () { var b = el.getBoundingClientRect(); topo = b.top; return b; },
      _topo: function (y) { topo = y; },
      _quadro: function (t, quieto) {   // com o topo já lido; devolve true se ainda há faísca acesa
        if (!vivo || !C) return false;
        var t0 = agora();
        calcular(t, quieto);
        var mais = pintar(t);
        var dt = agora() - t0;
        est.quadros++; est.ms += dt; if (dt > est.msMax) est.msMax = dt;
        return mais;
      },
      _medir: function (w, h, wD, hD) { return medir(w, h, wD, hD); },
      _remedir: function () { var b = I._ler(); if (medir(b.width, b.height) && I._quadro(agora(), true)) pedir(); },
      _apagarFaiscas: function () { if (fimF) { fimF.fill(0); ativas = []; } },
      atualizar: function () { var b = I._ler(); medir(b.width, b.height); if (I._quadro(agora(), true)) pedir(); },   // à mão (mede e redesenha)
      alturas: function () { return alt ? Array.prototype.slice.call(alt) : []; },
      stats: function (zerar) {
        var s = {
          progresso: +prog.toFixed(3), visivel: I._visivel, calmo: calmo, parado: paradoEm === paradoEm,
          colunas: C, fileiras: R, canvas: Wd + 'x' + Hd, dpr: dpr, quadradoCss: R ? +(hCss / R).toFixed(2) : 0,
          cores: pal.slice(), quadros: est.quadros,
          msMedio: est.quadros ? +(est.ms / est.quadros).toFixed(4) : 0, msMax: +est.msMax.toFixed(4),
          pintadas: est.pintadas, faiscas: est.faiscas, faiscasAcesas: ativas.length
        };
        if (zerar) { est.quadros = 0; est.ms = 0; est.msMax = 0; est.pintadas = 0; est.faiscas = 0; }
        return s;
      },
      destruir: function () {
        vivo = false;
        if (io) io.unobserve(el);
        if (ro) ro.unobserve(el);
        if (cv.parentNode) cv.parentNode.removeChild(cv);
        delete el.__lcSubida;
        var k = instancias.indexOf(I); if (k >= 0) instancias.splice(k, 1);
        ligarRolagem();
      }
    };
    el.__lcSubida = I;
    instancias.push(I);
    observar(I);
    return I;
  }

  /* ------------------------------------------------------------------ */
  /* laço comum: só roda quando a rolagem mexe (ou uma faísca está acesa) */
  /* ------------------------------------------------------------------ */
  function pedir() { if (!raf && !document.hidden) raf = requestAnimationFrame(laco); }
  // o quadro só calcula e pinta: a medida (topo da faixa) já foi lida no evento de rolagem, no
  // IntersectionObserver ou no ResizeObserver, momentos em que o layout está em dia (não força reflow)
  function laco() {
    raf = 0;
    if (document.hidden || calmo) return;   // calmo: só muda com o tamanho ou com a preferência
    var t0 = agora(), i, mais = false, n = 0;
    for (i = 0; i < instancias.length; i++) {
      var J = instancias[i];
      if (J._visivel && !J._fixo) { n++; if (J._quadro(t0)) mais = true; }
    }
    if (!n) return;
    var dt = agora() - t0 + leitura;   // tempo do quadro = leitura da medida + cálculo + pintura
    leitura = 0;
    geral.ultimos[geral.quadros % geral.ultimos.length] = dt;
    geral.quadros++; geral.ms += dt; if (dt > geral.msMax) geral.msMax = dt;
    if (typeof api.aoQuadro === 'function') api.aoQuadro(t0, dt);
    if (mais) pedir();
  }
  // o evento de rolagem chega uma vez por quadro, antes dos requestAnimationFrame desse quadro
  var leitura = 0;
  function aoRolar() {
    if (document.hidden) return;
    var t0 = agora();
    for (var i = 0; i < instancias.length; i++) { var J = instancias[i]; if (J._visivel && !J._fixo) J._ler(); }
    leitura += agora() - t0;
    pedir();
  }
  function ligarRolagem() {
    var precisa = false;
    if (!calmo) for (var i = 0; i < instancias.length; i++) if (instancias[i]._visivel && !instancias[i]._fixo) { precisa = true; break; }
    if (precisa === rolagemLigada) return;
    rolagemLigada = precisa;
    if (precisa) window.addEventListener('scroll', aoRolar, { passive: true });
    else window.removeEventListener('scroll', aoRolar, { passive: true });
  }

  function observar(I) {
    if (temIO) {
      if (!io) io = new IntersectionObserver(function (es) {
        for (var k = 0; k < es.length; k++) {
          var J = es[k].target.__lcSubida;
          if (J) { J._visivel = es[k].isIntersecting; J._topo(es[k].boundingClientRect.top); }
        }
        ligarRolagem();
        pedir();
      }, { rootMargin: '80px 0px' });
      io.observe(I.el);
    }
    if (temRO) {
      if (!ro) ro = new ResizeObserver(function (es) {
        var t = agora();
        for (var k = 0; k < es.length; k++) {
          var e = es[k], J = e.target.__lcSubida;
          if (!J) continue;
          var dp = e.devicePixelContentBoxSize && e.devicePixelContentBoxSize[0];
          if (J._medir(e.contentRect.width, e.contentRect.height, dp ? dp.inlineSize : 0, dp ? dp.blockSize : 0)) { J._ler(); if (J._quadro(t, true)) pedir(); }
        }
      });
      try { ro.observe(I.el, { box: 'device-pixel-content-box' }); } catch (err) { ro.observe(I.el); }
    }
  }

  // aba escondida: nada pinta; ao voltar, relê a posição e um quadro acerta o estado
  document.addEventListener('visibilitychange', function () {
    if (document.hidden) { if (raf) { cancelAnimationFrame(raf); raf = 0; } }
    else aoRolar();
  });
  window.addEventListener('resize', function () {
    alturaTela = window.innerHeight || alturaTela;
    if (!temRO) for (var i = 0; i < instancias.length; i++) instancias[i]._remedir();
    pedir();
  }, { passive: true });
  if (calmoMQ) ouvirMQ(calmoMQ, function () {
    calmo = calmoMQ.matches;
    for (var i = 0; i < instancias.length; i++) { instancias[i]._apagarFaiscas(); instancias[i]._ler(); instancias[i]._quadro(agora(), true); }
    ligarRolagem();
  });
  function vigiarDpr() {   // reserva para navegador sem device-pixel-content-box
    if (!window.matchMedia) return;
    if (mqDpr) largarMQ(mqDpr, aoMudarDpr);
    mqDpr = window.matchMedia('(resolution: ' + (window.devicePixelRatio || 1) + 'dppx)');
    ouvirMQ(mqDpr, aoMudarDpr);
  }
  function aoMudarDpr() { for (var i = 0; i < instancias.length; i++) instancias[i]._remedir(); vigiarDpr(); }

  // primeiro desenho: com ResizeObserver, no primeiro aviso dele (depois do layout, sem forçar
  // reflow no meio do carregamento); sem ele, medindo na hora, todas as leituras juntas
  function primeiro(lista) {
    if (!mqDpr) vigiarDpr();
    if (temRO || !lista.length) return;
    var medidas = [], i, b, t;
    for (i = 0; i < lista.length; i++) medidas.push(lista[i]._ler());
    t = agora();
    for (i = 0; i < lista.length; i++) { b = medidas[i]; lista[i]._medir(b.width, b.height); lista[i]._quadro(t, true); }
  }
  function iniciar() {
    var els = document.querySelectorAll('[data-subida]'), novas = [], i, I;
    for (i = 0; i < els.length; i++) if (!els[i].__lcSubida && (I = montar(els[i]))) novas.push(I);
    primeiro(novas);
  }

  var api = {
    montar: function (el, op) { var ja = el && el.__lcSubida, I = montar(el, op); if (I && !ja) primeiro([I]); return I; },
    iniciar: iniciar,
    instancias: instancias,
    aoQuadro: null,   // gancho de teste: função(t, ms) chamada depois de cada quadro
    _escada: ESCADA,  // forma da escada (ajuste fino; vale para as faixas montadas depois)
    _janela: JANELA,
    stats: function (zerar) {   // tempo de cada quadro (leitura da medida + cálculo + pintura), em ms
      var n = Math.min(geral.quadros, geral.ultimos.length), v = Array.prototype.slice.call(geral.ultimos, 0, n).sort(function (a, b) { return a - b; });
      var s = { quadros: geral.quadros, msMedio: geral.quadros ? +(geral.ms / geral.quadros).toFixed(4) : 0, msP95: n ? +v[Math.min(n - 1, Math.floor(n * 0.95))].toFixed(4) : 0, msMax: +geral.msMax.toFixed(4), rolagemLigada: rolagemLigada, calmo: calmo };
      if (zerar) { geral.quadros = 0; geral.ms = 0; geral.msMax = 0; }
      return s;
    }
  };
  window.LCSubida = api;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar);
  else iniciar();
})();
