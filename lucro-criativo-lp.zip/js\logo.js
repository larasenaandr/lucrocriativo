/* Lucro Criativo · motor da logo
   A logo final vem de logo-data.js (moeda em pixel na altura das duas linhas, letras em curva; a mão saiu em 26/11).
   A moeda é uma moeda de verdade: cara = moeda em pixel, coroa = faísca. Ela gira no eixo vertical e é
   redesenhada na grade a cada quadro (os quadrados ficam no lugar; muda quem acende e o tamanho de cada um).
   Do lado da faísca, ela "pensa" como o Claude: passa por ✢ ✳ ✶ ✻ ✽ e assenta na faísca da marca. */
window.LCLogo = (function () {
  const D = window.LC_LOGO, G = D.grid, NS = 'http://www.w3.org/2000/svg';
  const R = D.coin.r, T = 1.6;                       // raio e espessura da moeda, em quadrados
  const gx = i => G.ox + i * G.px, gy = j => G.oy + j * G.py;
  const CC = [gx(D.coin.k0), gy(D.coin.l0)];
  const CW = G.px * G.sq, CH = G.py * G.sq;
  const COIN = new Set(D.coin.cells.map(c => c[0] + ',' + c[1]));

  // formas da faísca (unidades: quadrados; len é fração do raio)
  const BRAND = { n: 11, len: [1, .855, .942, .797, .913, .841, .768, .957, .826, .899, .783], jit: [0, 4, -3, 5, -2, 3, -4, 2, -1, -3, 3], hw: .62, hub: 1.7 };
  const SHAPES = {
    '✢': { n: 4, len: [.86, .86, .86, .86], jit: [0, 0, 0, 0], hw: 1.05, hub: 1.8, tip: [1.25, .62] },
    '✳': { n: 8, len: [.94, .94, .94, .94, .94, .94, .94, .94], jit: [0, 0, 0, 0, 0, 0, 0, 0], hw: .6, hub: 1.4 },
    '✶': { n: 6, len: [.98, .98, .98, .98, .98, .98], jit: [0, 0, 0, 0, 0, 0], hw: .95, hub: 2.4 },
    '✻': { n: 8, len: [.7, .7, .7, .7, .7, .7, .7, .7], jit: [22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5, 22.5], hw: .42, hub: 1.2, tip: [1.25, .78] },
    '✽': { n: 8, len: [.9, .9, .9, .9, .9, .9, .9, .9], jit: [0, 0, 0, 0, 0, 0, 0, 0], hw: .78, hub: 1.6, tip: [1.0, .9] },
    'faísca': BRAND,
  };
  const THINK = ['✢', '✳', '✶', '✻', '✽'];

  function sparkHit(sh, x, y, rot) {
    const d = Math.hypot(x, y);
    if (d > R + .5) return false;
    if (d <= sh.hub) return true;
    for (let n = 0; n < sh.n; n++) {
      const a = (n * 360 / sh.n + sh.jit[n] - 90 + rot) * Math.PI / 180, l = sh.len[n] * R;
      const ex = Math.cos(a) * l, ey = Math.sin(a) * l;
      const t = Math.max(0, Math.min(1, (x * ex + y * ey) / (l * l)));
      if (Math.hypot(x - t * ex, y - t * ey) <= sh.hw) return true;
      if (sh.tip && Math.hypot(x - ex * sh.tip[1], y - ey * sh.tip[1]) <= sh.tip[0]) return true;
    }
    return false;
  }

  /* cobertura de um quadrado da grade (u,v) para a moeda girada de a graus.
     devolve [cobertura 0..1, 'k' tinta | 'a' faísca] */
  const SUB = [-1 / 3, 0, 1 / 3];
  function cover(u, v, a, shape, rot) {
    const ar = a * Math.PI / 180, c = Math.cos(ar), s = Math.sin(ar);
    let k = 0, ac = 0;
    for (const su of SUB) for (const sv of SUB) {
      const x = u + su, y = v + sv;
      if (y * y > R * R) continue;
      const ry = Math.sqrt(R * R - y * y);
      let hit = 0;
      if (Math.abs(c) > .02) {
        const zf = c > 0 ? T / 2 : -T / 2, xo = (x - zf * s) / c;
        if (xo * xo + y * y <= R * R) {
          if (c > 0) { if (COIN.has(Math.round(xo) + ',' + Math.round(y))) hit = 1; }
          else if (sparkHit(shape, -xo, y, rot)) hit = 2;
        }
      }
      if (!hit) {
        const w = (T / 2) * Math.abs(s);
        if (w > .02 && (Math.abs(x - ry * c) <= w || Math.abs(x + ry * c) <= w)) hit = 1;
      }
      if (hit === 1) k++; else if (hit === 2) ac++;
    }
    const n = SUB.length * SUB.length;
    return ac > k ? [ac / n, 'a'] : [k / n, 'k'];
  }

  // linha do tempo do giro (ms)
  const TL = { rest: 1600, flip: 900, think: 700, hold: 1900, back: 900, rest2: 1200 };
  const PERIOD = TL.rest + TL.flip + TL.think + TL.hold + TL.back + TL.rest2;
  const ease = x => x < .5 ? 4 * x * x * x : 1 - ((-2 * x + 2) ** 3) / 2;
  function state(tt) {
    let p = ((tt % PERIOD) + PERIOD) % PERIOD;
    if (p < TL.rest) return { a: 0, shape: '✢', rot: 0, phase: 'moeda' };
    if ((p -= TL.rest) < TL.flip) return { a: 180 * ease(p / TL.flip), shape: '✢', rot: 0, phase: 'gira' };
    if ((p -= TL.flip) < TL.think) { const g = THINK[Math.min(THINK.length - 1, Math.floor(p / (TL.think / THINK.length)))]; return { a: 180, shape: g, rot: 0, phase: 'pensa', glyph: g }; }
    if ((p -= TL.think) < TL.hold) return { a: 180, shape: 'faísca', rot: 0, phase: 'faísca' };
    if ((p -= TL.hold) < TL.back) return { a: 180 + 180 * ease(p / TL.back), shape: 'faísca', rot: 0, phase: 'volta' };
    return { a: 0, shape: '✢', rot: 0, phase: 'moeda' };
  }

  function el(tag, attrs, parent) {
    const e = document.createElementNS(NS, tag);
    for (const k in attrs) e.setAttribute(k, attrs[k]);
    if (parent) parent.appendChild(e);
    return e;
  }
  function rng(seed) { let s = seed; return () => (s = s * 16807 % 2147483647) / 2147483647; }

  // quadrados da moeda: posições fixas na grade, dentro de um círculo um pouco maior que a moeda
  const POOL_UV = [];
  for (let u = -10; u <= 10; u++) for (let v = -10; v <= 10; v++) if (Math.hypot(u, v) <= 10.8) POOL_UV.push([u, v]);

  function viewBox(crop) {
    if (crop === 'symbol' && !D.hand.length) return [CC[0] - 10.2 * G.px, CC[1] - 10.2 * G.py, 20.4 * G.px, 20.4 * G.py];
    if (crop === 'symbol') {
      const xs = D.hand.map(c => gx(c[0])), ys = D.hand.map(c => gy(c[1]));
      const x0 = CC[0] - 10.6 * G.px, x1 = Math.max(...xs) + G.px * .7, y0 = Math.min(...ys) - G.py * .7, y1 = Math.max(...ys) + G.py * .7;
      return [x0, y0, x1 - x0, y1 - y0];
    }
    if (crop === 'coin') return [CC[0] - 10.8 * G.px, CC[1] - 10.8 * G.py, 21.6 * G.px, 21.6 * G.py];
    return D.vb.slice();
  }

  /* create(svg, opts) — opts.crop: 'full' | 'symbol' | 'coin'; opts.intro; opts.loop; opts.ink; opts.accent */
  function create(svg, opts) {
    opts = Object.assign({ crop: 'full', ink: '#0A0A0A', accent: '#FF5A1F', intro: true, loop: true, speed: 1, offset: 0 }, opts || {});
    svg.innerHTML = '';
    const vb = opts.viewBox || viewBox(opts.crop);
    svg.setAttribute('viewBox', vb.map(n => n.toFixed(2)).join(' '));
    svg.style.setProperty('--ink', opts.ink);
    svg.style.setProperty('--accent', opts.accent);
    svg.classList.add('lc-logo');
    const r = rng(11), groups = {};

    if (opts.crop !== 'coin' && D.hand.length) {
      const g = groups.hand = el('g', { class: 'lc-hand' }, svg);
      const ys = D.hand.map(c => gy(c[1])), maxY = Math.max(...ys);
      D.hand.forEach(([i, j]) => {
        const x = gx(i), y = gy(j), d = (maxY - y) * 8 + (x - 40) * 2 + r() * 160;
        el('rect', { x: (x - CW / 2).toFixed(2), y: (y - CH / 2).toFixed(2), width: CW.toFixed(2), height: CH.toFixed(2), style: `--d:${Math.round(d)}ms` }, g);
      });
    }
    const gc = groups.coin = el('g', { class: 'lc-coin' }, svg);
    // sem a mão, a moeda é a primeira a acender (do centro para fora, antes do LUCRO)
    const c0 = D.hand.length ? 900 : 120;
    const pool = POOL_UV.map(([u, v]) => {
      const rc = el('rect', { style: `--d:${Math.round(c0 + Math.hypot(u, v) * 45)}ms` }, gc);
      return { u, v, rc, key: '' };
    });
    const glyph = (list, cls, start, step) => {
      const g = el('g', { class: cls }, svg);
      list.forEach((gl, n) => el('path', { d: gl.d, transform: `translate(${gl.t[0]},${gl.t[1]}) scale(${gl.t[2]},${gl.t[3]})`, style: `--d:${start + n * step}ms` }, g));
      return g;
    };
    if (opts.crop === 'full') {
      glyph(D.text.lucro, 'lc-word', 650, 90);
      glyph(D.text.criativo, 'lc-word', 1100, 70);
      glyph(D.text.imersao, 'lc-type', 1850, 55);
      glyph(D.text.va, 'lc-type', 2300, 45);
      glyph(D.text.prompt, 'lc-type', 2600, 45);
    }
    const cur = el('rect', { class: 'lc-cursor', width: '4.2', height: '8.6', x: '-99', y: '-99' }, svg);

    function draw(st) {
      for (const p of pool) {
        let cov, kind;
        if (st.a === 0) { cov = COIN.has(p.u + ',' + p.v) ? 1 : 0; kind = 'k'; }
        else [cov, kind] = cover(p.u, p.v, st.a, SHAPES[st.shape], st.rot);
        // parada de frente (moeda ou faísca): quadrado cheio ou nada; só no giro os quadrados variam de tamanho
        const flat = st.a % 180 === 0;
        const q = flat ? (cov >= .5 ? 1 : 0) : (cov < .12 ? 0 : Math.round(Math.sqrt(cov) * 20) / 20);
        const key = q ? kind + q : '0';
        if (key === p.key) continue;
        p.key = key;
        if (!q) { p.rc.setAttribute('class', 'off'); continue; }
        const w = CW * q, h = CH * q, x = CC[0] + p.u * G.px, y = CC[1] + p.v * G.py;
        p.rc.setAttribute('x', (x - w / 2).toFixed(2)); p.rc.setAttribute('y', (y - h / 2).toFixed(2));
        p.rc.setAttribute('width', w.toFixed(2)); p.rc.setAttribute('height', h.toFixed(2));
        p.rc.setAttribute('class', kind === 'a' ? 'a' : 'k');
      }
    }

    let t = opts.offset, last = null, playing = !!opts.loop, speed = opts.speed, raf = 0, phase = '', glyphNow = '', introDone = !opts.intro, drawnT = NaN, visible = true;
    const listeners = [];
    function frame(now) {
      raf = 0;
      if (last == null) last = now;
      const dt = Math.min(64, now - last); last = now;
      if (playing && introDone && visible) t += dt * speed;
      if (t !== drawnT) {
        const st = state(t);
        draw(st); drawnT = t;
        if (st.phase !== phase || (st.glyph || '') !== glyphNow) { phase = st.phase; glyphNow = st.glyph || ''; listeners.forEach(f => f(phase, glyphNow)); }
      }
      // só pede o próximo quadro quando há o que mexer; fora da tela ou parado, descansa
      if (visible && (playing || !introDone)) raf = requestAnimationFrame(frame); else last = null;
    }
    const kick = () => { if (!raf) raf = requestAnimationFrame(frame); };

    let timers = [];
    function typeCursor() {
      const steps = [];
      // o cursor tem o tamanho da linha que está sendo digitada (o IMERSÃO cresceu em 26/11)
      const kIm = (D.imCap || 7.5) / 7.5;
      const push = (list, start, step, k) => list.forEach((gl, n) => steps.push([start + n * step, gl.x1 + 1.2 * k, gl.t[1], k]));
      push(D.text.imersao, 1850, 55, kIm); push(D.text.va, 2300, 45, 1); push(D.text.prompt, 2600, 45, 1);
      steps.forEach(([ms, x, base, k]) => timers.push(setTimeout(() => { cur.setAttribute('x', x.toFixed(2)); cur.setAttribute('y', (base - 7.6 * k).toFixed(2)); cur.setAttribute('width', (4.2 * k).toFixed(2)); cur.setAttribute('height', (8.6 * k).toFixed(2)); cur.classList.add('vis'); }, ms)));
      const end = steps.length ? steps[steps.length - 1][0] + 650 : 0;
      timers.push(setTimeout(() => cur.classList.remove('vis'), end));
      return end;
    }
    function intro() {
      timers.forEach(clearTimeout); timers = [];
      svg.classList.remove('lc-in', 'lc-done'); void svg.getBoundingClientRect();
      introDone = false; t = 0; drawnT = NaN; pool.forEach(p => p.key = ''); draw(state(0));
      svg.classList.add('lc-in');
      const end = Math.max(opts.crop === 'full' ? typeCursor() : 0, opts.crop === 'full' ? 2600 : 1900);
      timers.push(setTimeout(() => { svg.classList.add('lc-done'); introDone = true; kick(); }, end));
      kick();
    }
    const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (opts.intro && !reduce) intro(); else { svg.classList.add('lc-in', 'lc-done'); introDone = true; }
    if (reduce) playing = false;
    draw(state(t));
    kick();

    return {
      svg, period: PERIOD,
      replay() { intro(); },
      play() { playing = true; kick(); }, pause() { playing = false; },
      toggle() { playing = !playing; kick(); return playing; },
      stop() { playing = false; t = 0; drawnT = NaN; pool.forEach(p => p.key = ''); kick(); },
      get playing() { return playing; }, get time() { return t; }, get phase() { return phase; }, get ready() { return introDone; },
      setSpeed(s) { speed = s; }, get speed() { return speed; },
      setVisible(v) { visible = !!v; if (visible) kick(); },
      setColors(ink, accent) { svg.style.setProperty('--ink', ink); if (accent) svg.style.setProperty('--accent', accent); },
      seek(ms) { t = Math.max(0, ms); kick(); },
      onPhase(f) { listeners.push(f); },
      destroy() { cancelAnimationFrame(raf); timers.forEach(clearTimeout); },
    };
  }

  // um quadro parado do giro, como SVG (para a tira de quadros)
  function frameSVG(a, shape, rot) {
    const vb = viewBox('coin').map(n => n.toFixed(2)).join(' ');
    let k = '', ac = '';
    for (const [u, v] of POOL_UV) {
      let cov, kind;
      if (a === 0) { cov = COIN.has(u + ',' + v) ? 1 : 0; kind = 'k'; } else [cov, kind] = cover(u, v, a, SHAPES[shape], rot || 0);
      const flat = a % 180 === 0;
      if (flat ? cov < .5 : cov < .12) continue;
      const q = flat ? 1 : Math.sqrt(cov), w = CW * q, h = CH * q, x = CC[0] + u * G.px, y = CC[1] + v * G.py;
      const r = `<rect x="${(x - w / 2).toFixed(2)}" y="${(y - h / 2).toFixed(2)}" width="${w.toFixed(2)}" height="${h.toFixed(2)}"/>`;
      if (kind === 'a') ac += r; else k += r;
    }
    return `<svg viewBox="${vb}" aria-hidden="true"><g class="fk">${k}</g><g class="fa">${ac}</g></svg>`;
  }

  // a mesma moeda desenhada em texto, como um terminal desenharia
  function asciiFrame(tt, cols, rows) {
    const st = state(tt), sh = SHAPES[st.shape];
    const sx = 23 / cols, sy = 23 / rows;
    let out = '';
    for (let rr = 0; rr < rows; rr++) {
      let line = '', open = false;
      for (let cc = 0; cc < cols; cc++) {
        const u = (cc - (cols - 1) / 2) * sx, v = (rr - (rows - 1) / 2) * sy;
        let cov, kind;
        if (st.a === 0) { cov = COIN.has(Math.round(u) + ',' + Math.round(v)) ? 1 : 0; kind = 'k'; } else [cov, kind] = cover(u, v, st.a, sh, st.rot);
        let ch = ' ';
        if (cov >= .7) ch = kind === 'a' ? '*' : '$'; else if (cov >= .4) ch = kind === 'a' ? '+' : 's'; else if (cov >= .15) ch = kind === 'a' ? '·' : ':';
        const acc = kind === 'a' && ch !== ' ';
        if (acc && !open) { line += '<b>'; open = true; } else if (!acc && open) { line += '</b>'; open = false; }
        line += ch;
      }
      if (open) line += '</b>';
      out += line + '\n';
    }
    return out;
  }

  return { create, frameSVG, asciiFrame, state, PERIOD, data: D, grid: G, coinCenter: CC, viewBox };
})();
