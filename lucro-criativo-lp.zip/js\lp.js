/* Lucro Criativo · LP do ingresso · comportamento da página (v2)
   (a venda, a virada das 19h, as UTMs e a medição ficam no venda.js)
   1) barra de compra no celular: aparece quando nenhum botão de compra está à vista
   2) print de chat: as mensagens entram uma vez; a faísca "pensa" só enquanto está na tela
   3) a moeda da coluna "A IA que traz cliente" gira e vira faísca (motor da logo), só quando visível
   4) o caminho Acha → Proposta → Fecha → Entrega → Renova acende uma etapa por vez, só quando visível
   5) aviso das 19h: clicar fora da caixa fecha */
(function () {
  var calmo = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var temIO = 'IntersectionObserver' in window;
  var visivel = function (el, fn, limiar) { if (!el) return; if (!temIO) { fn(true); return; } new IntersectionObserver(function (es) { es.forEach(function (e) { fn(e.isIntersecting); }); }, { threshold: limiar || 0 }).observe(el); };

  // 1) barra de compra no celular
  var bar = document.getElementById('buybar');
  var vigiados = ['#topo .cta', '#dor .cta', '#ingresso .ticket', '#fecho'].map(function (s) { return document.querySelector(s); }).filter(Boolean);
  if (bar && temIO && vigiados.length) {
    var vendo = new Map();
    var mostra = function () {
      var algum = false; vendo.forEach(function (v) { if (v) algum = true; });
      var on = !algum;
      bar.classList.toggle('on', on);
      bar.setAttribute('aria-hidden', on ? 'false' : 'true');
      var a = bar.querySelector('a'); if (a) a.tabIndex = on ? 0 : -1;
    };
    var io = new IntersectionObserver(function (es) { es.forEach(function (e) { vendo.set(e.target, e.isIntersecting); }); mostra(); }, { threshold: 0 });
    vigiados.forEach(function (el) { vendo.set(el, true); io.observe(el); });
  }

  // 2) print de chat
  var chat = document.querySelector('.chat');
  if (chat && temIO && !calmo) {
    chat.classList.add('js');
    var spin = chat.querySelector('.spin'), formas = ['✢', '✳', '✶', '✻', '✽'], k = 0, timer = 0;
    visivel(chat, function (v) {
      if (v) {
        chat.classList.add('vivo');
        if (spin && !timer) timer = setInterval(function () { k = (k + 1) % formas.length; spin.textContent = formas[k]; }, 140);
      } else if (timer) { clearInterval(timer); timer = 0; }
    }, 0.35);
  }

  // 3) moeda que vira faísca
  var mv = document.getElementById('moeda-vs');
  if (mv && window.LCLogo) {
    var M = window.LCLogo.create(mv, { crop: 'coin', ink: '#FFFFFF', accent: '#FF5A1F', intro: false, loop: !calmo, offset: 600 });
    visivel(mv, function (v) { M.setVisible(v); });
  }

  // 4) caminho acendendo
  var cam = document.querySelectorAll('.caminho li');
  if (cam.length) {
    var passo = 0, tc = 0;
    var acende = function () { cam.forEach(function (li, i) { li.classList.toggle('on', i === passo); }); passo = (passo + 1) % cam.length; };
    acende();
    if (!calmo) visivel(document.querySelector('.caminho'), function (v) {
      if (v && !tc) tc = setInterval(acende, 1500);
      else if (!v && tc) { clearInterval(tc); tc = 0; }
    }, 0.4);
  }

  // 6) timecode do sábado: o dia da imersão passando (10h → 18h), como uma fita; só anda na tela
  var tc = document.querySelector('[data-tc]'), marca = document.querySelector('[data-tc-marca]');
  if (tc) {
    var DIA = 8 * 3600, VEL = 60, inicio = 0, rodando = 0;           // 1 s da página = 1 min do sábado
    var dois = function (n) { return (n < 10 ? '0' : '') + n; };
    var mostraTc = function (agora) {
      var s = ((agora - inicio) / 1000 * VEL) % DIA, h = 10 + Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), seg = Math.floor(s % 60), f = Math.floor((agora / 33.3) % 30);
      tc.textContent = dois(h) + ':' + dois(m) + ':' + dois(seg) + ':' + dois(f);
      if (marca) marca.style.left = 'calc(' + (s / DIA * 100).toFixed(2) + '% - 6px)';
    };
    var tique = function (agora) { mostraTc(agora); rodando = requestAnimationFrame(tique); };
    if (!calmo) visivel(tc, function (v) {
      if (v && !rodando) { if (!inicio) inicio = performance.now(); rodando = requestAnimationFrame(tique); }
      else if (!v && rodando) { cancelAnimationFrame(rodando); rodando = 0; }
    });
  }

  // 5) aviso das 19h: clicar no fundo fecha
  var av = document.getElementById('aviso-venda');
  if (av) av.addEventListener('click', function (ev) { if (ev.target === av) { var f = av.querySelector('[data-fecha-aviso]'); if (f) f.click(); } });
})();
