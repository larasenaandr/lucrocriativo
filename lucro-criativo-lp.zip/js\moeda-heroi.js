/* Lucro Criativo · a moeda grande do topo, interativa
   Regra da marca: a moeda gira no eixo vertical e é redesenhada na grade a cada quadro
   (os quadrados não saem do lugar; muda quem acende e o tamanho de cada um). Usa o motor da logo (LCLogo.frameSVG).
   - mouse: a moeda vira um pouco para o lado do cursor e inclina (3D leve); os quadrados perto do ponteiro
     acendem em laranja e se afastam um pouco, voltando devagar
   - clique/toque: cara ou coroa. A moeda gira, vira a faísca, "pensa" (✢ ✳ ✶ ✻ ✽) e volta
   - arrastar no celular: gira com o dedo
   - rolagem: ao sair do topo a moeda gira meia volta
   - parada (sem mouse): balança de leve e, de tempos em tempos, vira sozinha
   - prefers-reduced-motion: moeda parada de frente
   Uso: <canvas class="moeda-heroi" data-moeda-heroi aria-hidden="true"></canvas> dentro do topo (header.heroi) */
(function () {
  'use strict';
  var L = window.LCLogo;
  if (!L) return;
  var calmo = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var finoMouse = window.matchMedia && matchMedia('(hover: hover) and (pointer: fine)').matches;
  var VB = L.viewBox('coin');                        // [x, y, w, h] da moeda no desenho da logo
  var TINTA = '#FFFFFF', ACENTO = '#FF5A1F';
  var PENSA = ['✢', '✳', '✶', '✻', '✽'];

  // quadros do giro, guardados (ângulo em passos de 3°, forma do verso)
  var cache = new Map();
  var reRect = /<rect x="([-\d.]+)" y="([-\d.]+)" width="([\d.]+)" height="([\d.]+)"\/>/g;
  function quadro(ang, forma) {
    var a = ((Math.round(ang / 3) * 3) % 360 + 360) % 360;
    var chave = a + '|' + forma;
    var q = cache.get(chave);
    if (q) return q;
    var svg = L.frameSVG(a, forma, 0);
    var grupos = { fk: [], fa: [] };
    ['fk', 'fa'].forEach(function (g) {
      var m = svg.match(new RegExp('<g class="' + g + '">([\\s\\S]*?)</g>'));
      if (!m) return;
      var r; reRect.lastIndex = 0;
      while ((r = reRect.exec(m[1]))) grupos[g].push([(+r[1] - VB[0]) / VB[2], (+r[2] - VB[1]) / VB[3], +r[3] / VB[2], +r[4] / VB[3]]);
    });
    if (cache.size > 900) cache.clear();
    cache.set(chave, grupos);
    return grupos;
  }

  function mount(cv) {
    var ctx = cv.getContext('2d');
    var heroi = cv.closest('.heroi') || cv.parentNode;
    var W = 0, H = 0, dpr = 1;
    function mede() {
      var r = cv.getBoundingClientRect();
      dpr = Math.min(2, window.devicePixelRatio || 1);
      W = Math.round(r.width); H = Math.round(r.height);
      cv.width = Math.max(1, Math.round(W * dpr)); cv.height = Math.max(1, Math.round(H * dpr));
      pede();
    }

    // estado
    var mouse = { x: 0, y: 0, dentro: false, ultimo: 0, cx: -9999, cy: -9999 };   // x,y: -1..1 no topo; cx,cy: px no canvas
    var tilt = { x: 0, y: 0 }, yawMouse = 0, yawMouseAlvo = 0;
    var flip = 0, flipDe = 0, flipAlvo = 0, flipT0 = 0, FLIP_MS = 950, segura = 0;
    var arrasto = null, yawDedo = 0;
    var rolagem = 0;
    var luz = [];               // brilho dos quadrados perto do ponteiro (decai devagar)
    var visivel = true, raf = 0, t0 = performance.now(), ultimoFlip = performance.now();
    var forma = 'faísca', pensaAte = 0;

    function ease(x) { return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; }
    function joga() {
      if (calmo) return;
      var agora = performance.now();
      if (agora - flipT0 < FLIP_MS) return;           // um giro de cada vez
      flipDe = flip; flipAlvo = flip + 180; flipT0 = agora; ultimoFlip = agora;
      clearTimeout(segura);
      var noVerso = Math.round(flipAlvo / 180) % 2 === 1;
      if (noVerso) {
        pensaAte = agora + FLIP_MS + 700;              // chega no verso pensando, assenta na faísca
        segura = setTimeout(joga, FLIP_MS + 2300);    // e volta a ser moeda
      }
      pede();
    }

    function desenha(agora) {
      raf = 0;
      if (!visivel) return;
      var t = agora - t0;
      // giro do clique
      var pf = Math.min(1, (agora - flipT0) / FLIP_MS);
      flip = flipDe + (flipAlvo - flipDe) * ease(pf);
      // mouse: segue com mola
      var parado = !mouse.dentro || agora - mouse.ultimo > 2500;
      yawMouseAlvo = parado ? Math.sin(t / 1700) * 16 : mouse.x * 46;
      yawMouse += (yawMouseAlvo - yawMouse) * 0.08;
      var tiltAlvoX = parado ? 0 : -mouse.y * 9, tiltAlvoY = parado ? Math.sin(t / 2300) * 4 : mouse.x * 11;
      tilt.x += (tiltAlvoX - tilt.x) * 0.08; tilt.y += (tiltAlvoY - tilt.y) * 0.08;
      // parado muito tempo: vira sozinha de vez em quando
      if (!calmo && parado && agora - ultimoFlip > 9000 && pf >= 1 && Math.round(flip / 180) % 2 === 0) joga();
      var ang = (calmo ? 0 : yawMouse + flip + rolagem * 180 + yawDedo);
      var verso = Math.cos(ang * Math.PI / 180) < 0;
      if (verso && agora < pensaAte && pf >= 1) forma = PENSA[Math.floor((agora % 700) / 140)];
      else forma = 'faísca';
      var q = quadro(ang, forma);

      cv.style.transform = 'perspective(1100px) rotateX(' + tilt.x.toFixed(2) + 'deg) rotateY(' + tilt.y.toFixed(2) + 'deg)';
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      var S = Math.min(W, H), ox = (W - S) / 2, oy = (H - S) / 2, R = S * 0.24, cel = S / 21.6;
      var temLuz = false;
      ['fk', 'fa'].forEach(function (g) {
        var lista = q[g];
        for (var i = 0; i < lista.length; i++) {
          var r = lista[i];
          var w = r[2] * S, h = r[3] * S, x = ox + r[0] * S, y = oy + r[1] * S;
          var cx = x + w / 2, cy = y + h / 2;
          var k = 0;
          if (mouse.cx > -999) {
            var dx = cx - mouse.cx, dy = cy - mouse.cy, d = Math.sqrt(dx * dx + dy * dy);
            if (d < R) {
              k = 1 - d / R; k = k * k;
              var emp = k * cel * 0.55 / (d || 1);
              x += dx * emp; y += dy * emp;
            }
          }
          var idx = g === 'fk' ? Math.round(r[0] * 40) * 64 + Math.round(r[1] * 40) : -1;
          if (idx >= 0) {
            var l = Math.max(k, (luz[idx] || 0) * 0.94);
            luz[idx] = l; if (l > 0.02) temLuz = true;
            ctx.fillStyle = l > 0.18 ? ACENTO : TINTA;
            if (l > 0.18 && l < 0.45) ctx.globalAlpha = 0.85; else ctx.globalAlpha = 1;
          } else { ctx.fillStyle = ACENTO; ctx.globalAlpha = 1; }
          ctx.fillRect(Math.round(x * 2) / 2, Math.round(y * 2) / 2, w, h);
        }
      });
      ctx.globalAlpha = 1;
      var mexendo = !calmo && (Math.abs(yawMouseAlvo - yawMouse) > 0.05 || pf < 1 || temLuz || agora < pensaAte || parado || arrasto);
      if (mexendo) pede();
    }
    function pede() { if (!raf && visivel) raf = requestAnimationFrame(desenha); }

    // eventos
    heroi.addEventListener('pointermove', function (e) {
      if (e.pointerType !== 'mouse') return;
      var rh = heroi.getBoundingClientRect(), rc = cv.getBoundingClientRect();
      mouse.x = Math.max(-1, Math.min(1, (e.clientX - (rc.left + rc.width / 2)) / (rh.width / 2)));
      mouse.y = Math.max(-1, Math.min(1, (e.clientY - (rc.top + rc.height / 2)) / (rh.height / 2)));
      mouse.cx = e.clientX - rc.left; mouse.cy = e.clientY - rc.top;
      mouse.dentro = true; mouse.ultimo = performance.now();
      pede();
    }, { passive: true });
    heroi.addEventListener('pointerleave', function () { mouse.dentro = false; mouse.cx = -9999; mouse.cy = -9999; pede(); }, { passive: true });
    cv.addEventListener('click', joga);
    cv.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'mouse') arrasto = { x0: e.clientX, y0: yawDedo, moveu: false }; }, { passive: true });
    cv.addEventListener('pointermove', function (e) {
      if (!arrasto) return;
      var dx = e.clientX - arrasto.x0;
      if (Math.abs(dx) > 6) arrasto.moveu = true;
      yawDedo = arrasto.y0 + dx * 0.9; pede();
    }, { passive: true });
    var solta = function () { if (!arrasto) return; var moveu = arrasto.moveu; arrasto = null; if (moveu) { yawDedo = Math.round(yawDedo / 180) * 180; pede(); } };
    cv.addEventListener('pointerup', solta); cv.addEventListener('pointercancel', solta);
    // rolagem: ao sair do topo, meia volta
    var rolou = function () {
      var r = heroi.getBoundingClientRect();
      rolagem = Math.max(0, Math.min(1, -r.top / Math.max(1, r.height * 0.8)));
      pede();
    };
    if (!calmo) window.addEventListener('scroll', rolou, { passive: true });
    if ('IntersectionObserver' in window) new IntersectionObserver(function (es) { es.forEach(function (e) { visivel = e.isIntersecting; if (visivel) pede(); }); }).observe(cv);
    document.addEventListener('visibilitychange', function () { visivel = !document.hidden; if (visivel) pede(); });
    if ('ResizeObserver' in window) new ResizeObserver(mede).observe(cv); else window.addEventListener('resize', mede);
    mede();
    if (!calmo) setTimeout(joga, 1200);   // na chegada, a moeda é jogada uma vez
    return { joga: joga };
  }

  function inicia() { document.querySelectorAll('canvas[data-moeda-heroi]').forEach(mount); }
  window.LCMoedaHeroi = { mount: mount };
  if (document.readyState !== 'loading') inicia(); else document.addEventListener('DOMContentLoaded', inicia);
})();
