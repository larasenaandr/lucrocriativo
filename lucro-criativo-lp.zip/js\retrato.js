/* Lucro Criativo · retrato em retícula (pontos em linhas)
   Desenha um vídeo curto (ou o poster dele) como pontos em linhas horizontais, no visual do layout da Lara:
   o raio do ponto vem do escuro da imagem (com curva gamma e realce local, para o rosto ler de longe) e a cor
   segue a escala ciano #00B4FF → azul #0040FF como no layout: azul-ciano no alto da figura (variando ponto a
   ponto), azul no rosto, azul fundo na base; ponto pequeno puxa para o azul para não sumir no branco.
   De longe a pessoa é reconhecível; de perto, aparecem os pontos e caracteres.

   Mouse (só onde existe hover):
   - perto do ponteiro (data-raio, 110 px) a retícula fica mais fina e alguns pontos viram caracteres de código;
     ao sair, volta ao tamanho normal em ~400 ms.
   - data-modo="olhar": a posição X do ponteiro escolhe o quadro do vídeo (ponteiro à esquerda = início do vídeo,
     à direita = fim); ao sair, volta suave ao quadro de repouso.
   - data-modo="gesto": ao entrar, o gesto toca uma vez (do repouso até o fim) e para no fim; ao sair, funde de
     volta ao repouso.
   Repouso: data-repouso (em s); sem ele, o quadro do vídeo mais parecido com o poster (o quadro bem composto);
   sem poster, o meio do vídeo (olhar) ou o início (gesto).
   Celular/toque: mostra o quadro de repouso; quando o retrato fica 50% visível, faz o gesto uma vez e repousa
   (um toque repete). O vídeo só é baixado a ~600 px de entrar na tela.
   prefers-reduced-motion ou economia de dados: só o poster em pontos, sem vídeo e sem efeito de mouse.
   Sem acesso aos pixels (página aberta direto do disco, em file://, ou poster de outro domínio sem CORS): o poster
   aparece em duotone azul só com CSS, sem pontos, para o quadro não ficar vazio. No ar (http) isso não acontece.
   O ponteiro é lido no espaço do próprio canvas (offsetX/Y): a lente acompanha mesmo com o retrato girado por CSS.

   Como funciona: o vídeo é decodificado uma vez, por busca sequencial, em 40 quadros (olhar) ou ~15 por segundo
   (gesto), guardados como luminância numa grade pequena. Depois o <video> é esvaziado e tudo sai da memória:
   nada de seek ao vivo. Entre dois quadros guardados, os pontos são interpolados. O desenho é WebGL (todos os
   pontos numa chamada só), com Canvas 2D de reserva. Só desenha quando algo muda e o retrato está visível.

   Uso:
   <div class="retrato" data-retrato data-src="video/hec_retrato.mp4" data-poster="video/hec_retrato.jpg"
        data-modo="olhar" data-cor="azul" role="img" aria-label="Retrato do Hec"></div>
   <script src="js/retrato.js" defer></script>
   O tamanho vem do CSS do elemento (ex.: aspect-ratio: 4/5). Vídeo e poster são enquadrados como
   object-fit: cover; o fundo do vídeo deve ser branco (o que for quase branco vira "sem ponto").
   Opcionais: data-posicao="50% 30%" (como object-position), data-trecho="0.4,3.6" (parte do vídeo usada),
   data-sentido="-1" (inverte o lado do olhar), data-celula (altura da linha em px; padrão: largura/64),
   data-gamma (1.15), data-realce (1.4), data-limiar (0.93), data-raio (110), data-fineza (3 em tela densa,
   2 em tela comum), data-quadros (40), data-caracteres ("01{}<>/*+=;"), data-inverte ("1" = ponto maior no
   claro; padrão "1" em data-cor="branco", para o rosto ficar positivo no fundo azul), data-lente="0" (desliga o
   efeito do ponteiro).
   JS: LCRetrato.mount(el, { modo: 'gesto', ... }) devolve { el, cfg, gesto(), estado(), destroy() }. */
window.LCRetrato = (function () {
  'use strict';

  const DPR_MAX = 2;
  const PROP_X = 0.8;       // passo horizontal = 0,8 × altura da linha: no escuro os pontos encostam e viram linha
  const RAIO_MAX = 0.47;    // raio máximo = 0,47 × altura da linha
  const VMIN = 0.1;         // ponto mínimo dentro da figura: o claro do rosto não vira buraco
  const NC = 12;            // tons de cor no Canvas 2D de reserva
  const FONTE = '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';
  const instancias = [];
  const mm = q => (window.matchMedia ? window.matchMedia(q) : { matches: false });
  const mqReduz = mm('(prefers-reduced-motion: reduce)');
  const mqHover = mm('(hover: hover) and (pointer: fine)');

  const clamp = (x, a, b) => (x < a ? a : x > b ? b : x);
  const suave = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const vaiVolta = u => 0.5 - 0.5 * Math.cos(Math.PI * u);
  const num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };
  function hash(i, j) {
    let h = Math.imul(i, 374761393) ^ Math.imul(j, 668265263);
    h = Math.imul(h ^ (h >>> 13), 1274126177);
    return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
  }
  function mesmaOrigem(url) {
    try { const u = new URL(url, location.href); return u.origin === location.origin || u.protocol === 'data:' || u.protocol === 'blob:'; }
    catch (e) { return true; }
  }
  function ouve(mq, f) { if (mq.addEventListener) mq.addEventListener('change', f); else if (mq.addListener) mq.addListener(f); }
  function desouve(mq, f) { if (mq.removeEventListener) mq.removeEventListener('change', f); else if (mq.removeListener) mq.removeListener(f); }
  function espera(alvo, evento, ms) {
    return new Promise((ok, falha) => {
      const fim = bom => { clearTimeout(to); alvo.removeEventListener(evento, h); alvo.removeEventListener('error', e); bom ? ok() : falha(new Error(evento)); };
      const h = () => fim(true), e = () => fim(false);
      const to = setTimeout(() => fim(false), ms);
      alvo.addEventListener(evento, h); alvo.addEventListener('error', e);
    });
  }
  function borra(src, w, h, r) {   // caixa separável, duas passadas (quase gaussiana); devolve Float32Array
    const a = Float32Array.from(src), b = new Float32Array(src.length), inv = 1 / (2 * r + 1);
    for (let p = 0; p < 2; p++) {
      for (let y = 0; y < h; y++) {
        const o = y * w; let acc = 0;
        for (let x = -r; x <= r; x++) acc += a[o + clamp(x, 0, w - 1)];
        for (let x = 0; x < w; x++) { b[o + x] = acc * inv; acc += a[o + Math.min(w - 1, x + r + 1)] - a[o + Math.max(0, x - r)]; }
      }
      for (let x = 0; x < w; x++) {
        let acc = 0;
        for (let y = -r; y <= r; y++) acc += b[clamp(y, 0, h - 1) * w + x];
        for (let y = 0; y < h; y++) { a[y * w + x] = acc * inv; acc += b[Math.min(h - 1, y + r + 1) * w + x] - b[Math.max(0, y - r) * w + x]; }
      }
    }
    return a;
  }

  // ---------- WebGL: cada ponto (ou caractere) é um point sprite; tudo numa chamada ----------
  const VS = 'attribute vec2 a_p;attribute vec4 a_d;uniform vec2 u_res;varying vec4 v_d;varying float v_s;' +
    'void main(){float s=a_d.y<0.0?a_d.x*2.0+2.0:a_d.x;gl_PointSize=s;v_s=s;v_d=a_d;' +
    'vec2 q=a_p/u_res*2.0-1.0;gl_Position=vec4(q.x,-q.y,0.0,1.0);}';
  const FS = 'precision mediump float;uniform sampler2D u_tex;uniform float u_ng;uniform vec3 u_c0;uniform vec3 u_c1;uniform vec2 u_a;' +
    'uniform vec3 u_or;varying vec4 v_d;varying float v_s;void main(){float a;' +
    'if(v_d.y<0.0){float d=length(gl_PointCoord-0.5)*v_s;a=clamp(v_d.x-d+0.5,0.0,1.0);}' +
    'else{a=texture2D(u_tex,vec2((v_d.y+gl_PointCoord.x)/u_ng,gl_PointCoord.y)).a;}' +
    'bool lj=v_d.z>1.5;vec3 c=lj?u_or:mix(u_c0,u_c1,v_d.z);' +   // cor > 1,5 = ponto do rastro laranja do mouse
    'a*=v_d.w*(lj?1.0:mix(u_a.x,u_a.y,v_d.z));if(a<0.004)discard;gl_FragColor=vec4(c*a,a);}';
  const LARANJA = [1, 90 / 255, 31 / 255];   // #FF5A1F

  function lerCfg(el, o) {
    const d = el.dataset;
    const pega = (k, def) => (o[k] !== undefined && o[k] !== null ? o[k] : d[k] !== undefined && d[k] !== '' ? d[k] : def);
    const pos = String(pega('posicao', '50% 50%')).trim().split(/\s+/);
    const pct = (s, def) => { const n = parseFloat(s); return isFinite(n) ? clamp(n / 100, 0, 1) : def; };
    const tre = String(pega('trecho', '')).split(/[\s,;]+/).map(parseFloat).filter(isFinite);
    const cor = pega('cor', 'azul') === 'branco' ? 'branco' : 'azul';
    const inv = pega('inverte', cor === 'branco');   // no fundo azul, ponto maior no claro: o rosto fica positivo
    const rep = pega('repouso', null);
    return {
      src: pega('src', ''), poster: pega('poster', ''),
      modo: pega('modo', 'olhar') === 'gesto' ? 'gesto' : 'olhar',
      cor,
      inverte: inv === true || String(inv) === '1' || String(inv) === 'true',
      repouso: rep === null ? null : num(rep, null),
      celula: num(pega('celula', 0), 0),
      gamma: clamp(num(pega('gamma', 1.15), 1.15), 0.2, 4),
      realce: clamp(num(pega('realce', 1.4), 1.4), 0, 3),
      raio: Math.max(20, num(pega('raio', 110), 110)),
      fineza: Math.round(clamp(num(pega('fineza', 0), 0), 0, 4)),
      quadros: Math.round(clamp(num(pega('quadros', 40), 40), 8, 96)),
      posX: pct(pos[0], 0.5), posY: pct(pos[1] !== undefined ? pos[1] : pos[0], 0.5),
      sentido: num(pega('sentido', 1), 1) < 0 ? -1 : 1,
      limiar: clamp(num(pega('limiar', 0.93), 0.93), 0.5, 0.995),
      trecho: tre.length >= 2 ? [tre[0], tre[1]] : null,
      caracteres: String(pega('caracteres', '01{}<>/*+=;')).replace(/\s+/g, '') || '01',
      lente: String(pega('lente', '1')) !== '0',
      laranja: String(pega('laranja', '1')) !== '0',            // rastro laranja atrás do mouse (e do toque)
      rastro: Math.max(20, num(pega('rastro', 74), 74)),         // raio do rastro, em px CSS
      render: String(pega('render', '')),   // "2d" força o Canvas 2D (só para teste)
    };
  }

  function mount(el, opcoes) {
    if (!el) return null;
    if (el.__lcRetrato) return el.__lcRetrato;
    const cfg = lerCfg(el, opcoes || {});
    const economia = !!(navigator.connection && navigator.connection.saveData);
    const reduzido = () => mqReduz.matches;
    const temHover = () => mqHover.matches;
    const podeLente = () => cfg.lente && !reduzido() && temHover();
    const podeVideo = () => !!cfg.src && !reduzido() && !economia;
    const BRANCO = cfg.cor === 'branco';
    const C0 = BRANCO ? [1, 1, 1] : [0, 180 / 255, 1], C1 = BRANCO ? [1, 1, 1] : [0, 64 / 255, 1];   // #00B4FF → #0040FF
    const ALFA = BRANCO ? [1, 0.55] : [1, 1];   // no azul: pontos brancos, mais transparentes onde a cor "escurece"

    // ---------- estado ----------
    let W = 0, H = 0, dpr = 1, fin = 3, geoVer = 0;
    let pX = 6, pY = 7.5, cols = 0, rows = 0, gx0 = 0, gy0 = 0, rMax = 3;
    let poster = null, quadros = [], dur = 0, pronto = false, usaVideo = false;
    let niveis = null, lut = null, lutVer = 0, sc = null, sctx = null;
    let tAtual = 0, roteiro = null, mistura = null, raf = 0, ultimo = 0, sujo = false;
    let px = 0, py = 0, lx = 0, ly = 0, forca = 0, sobre = false, tipoPonteiro = '', rect = null;
    let visivel = false, metade = false, jaTocou = false, querTocar = false, destruido = false;
    let posterPedido = false, videoPedido = false, glifos = null, glifosAgendado = false, mqDpr = null, repAuto = null;
    let vb = new Float32Array(6 * 8192), nv = 0;
    const estat = { n: 0, soma: 0, max: 0 };
    const rastro = [];          // pontos por onde o mouse passou: { x, y, s } (s apaga devagar)
    let rx = -1e9, ry = -1e9;

    // ---------- DOM ----------
    if (getComputedStyle(el).position === 'static') el.style.position = 'relative';
    const cv = document.createElement('canvas');
    cv.className = 'retrato-canvas';
    cv.setAttribute('aria-hidden', 'true');
    cv.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;display:block;-webkit-tap-highlight-color:transparent';
    const vd = document.createElement('video');
    vd.muted = true; vd.defaultMuted = true; vd.playsInline = true; vd.preload = 'none';
    vd.setAttribute('muted', ''); vd.setAttribute('playsinline', ''); vd.setAttribute('preload', 'none');
    vd.setAttribute('aria-hidden', 'true'); vd.setAttribute('tabindex', '-1');
    vd.disablePictureInPicture = true; vd.disableRemotePlayback = true;
    vd.style.cssText = 'position:absolute;left:0;top:0;width:2px;height:2px;opacity:0;pointer-events:none';
    el.appendChild(vd);
    el.appendChild(cv);
    const rend = criaRender();

    // ---------- desenho: WebGL ou Canvas 2D ----------
    function criaRender() {
      const op = { alpha: true, premultipliedAlpha: true, antialias: false, depth: false, stencil: false, powerPreference: 'low-power' };
      let gl = null;
      if (cfg.render !== '2d') { try { gl = cv.getContext('webgl', op) || cv.getContext('experimental-webgl', op); } catch (e) { gl = null; } }
      if (gl) return rendGL(gl);
      const c2 = cv.getContext('2d');
      return c2 ? rend2D(c2) : null;
    }
    function rendGL(gl) {
      let U = {}, perdido = false, ng = 1, glifosCv = null;
      function init() {
        const sh = (t, s) => { const o = gl.createShader(t); gl.shaderSource(o, s); gl.compileShader(o); return gl.getShaderParameter(o, gl.COMPILE_STATUS) ? o : null; };
        const vs = sh(gl.VERTEX_SHADER, VS), fs = sh(gl.FRAGMENT_SHADER, FS);
        if (!vs || !fs) return false;
        const pr = gl.createProgram(); gl.attachShader(pr, vs); gl.attachShader(pr, fs); gl.linkProgram(pr);
        if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) return false;
        gl.useProgram(pr);
        ['u_res', 'u_tex', 'u_ng', 'u_c0', 'u_c1', 'u_a', 'u_or'].forEach(n => { U[n] = gl.getUniformLocation(pr, n); });
        const ap = gl.getAttribLocation(pr, 'a_p'), ad = gl.getAttribLocation(pr, 'a_d');
        gl.bindBuffer(gl.ARRAY_BUFFER, gl.createBuffer());
        gl.enableVertexAttribArray(ap); gl.vertexAttribPointer(ap, 2, gl.FLOAT, false, 24, 0);
        gl.enableVertexAttribArray(ad); gl.vertexAttribPointer(ad, 4, gl.FLOAT, false, 24, 8);
        gl.bindTexture(gl.TEXTURE_2D, gl.createTexture());
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array(4));
        if (glifosCv) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, glifosCv);
        gl.uniform1i(U.u_tex, 0); gl.uniform1f(U.u_ng, ng);
        gl.uniform3fv(U.u_c0, C0); gl.uniform3fv(U.u_c1, C1); gl.uniform2fv(U.u_a, ALFA); gl.uniform3fv(U.u_or, LARANJA);
        gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
        return true;
      }
      if (!init()) return null;
      const maxP = gl.getParameter(gl.ALIASED_POINT_SIZE_RANGE)[1] || 1;
      cv.addEventListener('webglcontextlost', e => { e.preventDefault(); perdido = true; });
      cv.addEventListener('webglcontextrestored', () => { perdido = !init(); pede(); });
      return {
        tipo: 'webgl', maxP,
        glifos(c, n) { glifosCv = c; ng = n; if (!perdido) { gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c); gl.uniform1f(U.u_ng, n); } },
        pinta(n) {
          if (perdido) return;
          gl.viewport(0, 0, cv.width, cv.height);
          gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
          if (!n) return;
          gl.uniform2f(U.u_res, cv.width, cv.height);
          gl.bufferData(gl.ARRAY_BUFFER, vb.subarray(0, n * 6), gl.DYNAMIC_DRAW);
          gl.drawArrays(gl.POINTS, 0, n);
        },
      };
    }
    function rend2D(c) {   // reserva: um Path2D por tom de cor
      const cores = [];
      for (let i = 0; i < NC; i++) {
        const t = i / (NC - 1), a = ALFA[0] + (ALFA[1] - ALFA[0]) * t;
        const ch = k => Math.round(255 * (C0[k] + (C1[k] - C0[k]) * t));
        cores.push('rgba(' + ch(0) + ',' + ch(1) + ',' + ch(2) + ',' + a.toFixed(3) + ')');
      }
      cores.push('rgb(255,90,31)');   // índice NC: rastro laranja do mouse
      const tom = z => (z > 1.5 ? NC : Math.round(z * (NC - 1)));
      let lista = null;
      return {
        tipo: '2d', maxP: 4096,
        glifos(cnv, n, chars) { lista = chars; },
        pinta(n) {
          c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1;
          c.clearRect(0, 0, cv.width, cv.height);
          const ps = new Array(NC + 1);
          for (let i = 0, o = 0; i < n; i++, o += 6) {
            if (vb[o + 3] >= 0) continue;
            const ci = tom(vb[o + 4]), r = vb[o + 2];
            const p = ps[ci] || (ps[ci] = new Path2D());
            p.moveTo(vb[o] + r, vb[o + 1]); p.arc(vb[o], vb[o + 1], r, 0, 6.2832);
          }
          for (let i = 0; i <= NC; i++) if (ps[i]) { c.fillStyle = cores[i]; c.fill(ps[i]); }
          if (!lista) return;
          c.textAlign = 'center'; c.textBaseline = 'middle';
          for (let i = 0, o = 0; i < n; i++, o += 6) {
            if (vb[o + 3] < 0) continue;
            c.font = '700 ' + (vb[o + 2] / 1.25).toFixed(1) + 'px ' + FONTE;
            c.globalAlpha = vb[o + 5]; c.fillStyle = cores[tom(vb[o + 4])];
            c.fillText(lista[vb[o + 3]], vb[o], vb[o + 1]);
          }
          c.globalAlpha = 1;
        },
      };
    }

    // ---------- grade ----------
    function geometria(w, h) {
      const nd = Math.min(DPR_MAX, window.devicePixelRatio || 1);
      if (w < 2 || h < 2) return false;
      if (Math.abs(w - W) < 0.5 && Math.abs(h - H) < 0.5 && nd === dpr && geoVer) return false;
      W = w; H = h; dpr = nd;
      fin = cfg.fineza || (dpr >= 1.5 ? 3 : 2);
      pY = cfg.celula > 0 ? cfg.celula : clamp(W / 64, 4.5, 9);
      pX = pY * PROP_X;
      cols = Math.max(1, Math.floor(W / pX)); rows = Math.max(1, Math.floor(H / pY));
      gx0 = (W - cols * pX) / 2; gy0 = (H - rows * pY) / 2;
      rMax = pY * RAIO_MAX;
      cv.width = Math.max(1, Math.round(W * dpr)); cv.height = Math.max(1, Math.round(H * dpr));
      geoVer++; glifos = null;
      return true;
    }

    // caracteres em branco numa tira (o shader pinta), ordenados pela tinta, do mais leve ao mais pesado
    function fazGlifos() {
      const fs = Math.max(5, pY * 1.25) * dpr, gs = Math.min(rend.maxP, Math.ceil(fs * 1.25) + 2);
      const font = '700 ' + fs.toFixed(1) + 'px ' + FONTE;
      const m = document.createElement('canvas'); m.width = gs; m.height = gs;
      const mc = m.getContext('2d', { willReadFrequently: true });
      mc.font = font; mc.textAlign = 'center'; mc.textBaseline = 'middle'; mc.fillStyle = '#fff';
      const lista = Array.from(cfg.caracteres).map(ch => {
        mc.clearRect(0, 0, gs, gs); mc.fillText(ch, gs / 2, gs / 2);
        const d = mc.getImageData(0, 0, gs, gs).data; let s = 0;
        for (let i = 3; i < d.length; i += 4) s += d[i];
        return { ch, s };
      }).sort((a, b) => a.s - b.s).map(g => g.ch);
      const a = document.createElement('canvas'); a.width = gs * lista.length; a.height = gs;
      const c = a.getContext('2d'); c.font = font; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#fff';
      lista.forEach((ch, k) => c.fillText(ch, k * gs + gs / 2, gs / 2));
      glifos = { gs, n: lista.length };
      rend.glifos(a, lista.length, lista);
    }

    // ---------- quadros (luminância numa grade pequena, com realce local) ----------
    function larguraAmostra(nw, nh) {
      let sw = 200;
      if (W > 0 && H > 0) sw = nw * Math.max(W / nw, H / nh) / (podeLente() ? pX / fin : pX / 2);
      return Math.round(clamp(sw, 64, Math.min(360, nw)));
    }
    function capturaQuadro(fonte, nw, nh, t) {
      const sw = larguraAmostra(nw, nh), sh = Math.max(1, Math.round(sw * nh / nw));
      if (!sc) { sc = document.createElement('canvas'); sctx = sc.getContext('2d', { willReadFrequently: true }); }
      if (sc.width !== sw || sc.height !== sh) { sc.width = sw; sc.height = sh; }
      sctx.imageSmoothingEnabled = true; sctx.imageSmoothingQuality = 'high';
      sctx.fillStyle = '#fff'; sctx.fillRect(0, 0, sw, sh);   // vídeo com transparência fica sobre branco
      sctx.drawImage(fonte, 0, 0, sw, sh);
      let d;
      // outra origem sem CORS ou file://: o canvas de amostra fica "sujo" para sempre; descarta para o próximo vir limpo
      try { d = sctx.getImageData(0, 0, sw, sh).data; } catch (e) { sc = null; sctx = null; return null; }
      const L = new Uint8Array(sw * sh), lim = cfg.limiar * 255;
      for (let i = 0, k = 0; i < L.length; i++, k += 4) L[i] = (d[k] * 54 + d[k + 1] * 183 + d[k + 2] * 19) >> 8;
      if (cfg.realce > 0) {   // máscara de nitidez: olhos, sobrancelha e boca não somem na retícula
        const B = borra(L, sw, sh, Math.max(1, Math.round(sw * 0.014))), k = cfg.realce;
        for (let i = 0; i < L.length; i++) { const y = L[i]; if (y < lim) L[i] = clamp(y + k * (y - B[i]), 0, 254); }
      }
      let fig = 0;
      for (let i = 0; i < L.length; i++) if (L[i] < lim) fig++;
      return { t, L, sw, sh, nw, nh, fig: fig / L.length, b: null, bg: -1, bl: -1, m: null };
    }

    // níveis automáticos (uma vez, do primeiro quadro): o claro e o escuro da figura viram mínimo e máximo
    function defineNiveis(q) {
      if (niveis) return;
      const hist = new Uint32Array(256), lim = cfg.limiar * 255 - 6;
      let n = 0;
      for (let i = 0; i < q.L.length; i++) { const y = q.L[i]; if (y < lim) { hist[y]++; n++; } }
      let yEsc = 0, yCla = 255;
      if (n > 64) {
        let acc = 0, achou = false;
        for (let y = 0; y < 256; y++) {
          acc += hist[y];
          if (!achou && acc >= n * 0.02) { yEsc = y; achou = true; }
          if (acc >= n * 0.985) { yCla = y; break; }
        }
      }
      niveis = { lo: 1 - yCla / 255, hi: 1 - yEsc / 255 };
      fazLUT();
    }
    function fazLUT() {
      const nv0 = niveis || { lo: 0.05, hi: 0.9 }, span = Math.max(0.1, nv0.hi - nv0.lo), lim = cfg.limiar;
      lut = new Uint8Array(256);
      for (let y = 0; y < 256; y++) {
        const Y = y / 255;
        let dn = clamp((1 - Y - nv0.lo) / span, 0, 1);
        if (cfg.inverte) dn = 1 - dn;
        const v = (VMIN + (1 - VMIN) * Math.pow(dn, cfg.gamma)) * (1 - suave(lim - 0.05, lim, Y));
        lut[y] = Math.round(255 * v);
      }
      lutVer++;
    }

    // enquadramento cover + posição: px CSS do elemento → px da amostra
    function mapa(q) {
      const s = Math.max(W / q.nw, H / q.nh), dw = q.nw * s, dh = q.nh * s;
      const ox = (W - dw) * cfg.posX, oy = (H - dh) * cfg.posY, ax = q.sw / dw, ay = q.sh / dh;
      return { ax, bx: -ox * ax, ay, by: -oy * ay };
    }
    function amostra(q, u, v) {   // bilinear; fora da imagem = branco
      const sw = q.sw, sh = q.sh, L = q.L;
      if (u < 0 || v < 0 || u > sw || v > sh) return 255;
      u -= 0.5; v -= 0.5;
      if (u < 0) u = 0; else if (u > sw - 1) u = sw - 1;
      if (v < 0) v = 0; else if (v > sh - 1) v = sh - 1;
      const x0 = u | 0, y0 = v | 0, fx = u - x0, fy = v - y0;
      const x1 = x0 < sw - 1 ? x0 + 1 : x0, r0 = y0 * sw, r1 = (y0 < sh - 1 ? y0 + 1 : y0) * sw;
      const a = L[r0 + x0], b = L[r0 + x1], c = L[r1 + x0], e = L[r1 + x1];
      const t = a + (b - a) * fx;
      return t + (c + (e - c) * fx - t) * fy;
    }
    // valor de cada célula (média de 4 amostras) e cor, medida no layout da Lara: azul-ciano no alto da figura
    // (~#0080FF, com variação ponto a ponto), azul no rosto (~#0064FF) e azul fundo na base (#0040FF);
    // ponto pequeno puxa para o azul (no branco, ponto pequeno ciano sumiria)
    function base(q) {
      if (q.bg === geoVer && q.bl === lutVer) return q.b;
      const n = cols * rows, v = new Uint8Array(n), c = new Uint8Array(n), m = mapa(q);
      const ex = pX * m.ax * 0.25, ey = pY * m.ay * 0.25;
      for (let j = 0, id = 0; j < rows; j++) {
        const sy = (gy0 + (j + 0.5) * pY) * m.ay + m.by;
        for (let i = 0; i < cols; i++, id++) {
          const sx = (gx0 + (i + 0.5) * pX) * m.ax + m.bx;
          const Y = (amostra(q, sx - ex, sy - ey) + amostra(q, sx + ex, sy - ey) + amostra(q, sx - ex, sy + ey) + amostra(q, sx + ex, sy + ey)) * 0.25;
          v[id] = lut[(Y + 0.5) | 0];
        }
      }
      const bl = borra(v, cols, rows, Math.max(2, Math.round(cols * 0.04)));
      for (let j = 0, id = 0; j < rows; j++) {
        const yN = (j + 0.5) / rows;
        for (let i = 0; i < cols; i++, id++) {
          const dens = suave(10, 150, bl[id]), vv = v[id] / 255;
          const t = 0.28 + 0.72 * yN + 0.12 * (1 - vv) + 0.1 * (dens - 0.5) + (hash(i, j) - 0.5) * 0.16;
          c[id] = Math.round(255 * clamp(t, 0, 1));
        }
      }
      q.b = { v, c }; q.m = m; q.bg = geoVer; q.bl = lutVer;
      return q.b;
    }

    // ---------- o que mostrar agora ----------
    function quadroEm(t) {
      if (!usaVideo || !quadros.length) return poster;
      let lo = 0, hi = quadros.length - 1;
      while (hi - lo > 1) { const m = (lo + hi) >> 1; if (quadros[m].t <= t) lo = m; else hi = m; }
      return Math.abs(quadros[lo].t - t) <= Math.abs(quadros[hi].t - t) ? quadros[lo] : quadros[hi];
    }
    function vista() {
      if (mistura && mistura.de && mistura.para) return { a: mistura.de, b: mistura.para, k: vaiVolta(mistura.p) };
      if (!usaVideo || !quadros.length) return poster ? { a: poster, b: null, k: 0 } : null;
      const n = quadros.length;
      if (n === 1 || tAtual <= quadros[0].t) return { a: quadros[0], b: null, k: 0 };
      if (tAtual >= quadros[n - 1].t) return { a: quadros[n - 1], b: null, k: 0 };
      let lo = 0, hi = n - 1;
      while (hi - lo > 1) { const m = (lo + hi) >> 1; if (quadros[m].t <= tAtual) lo = m; else hi = m; }
      const a = quadros[lo], b = quadros[hi], k = (tAtual - a.t) / (b.t - a.t || 1);
      return k < 0.02 ? { a, b: null, k: 0 } : k > 0.98 ? { a: b, b: null, k: 0 } : { a, b, k };
    }

    // ---------- monta a lista de pontos e pinta ----------
    function emite(x, y, r, tipo, cor, alfa) {
      if (nv * 6 + 6 > vb.length) { const nb = new Float32Array(vb.length * 2); nb.set(vb); vb = nb; }
      const o = nv * 6;
      vb[o] = x; vb[o + 1] = y; vb[o + 2] = r; vb[o + 3] = tipo; vb[o + 4] = cor; vb[o + 5] = alfa;
      nv++;
    }
    function desenha() {
      if (!W || !rend) return;
      const t0 = performance.now();
      nv = 0;
      const vi = vista();
      if (vi && lut) monta(vi);
      rend.pinta(nv);
      const ms = performance.now() - t0;
      estat.n++; estat.soma += ms; if (ms > estat.max) estat.max = ms;
      if (!glifos && !glifosAgendado && lut && podeLente()) {   // prepara os caracteres na folga: o 1º hover não engasga
        glifosAgendado = true;
        const f = () => { glifosAgendado = false; if (!glifos && W && !destruido) fazGlifos(); };
        if (window.requestIdleCallback) requestIdleCallback(f, { timeout: 1500 }); else setTimeout(f, 300);
      }
    }
    // rastro laranja: força em (x, y) = o ponteiro agora (com a força da lente) e os pontos que ficaram para trás
    let lb = null;
    function preparaLaranja() {
      lb = null;
      if (!cfg.laranja || reduzido()) return;
      const vivo = sobre && forca > 0.004 && podeLente();
      if (!vivo && !rastro.length) return;
      const RL = cfg.rastro;
      let x0 = vivo ? lx : 1e9, y0 = vivo ? ly : 1e9, x1 = vivo ? lx : -1e9, y1 = vivo ? ly : -1e9;
      for (let k = 0; k < rastro.length; k++) { const p = rastro[k]; if (p.x < x0) x0 = p.x; if (p.x > x1) x1 = p.x; if (p.y < y0) y0 = p.y; if (p.y > y1) y1 = p.y; }
      lb = { vivo, RL, x0: x0 - RL, y0: y0 - RL, x1: x1 + RL, y1: y1 + RL };
    }
    function nivelLaranja(x, y) {
      if (x < lb.x0 || x > lb.x1 || y < lb.y0 || y > lb.y1) return 0;
      const RL = lb.RL, RL2 = RL * RL;
      let m = 0;
      if (lb.vivo) { const dx = x - lx, dy = y - ly, d2 = dx * dx + dy * dy; if (d2 < RL2) m = forca * (1 - suave(RL * 0.45, RL, Math.sqrt(d2))); }
      for (let k = 0; k < rastro.length; k++) {
        const p = rastro[k], dx = x - p.x, dy = y - p.y, d2 = dx * dx + dy * dy;
        if (d2 < RL2) { const w = p.s * (1 - suave(RL * 0.45, RL, Math.sqrt(d2))); if (w > m) m = w; }
      }
      return m;
    }
    function marcaRastro(forte) {
      if (!cfg.laranja || reduzido()) return;
      const dx = px - rx, dy = py - ry;
      if (!forte && dx * dx + dy * dy < 81) return;   // um ponto a cada ~9 px de caminho
      rx = px; ry = py;
      rastro.push({ x: px, y: py, s: 1 });
      if (rastro.length > 22) rastro.shift();
    }

    function monta(vi) {
      const qa = vi.a, qb = vi.b, k = vi.k;
      const A = base(qa), B = qb ? base(qb) : null, ma = qa.m, mb = qb ? qb.m : null;
      const rd = rMax * dpr / 255, R = cfg.raio, fx = pX / fin, fy = pY / fin;
      const lente = forca > 0.004 && podeLente();
      preparaLaranja();
      let i0 = 1, i1 = 0, j0 = 1, j1 = 0;
      if (lente) {
        i0 = Math.max(0, Math.floor((lx - R - gx0) / pX)); i1 = Math.min(cols - 1, Math.floor((lx + R - gx0) / pX));
        j0 = Math.max(0, Math.floor((ly - R - gy0) / pY)); j1 = Math.min(rows - 1, Math.floor((ly + R - gy0) / pY));
        if (!glifos) fazGlifos();
      }
      const gl = [];
      for (let j = 0, id = 0; j < rows; j++) {
        const y = gy0 + (j + 0.5) * pY, yd = y * dpr, faixa = j >= j0 && j <= j1;
        for (let i = 0; i < cols; i++, id++) {
          let v = A.v[id], c = A.c[id];
          if (B) { v += (B.v[id] - v) * k; c += (B.c[id] - c) * k; }
          const x = gx0 + (i + 0.5) * pX;
          let cor = c / 255;
          if (lb && v >= 3) { const m = nivelLaranja(x, y); if (m > 0.1 + 0.62 * hash(i + 101, j + 57)) cor = 2; }   // borda pontilhada, como a moeda
          if (faixa && i >= i0 && i <= i1) {
            // lente: miolo inteiro fino, borda pontilhada (cada célula vira fina quando a força local passa do
            // limiar sorteado dela). Entrar e sair dissolve célula a célula, sem misturar tamanhos na mesma célula.
            const dx = x - lx, dy = y - ly;
            const w = forca * (1 - suave(R * 0.62, R, Math.sqrt(dx * dx + dy * dy)));
            if (w > 0.02 + 0.96 * hash(i + 7919, j)) {
              if (v > 60 && hash(j, i) < 0.2) { gl.push(x * dpr, yd, v, cor); continue; }   // um caractere no lugar
              const sf = rd / fin;
              for (let b = 0; b < fin; b++) {
                const ys = y - pY / 2 + (b + 0.5) * fy;
                for (let a = 0; a < fin; a++) {
                  const xs = x - pX / 2 + (a + 0.5) * fx;
                  let Y = amostra(qa, xs * ma.ax + ma.bx, ys * ma.ay + ma.by);
                  if (qb) Y += (amostra(qb, xs * mb.ax + mb.bx, ys * mb.ay + mb.by) - Y) * k;
                  const vf = lut[(Y + 0.5) | 0];
                  if (vf >= 3) emite(xs * dpr, ys * dpr, vf * sf, -1, cor, 1);
                }
              }
              continue;
            }
          }
          if (v >= 3) emite(x * dpr, yd, v * rd, -1, cor, 1);
        }
      }
      if (gl.length && glifos) {   // caracteres por cima: o mais pesado no escuro
        const n = glifos.n, gs = glifos.gs;
        for (let o = 0; o < gl.length; o += 4) {
          const gi = Math.min(n - 1, ((gl[o + 2] - 60) / 196 * n) | 0);
          emite(gl[o], gl[o + 1], gs, gi, gl[o + 3], 1);
        }
      }
    }

    // ---------- tempo, roteiros e laço ----------
    function trecho() {
      let t0 = 0, t1 = dur;
      if (cfg.trecho) { t0 = clamp(Math.min(cfg.trecho[0], cfg.trecho[1]), 0, dur); t1 = clamp(Math.max(cfg.trecho[0], cfg.trecho[1]), 0, dur); }
      return [t0, Math.min(t1, Math.max(0, dur - 0.04))];
    }
    function repouso() {
      const tr = trecho();
      if (cfg.repouso !== null && isFinite(cfg.repouso)) return clamp(cfg.repouso, 0, tr[1]);
      if (repAuto !== null) return repAuto;   // o quadro do vídeo mais parecido com o poster
      return cfg.modo === 'gesto' ? tr[0] : (tr[0] + tr[1]) / 2;
    }
    function tempoPonteiro() {
      const tr = trecho();
      let u = W ? clamp(px / W, 0, 1) : 0.5;
      if (cfg.sentido < 0) u = 1 - u;
      return tr[0] + (tr[1] - tr[0]) * u;
    }

    function pede() { sujo = true; anima(); }
    function anima() { if (!raf && !destruido && !document.hidden) raf = requestAnimationFrame(passo); }
    function passo(now) {
      raf = 0;
      const dt = ultimo ? Math.min(0.05, (now - ultimo) / 1000) : 1 / 60;
      ultimo = now;
      let mexe = false;
      const alvo = sobre && podeLente() ? 1 : 0;   // lente: entra e sai em ~400 ms
      if (forca !== alvo) {
        forca += (alvo - forca) * (1 - Math.exp(-dt / 0.13));
        if (Math.abs(forca - alvo) < 0.004) forca = alvo;
        mexe = true;
      }
      if (forca > 0) {
        const dx = px - lx, dy = py - ly;
        if (Math.abs(dx) + Math.abs(dy) > 0.3) { const a = 1 - Math.exp(-dt / 0.06); lx += dx * a; ly += dy * a; mexe = true; }
        else { lx = px; ly = py; }
      }
      if (rastro.length) {   // o rastro laranja apaga em ~1,5 s, ponto a ponto
        const f = Math.exp(-dt / 0.42);
        for (let k = rastro.length - 1; k >= 0; k--) { rastro[k].s *= f; if (rastro[k].s < 0.05) rastro.splice(k, 1); }
        mexe = true;
      }
      if (roteiro) { andaRoteiro(dt); mexe = true; }
      else if (usaVideo && cfg.modo === 'olhar' && !reduzido()) {
        const alvoT = sobre ? tempoPonteiro() : repouso(), d = alvoT - tAtual;
        if (Math.abs(d) > 0.002) { tAtual += d * (1 - Math.exp(-dt / (sobre ? 0.12 : 0.14))); mexe = true; }
        else if (d !== 0) { tAtual = alvoT; mexe = true; }
      }
      if (mexe || sujo) { sujo = false; desenha(); }
      if (mexe && visivel && !document.hidden) raf = requestAnimationFrame(passo);
      else ultimo = 0;
    }
    function andaRoteiro(dt) {
      const p = roteiro[0];
      if (!p.ini) {
        p.ini = true; p.tempo = 0; p.de = tAtual;
        if (p.tipo === 'vai') p.dur = Math.abs(p.para - p.de) / (p.vel || 1);
        if (p.tipo === 'mistura') mistura = { de: p.deQ || quadroEm(tAtual), para: quadroEm(p.para), p: 0 };
      }
      p.tempo += dt;
      const u = p.dur > 0 ? clamp(p.tempo / p.dur, 0, 1) : 1;
      if (p.tipo === 'vai') tAtual = p.de + (p.para - p.de) * (p.suave ? vaiVolta(u) : u);
      else if (p.tipo === 'mistura') { mistura.p = u; if (u >= 1) { mistura = null; tAtual = p.para; } }
      if (u >= 1) { roteiro.shift(); if (!roteiro.length) roteiro = null; }
    }

    // celular/toque: o gesto uma vez, e a cena repousa. Se a fusão poster → vídeo ainda estiver rodando,
    // o gesto entra na fila depois dela. Devolve true se começou (ou entrou na fila).
    function tocaGesto() {
      if (!usaVideo || !pronto || reduzido()) return false;
      if (roteiro && roteiro.gesto) return false;   // já está tocando
      const tr = trecho(), rep = repouso();
      let passos;
      if (cfg.modo === 'gesto') {
        passos = [{ tipo: 'vai', para: rep, vel: 1e6 }, { tipo: 'vai', para: tr[1], vel: 1 }, { tipo: 'espera', dur: 0.7 }, { tipo: 'mistura', para: rep, dur: 0.5 }];
      } else {
        const total = Math.abs(rep - tr[0]) + (tr[1] - tr[0]) + Math.abs(tr[1] - rep), vel = Math.max(1, total / 4.5);
        passos = [{ tipo: 'vai', para: tr[0], vel, suave: true }, { tipo: 'vai', para: tr[1], vel, suave: true }, { tipo: 'vai', para: rep, vel, suave: true }];
      }
      if (roteiro) roteiro.push.apply(roteiro, passos); else { mistura = null; roteiro = passos; }
      roteiro.gesto = true;
      ultimo = 0; anima();
      return true;
    }
    function talvezToque() {
      if (jaTocou || temHover() || reduzido() || !podeVideo()) return;
      if (!pronto) { querTocar = true; return; }
      if (tocaGesto()) jaTocou = true;
    }
    // mouse
    function entra() {
      if (reduzido()) return;
      if (cfg.modo === 'olhar') { roteiro = null; mistura = null; return; }
      if (!usaVideo || !pronto) return;
      if (mistura || roteiro) { mistura = null; roteiro = null; tAtual = repouso(); }
      roteiro = [{ tipo: 'vai', para: trecho()[1], vel: 1 }];   // toca o gesto e para no fim
    }
    function sai() {
      if (cfg.modo === 'gesto' && usaVideo && pronto && !reduzido()) roteiro = [{ tipo: 'mistura', para: repouso(), dur: 0.45 }];
    }

    // ---------- carga ----------
    let avisaPoster = null;
    const posterChegou = new Promise(r => { avisaPoster = r; });   // a captura espera o poster para achar o repouso
    if (!cfg.poster) avisaPoster();
    function carregaPoster() {
      if (posterPedido || !cfg.poster) return;
      posterPedido = true;
      const img = new Image();
      if (!mesmaOrigem(cfg.poster)) img.crossOrigin = 'anonymous';
      img.decoding = 'async';
      img.onload = () => {
        if (destruido) return;
        if (!W) geometria(el.clientWidth, el.clientHeight);
        const q = capturaQuadro(img, img.naturalWidth, img.naturalHeight, -1);
        if (q) { poster = q; defineNiveis(q); pede(); }
        else posterReserva();   // sem acesso aos pixels: o quadro não fica vazio
        avisaPoster();
      };
      img.onerror = () => avisaPoster();
      img.src = cfg.poster;
    }
    // Reserva para quando o navegador não deixa ler os pixels (index aberto direto do disco, em file://, ou
    // poster de outro domínio sem CORS): mostra o poster em duotone azul só com CSS, sem pontos e sem mouse.
    // No ar (http, mesmo domínio) isto nunca entra.
    let reserva = null;
    function posterReserva() {
      if (destruido || reserva || !cfg.poster) return;
      reserva = document.createElement('div');
      reserva.className = 'retrato-reserva';
      reserva.setAttribute('aria-hidden', 'true');
      reserva.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;overflow:hidden;pointer-events:none;isolation:isolate;border-radius:inherit';
      const im = new Image();
      im.alt = ''; im.decoding = 'async'; im.src = cfg.poster;
      im.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;max-width:none;display:block;object-fit:cover;object-position:' +
        Math.round(cfg.posX * 100) + '% ' + Math.round(cfg.posY * 100) + '%;filter:grayscale(1) contrast(1.15)';
      const tinta = document.createElement('div');   // screen: preto vira o azul, branco continua branco
      tinta.style.cssText = 'position:absolute;left:0;top:0;width:100%;height:100%;background:#0050FF;mix-blend-mode:screen';
      reserva.appendChild(im); reserva.appendChild(tinta);
      el.insertBefore(reserva, cv);
    }
    // seek e captura no 'seeked' (testado no Chrome: o quadro desenhado ali é idêntico ao de 300 ms depois;
    // o requestVideoFrameCallback não dispara com confiança num vídeo escondido, por isso não esperamos por ele)
    function busca(t) {
      return new Promise(res => {
        let feito = false;
        const fim = () => { if (feito) return; feito = true; clearTimeout(to); vd.removeEventListener('seeked', fim); res(); };
        const to = setTimeout(fim, 2500);
        vd.addEventListener('seeked', fim);
        try { vd.currentTime = t; } catch (e) { fim(); }
      });
    }
    function insere(q) { let i = quadros.length; while (i > 0 && quadros[i - 1].t > q.t) i--; quadros.splice(i, 0, q); }
    function liberaVideo() { try { vd.pause(); vd.removeAttribute('src'); vd.load(); } catch (e) { /* nada */ } }

    async function carregaVideo() {
      if (videoPedido || !podeVideo()) return;
      videoPedido = true;
      let cutuca = 0;
      try {
        if (!mesmaOrigem(cfg.src)) vd.crossOrigin = 'anonymous';
        vd.preload = 'auto'; vd.setAttribute('preload', 'auto');
        const chegou = espera(vd, 'loadeddata', 20000);
        vd.src = cfg.src; vd.load();
        // alguns Safari só carregam depois de um play(): toca mudo e pausa
        cutuca = setTimeout(() => { const p = vd.play(); if (p && p.then) p.then(() => vd.pause(), () => {}); }, 1500);
        await chegou;
        clearTimeout(cutuca); vd.pause();
        dur = vd.duration;
        if (!isFinite(dur) || dur <= 0 || !vd.videoWidth) throw new Error('vídeo sem duração');
        await Promise.race([posterChegou, new Promise(r => setTimeout(r, 4000))]);
        await capturaVideo();
      } catch (e) {
        clearTimeout(cutuca); liberaVideo();
      }
    }
    function ligaVideo(rep) {   // troca o poster pelos quadros do vídeo, fundindo se estiver na tela
      if (reserva) { reserva.remove(); reserva = null; }   // o vídeo deu para ler: sai a reserva do poster
      tAtual = rep;
      const de = poster;
      usaVideo = true;
      if (de && visivel && !roteiro && !sobre) { roteiro = [{ tipo: 'mistura', para: rep, dur: 0.35, deQ: de }]; anima(); }
      else pede();
    }
    async function capturaVideo() {
      const nw = vd.videoWidth, nh = vd.videoHeight;
      if (!W) geometria(el.clientWidth, el.clientHeight);
      const fim = Math.max(0, dur - 0.04);
      const n = cfg.modo === 'gesto' ? Math.round(clamp(dur * 15, 8, 90)) : cfg.quadros;
      const passoT = fim / (n - 1);
      // sem data-repouso e com poster: o repouso é o quadro mais parecido com o poster (o "quadro bem composto");
      // os quadros vêm em ordem e o poster fica na tela até o fim da captura (~1 s)
      const casa = (cfg.repouso === null || !isFinite(cfg.repouso)) && !!poster && W > 0;
      const rep = Math.min(repouso(), fim);
      const ordem = casa ? [] : [rep];   // sem casar: o repouso primeiro, e ele já substitui o poster
      for (let i = 0; i < n; i++) { const t = passoT * i; if (casa || Math.abs(t - rep) > passoT / 2) ordem.push(t); }
      let melhor = null, melhorD = Infinity;
      for (let i = 0; i < ordem.length; i++) {
        if (destruido) return;
        if (document.hidden) await espera(document, 'visibilitychange', 3600000).catch(() => {});
        await busca(ordem[i]);
        const q = capturaQuadro(vd, nw, nh, ordem[i]);
        if (!q) throw new Error('sem acesso aos pixels');
        // confere se o vídeo desenhou de verdade (navegador que devolve quadro vazio fica no poster)
        if (i === 0 && (q.fig < 0.001 || (poster && q.fig < poster.fig * 0.25))) throw new Error('quadro vazio');
        if (i === 0) defineNiveis(q);
        insere(q);
        if (casa) {
          const a = base(q).v, b = base(poster).v;
          let s = 0;
          for (let k = 0; k < a.length; k++) s += Math.abs(a[k] - b[k]);
          if (s < melhorD) { melhorD = s; melhor = q; }
        } else if (i === 0) ligaVideo(rep);
      }
      if (casa && melhor) { repAuto = melhor.t; ligaVideo(repAuto); }
      pronto = true;
      liberaVideo();
      if (querTocar && metade) talvezToque();
      pede();
    }

    // ---------- eventos ----------
    function posiciona(e) {
      // offsetX/Y já vêm no espaço do próprio canvas, mesmo com o retrato girado ou escalado por CSS
      // (no topo a .janela gira -4°: com clientX - getBoundingClientRect a lente ficava até ~26 px fora do ponteiro)
      if (e.target === cv && typeof e.offsetX === 'number' && isFinite(e.offsetX)) { px = e.offsetX; py = e.offsetY; return; }
      if (!rect) rect = el.getBoundingClientRect();
      px = e.clientX - rect.left; py = e.clientY - rect.top;
    }
    cv.addEventListener('pointerenter', e => {
      tipoPonteiro = e.pointerType;
      if (e.pointerType === 'touch') return;
      rect = el.getBoundingClientRect(); posiciona(e);
      sobre = true;
      if (forca < 0.02) { lx = px; ly = py; }
      entra(); anima();
    });
    cv.addEventListener('pointermove', e => {
      tipoPonteiro = e.pointerType;
      if (e.pointerType === 'touch') { posiciona(e); marcaRastro(false); anima(); return; }
      posiciona(e);
      marcaRastro(false);
      if (!sobre) { sobre = true; entra(); }
      anima();
    });
    // toque: o laranja acende onde o dedo encosta e apaga devagar
    cv.addEventListener('pointerdown', e => {
      if (e.pointerType !== 'touch') return;
      tipoPonteiro = 'touch'; rect = el.getBoundingClientRect(); posiciona(e);
      marcaRastro(true); ultimo = 0; anima();
    });
    cv.addEventListener('pointerleave', e => {
      if (e.pointerType === 'touch') return;
      sobre = false; sai(); anima();
    });
    cv.addEventListener('click', () => { if (tipoPonteiro !== 'mouse' && tipoPonteiro !== 'pen') tocaGesto(); });
    const aoRolar = () => { rect = null; };
    const aoRedimensionar = () => { rect = null; if (geometria(el.clientWidth, el.clientHeight)) { sujo = false; desenha(); } };
    const aoMudarDpr = () => { vigiaDpr(); aoRedimensionar(); };
    function vigiaDpr() {   // zoom do navegador ou troca de monitor: refaz na nova densidade
      if (mqDpr) desouve(mqDpr, aoMudarDpr);
      mqDpr = mm('(resolution: ' + (window.devicePixelRatio || 1) + 'dppx)');
      ouve(mqDpr, aoMudarDpr);
    }
    const aoMudarAba = () => {
      if (document.hidden) { if (raf) { cancelAnimationFrame(raf); raf = 0; } ultimo = 0; }
      else if (visivel) anima();
    };
    const aoMudarMovimento = () => {
      if (reduzido()) { roteiro = null; mistura = null; sobre = false; forca = 0; if (usaVideo) tAtual = repouso(); pede(); }
      else carregaVideo();
    };
    window.addEventListener('scroll', aoRolar, { passive: true, capture: true });
    window.addEventListener('resize', aoRedimensionar, { passive: true });
    document.addEventListener('visibilitychange', aoMudarAba);
    ouve(mqReduz, aoMudarMovimento);
    vigiaDpr();
    if (document.fonts && document.fonts.load) document.fonts.load('700 12px "JetBrains Mono"').then(() => { glifos = null; if (forca > 0) pede(); }, () => {});

    let ro = null, ioPerto = null, ioLonge = null, ioVis = null;
    if ('ResizeObserver' in window) {
      ro = new ResizeObserver(() => { if (geometria(el.clientWidth, el.clientHeight)) { sujo = false; desenha(); } });
      ro.observe(el);
    } else geometria(el.clientWidth, el.clientHeight);
    if ('IntersectionObserver' in window) {
      ioLonge = new IntersectionObserver(es => { if (es.some(e => e.isIntersecting)) { carregaPoster(); ioLonge.disconnect(); } }, { rootMargin: '1400px 0px' });
      ioPerto = new IntersectionObserver(es => { if (es.some(e => e.isIntersecting)) { carregaPoster(); carregaVideo(); ioPerto.disconnect(); } }, { rootMargin: '600px 0px' });
      ioVis = new IntersectionObserver(es => {
        const e = es[es.length - 1], rb = e.rootBounds;
        visivel = e.isIntersecting;
        metade = e.isIntersecting && (e.intersectionRatio >= 0.5 || !!(rb && e.intersectionRect.height >= rb.height * 0.5));
        if (visivel) anima();
        if (metade) talvezToque();
      }, { threshold: [0, 0.25, 0.5, 0.75, 1] });
      ioLonge.observe(el); ioPerto.observe(el); ioVis.observe(el);
    } else { visivel = true; carregaPoster(); carregaVideo(); }

    function destroy() {
      destruido = true;
      if (raf) cancelAnimationFrame(raf);
      [ro, ioPerto, ioLonge, ioVis].forEach(o => o && o.disconnect());
      window.removeEventListener('scroll', aoRolar, { capture: true });
      window.removeEventListener('resize', aoRedimensionar);
      document.removeEventListener('visibilitychange', aoMudarAba);
      desouve(mqReduz, aoMudarMovimento);
      if (mqDpr) desouve(mqDpr, aoMudarDpr);
      liberaVideo(); cv.remove(); vd.remove(); if (reserva) reserva.remove();
      quadros = []; poster = null;
      delete el.__lcRetrato;
      const i = instancias.indexOf(api); if (i >= 0) instancias.splice(i, 1);
    }
    const api = {
      el, cfg, destroy, gesto: tocaGesto,
      estado: () => ({
        modo: cfg.modo, cor: cfg.cor, render: rend ? rend.tipo : 'nenhum', poster: !!poster, reserva: !!reserva, usaVideo, pronto,
        quadros: quadros.length, dur, amostra: quadros[0] ? quadros[0].sw + 'x' + quadros[0].sh : poster ? poster.sw + 'x' + poster.sh : '',
        grade: cols + 'x' + rows, fineza: fin, dpr, pontos: nv, desenhos: estat.n,
        mediaMs: estat.n ? +(estat.soma / estat.n).toFixed(2) : 0, maxMs: +estat.max.toFixed(2),
        lente: +forca.toFixed(3), t: +tAtual.toFixed(3), visivel, metade, jaTocou, roteiro: !!roteiro,
      }),
      zeraEstat: () => { estat.n = 0; estat.soma = 0; estat.max = 0; },
    };
    el.__lcRetrato = api;
    instancias.push(api);
    return api;
  }

  function montaTodos(raiz) {
    return Array.from((raiz || document).querySelectorAll('[data-retrato]')).map(el => mount(el));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => montaTodos());
  else montaTodos();

  return { mount, montaTodos, instancias };
})();
