/* Lucro Criativo · LP · venda.js (sem dependências)
   1) Repassa utm_*, fbclid, gclid, gbraid, wbraid e ref da URL da LP para todo <a data-compra>.
   2) Segura o botão até a venda abrir (26/11/2026, 19h de Brasília) e solta sozinho, pela hora do servidor.
   3) No clique, manda o evento (k.js da Koko, se estiver na página; senão o pixel direto) e segue para o checkout.
   Se este arquivo não carregar, os botões continuam links comuns para https://checkout.koko.ag/lucro-criativo.

   HTML esperado:
   <html data-venda="aberta">  (o script inline do <head> acerta antes da 1ª pintura; ver teste.html)
   <a class="compra" href="https://checkout.koko.ag/lucro-criativo" data-compra="topo">
     <span class="se-aberta">Quero meu ingresso por R$ 57</span>
     <span class="se-antes">Abre hoje às 19h · faltam <span data-falta>--:--:--</span></span>
     <span class="se-encerrada">Vendas encerradas</span>
   </a>
   <div id="aviso-venda" hidden> ... <a href="https://checkout.koko.ag/lucro-criativo" data-compra="aviso" data-forca>Já passou das 19h? Abrir o pagamento</a></div>
*/
(function () {
  'use strict';
  var ABRE = Date.parse('2026-11-26T19:00:00-03:00');   // 22:00 UTC (o Brasil está sem horário de verão)
  var FECHA = Date.parse('2027-01-16T10:00:00-03:00');  // 13:00 UTC
  var CHAVES = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'utm_id',
    'fbclid', 'gclid', 'gbraid', 'wbraid', 'ref'];
  var PADRAO = {};           // UTM para quem chega sem nenhuma (padrão da planilha do Murilo/Jean). Vazio = não manda.
  var MANDA_INITIATE = true; // false se o checkout/servidor já mandar InitiateCheckout de lucro-criativo
  var EVENTO = { content_ids: ['lucro-criativo'], content_type: 'product', content_name: 'Imersão Lucro Criativo',
    content_category: 'evento', value: 57, currency: 'BRL', num_items: 1 };
  var GUARDA = 'lc_origem', VALE = 30 * 864e5;  // última origem não direta vale 30 dias neste aparelho
  var raiz = document.documentElement;

  /* ---------- 1. origem da visita ---------- */
  function limpa(v) { return String(v).replace(/[\u0000-\u001f\u007f]/g, '').slice(0, 300); }
  function leOrigem() {
    var o = {}, tem = false, q = null;
    try { q = new URLSearchParams(location.search); } catch (e) { q = null; }
    if (q) for (var i = 0; i < CHAVES.length; i++) { var v = q.get(CHAVES[i]); if (v) { o[CHAVES[i]] = limpa(v); tem = true; } }
    try {
      if (tem) localStorage.setItem(GUARDA, JSON.stringify({ t: Date.now(), o: o }));
      else {
        var s = JSON.parse(localStorage.getItem(GUARDA) || 'null');
        if (s && s.o && Date.now() - s.t < VALE) o = s.o;
      }
    } catch (e) { /* aba anônima ou storage bloqueado: fica só o que veio na URL */ }
    return o;
  }
  var ORIGEM = leOrigem();
  var temUtm = false;
  for (var k0 in ORIGEM) if (k0.indexOf('utm_') === 0) temUtm = true;

  function comOrigem(href) {
    try {
      var u = new URL(href, location.href), k;
      if (u.hostname !== 'checkout.koko.ag') return href;   // só carimba link de checkout (âncora #ingresso fica intacta)
      if (!temUtm) for (k in PADRAO) if (!u.searchParams.has(k)) u.searchParams.set(k, PADRAO[k]);
      for (k in ORIGEM) u.searchParams.set(k, ORIGEM[k]);   // a origem do visitante ganha de qualquer padrão
      return u.toString();
    } catch (e) { return href; }
  }
  var botoes = document.querySelectorAll('a[data-compra]');
  for (var b = 0; b < botoes.length; b++) botoes[b].href = comOrigem(botoes[b].getAttribute('href'));

  /* ---------- 2. hora certa e estado da venda ---------- */
  var desvio = 0, teste = NaN;
  // ?agora=2026-11-26T18:59:50-03:00 simula a hora, só em prévia (netlify.app), localhost ou arquivo
  if (location.protocol === 'file:' || /(^localhost$|^127\.0\.0\.1$|\.netlify\.app$)/.test(location.hostname)) {
    try { teste = Date.parse(new URLSearchParams(location.search).get('agora') || ''); } catch (e) { teste = NaN; }
    if (!isNaN(teste)) desvio = teste - Date.now();
  }
  function agora() { return Date.now() + desvio; }
  function estado() { var t = agora(); return t < ABRE ? 'antes' : (t < FECHA ? 'aberta' : 'encerrada'); }

  var relogios = document.querySelectorAll('[data-falta]'), tique = 0, vira = 0;
  function dois(n) { return (n < 10 ? '0' : '') + n; }
  function contagem() {
    clearInterval(tique);
    if (!relogios.length || estado() !== 'antes') return;
    var mostra = function () {
      var s = Math.max(0, Math.floor((ABRE - agora()) / 1000));
      var txt = dois(Math.floor(s / 3600)) + ':' + dois(Math.floor(s % 3600 / 60)) + ':' + dois(s % 60);
      for (var i = 0; i < relogios.length; i++) relogios[i].textContent = txt;
      if (s === 0) aplica();
    };
    mostra();
    tique = setInterval(mostra, 1000);
  }
  function aplica() {
    var e = estado();
    raiz.setAttribute('data-venda', e);
    if (e !== 'antes') fechaAviso();
    clearTimeout(vira);
    var falta = (e === 'antes' ? ABRE : (e === 'aberta' ? FECHA : 0)) - agora();
    if (falta > 0 && falta < 864e5) vira = setTimeout(aplica, falta + 300);  // vira sozinho, sem recarregar
    contagem();
  }
  function sincroniza() {
    if (!isNaN(teste) || !window.fetch) { aplica(); return; }
    var t0 = Date.now();
    fetch(location.pathname + '?hora=' + t0, { method: 'HEAD', cache: 'no-store', credentials: 'omit' })
      .then(function (r) {
        var t1 = Date.now();
        // Só o Date, nunca Date + Age: a Netlify manda o Date na hora da resposta e o Age do cache junto
        // (conferido numa prévia: Age 9750 com o Date de agora). Somar o Age adiantaria a página em horas.
        var d = Date.parse(r.headers.get('Date') || '');
        // o Date vem em segundos inteiros: +500 ms; a ida e a volta contam pela metade
        if (!isNaN(d) && t1 - t0 < 5000) desvio = d + 500 - (t0 + t1) / 2;
      })
      .catch(function () { /* sem rede: fica o relógio do aparelho */ })
      .then(aplica);
  }
  aplica();
  sincroniza();
  document.addEventListener('visibilitychange', function () { if (!document.hidden) sincroniza(); });

  /* ---------- aviso "abre às 19h" ---------- */
  var aviso = document.getElementById('aviso-venda'), voltaPara = null;
  function abreAviso(origem) {
    if (!aviso) return;
    voltaPara = origem;
    aviso.hidden = false;
    var foco = aviso.querySelector('a,button');
    if (foco) foco.focus();
  }
  function fechaAviso() {
    if (!aviso || aviso.hidden) return;
    aviso.hidden = true;
    if (voltaPara && voltaPara.focus) voltaPara.focus();
  }
  document.addEventListener('keydown', function (ev) { if (ev.key === 'Escape') fechaAviso(); });

  /* ---------- 3. clique no botão de compra ---------- */
  function mede(a) {
    try {
      var id = 'lc-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 8);
      if (MANDA_INITIATE) {
        if (window.koko && typeof window.koko.evento === 'function') window.koko.evento('InitiateCheckout', { custom: EVENTO, event_id: id });
        else if (typeof window.fbq === 'function') window.fbq('track', 'InitiateCheckout', EVENTO, { eventID: id });
      }
      if (typeof window.gtag === 'function') window.gtag('event', 'cta_click', { cta_name: 'ingresso', cta_location: a.getAttribute('data-compra') || '', cta_href: a.href });
    } catch (e) { /* medição nunca segura a compra */ }
  }
  document.addEventListener('click', function (ev) {
    var a = ev.target && ev.target.closest ? ev.target.closest('a[data-compra]') : null;
    if (!a) {
      if (ev.target && ev.target.closest && ev.target.closest('[data-fecha-aviso]')) fechaAviso();
      return;
    }
    a.href = comOrigem(a.getAttribute('href'));
    var e = estado();
    if (e !== 'aberta' && !a.hasAttribute('data-forca')) { ev.preventDefault(); abreAviso(a); return; }
    mede(a);
    // clique simples na mesma aba: 250 ms para o pixel sair antes de trocar de página
    if (ev.defaultPrevented || ev.button !== 0 || ev.metaKey || ev.ctrlKey || ev.shiftKey || ev.altKey || a.target === '_blank') return;
    ev.preventDefault();
    var destino = a.href;
    setTimeout(function () { location.href = destino; }, 250);
  });
})();
